import { useCallback, useEffect, useReducer, useRef, useState } from "react";
import { STORY, T } from "./story/data";
import { StoryEngine, clock } from "./story/engine";
import { StageMap, type Bubble } from "./components/StageMap";
import { Checklist, GodotExport, Knowledge, NarrativeLog } from "./components/Panels";
import { cn } from "./utils/cn";

const SPEEDS = [1, 10, 60, 240];
const TABS = [["log", "剧情"], ["mind", "认知"], ["check", "校验"], ["godot", "Godot 导出"]] as const;
type Said = { actor: string; text: string; at: number; until: number };
const nameOf = (id: string) => STORY.actors.find((a) => a.id === id)?.name ?? id;
const tint = (id: string) => (id === "demon" ? "#c79bff" : STORY.actors.find((a) => a.id === id)?.color ?? "#ddd");

export default function App() {
  const [auto, setAuto] = useState(false);
  const engineRef = useRef<StoryEngine>(new StoryEngine(STORY, false));
  const displayRef = useRef(engineRef.current.time);
  const cursorRef = useRef(0);
  const saidRef = useRef<Said[]>([]);
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(10);
  const [tab, setTab] = useState<(typeof TABS)[number][0]>("log");
  const [selected, setSelected] = useState(STORY.viewer);
  const [viewerOnly, setViewerOnly] = useState(true);
  const [, frame] = useReducer((x: number) => x + 1, 0);

  const consume = useCallback(() => {
    const e = engineRef.current;
    const now = performance.now() / 1000;
    let slot = Math.max(now, ...saidRef.current.map((s) => s.at + 1.6));
    for (; cursorRef.current < e.events.length; cursorRef.current++) {
      const ev = e.events[cursorRef.current];
      if ((ev.type === "start" || ev.type === "intervene") && ev.lines?.length) {
        for (const [actor, text] of ev.lines) {
          saidRef.current.push({ actor, text, at: slot, until: slot + Math.min(7, 2.6 + text.length * 0.06) });
          slot += speed >= 60 ? 0.6 : 1.6;
        }
      }
    }
    saidRef.current = saidRef.current.filter((s) => s.until > now).slice(-24);
  }, [speed]);

  useEffect(() => {
    let raf = 0, last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      const e = engineRef.current;
      if (playing && e.pending === null && !e.finished) {
        displayRef.current += dt * speed;
        e.advanceTo(displayRef.current);
      }
      if (e.pending !== null || e.finished) displayRef.current = e.time;
      consume();
      frame();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [playing, speed, consume]);

  const restart = (autoChoose = auto) => {
    engineRef.current = new StoryEngine(STORY, autoChoose);
    displayRef.current = engineRef.current.time;
    cursorRef.current = 0;
    saidRef.current = [];
  };
  const jump = (day: number) => {
    const target = T(day, 6, 59);
    if (target < engineRef.current.time) restart();
    const e = engineRef.current;
    e.advanceTo(target);
    displayRef.current = e.time;
    cursorRef.current = e.events.length;
    saidRef.current = [];
  };
  const nextBeat = () => {
    const e = engineRef.current;
    const n = e.events.length;
    for (let i = 0; i < 4000 && e.pending === null && !e.finished; i++) {
      e.advanceTo(e.time + e.data.tick);
      if (e.events.slice(n).some((x) => x.type === "start" && (x.actor === e.data.viewer || x.lines?.length))) break;
    }
    displayRef.current = e.time;
  };
  const toggleAuto = () => {
    const next = !auto;
    setAuto(next);
    const e = engineRef.current;
    e.autoChoose = next;
    if (next && e.pending) e.choose(e.pending, e.beats[e.pending].choice!.auto);
  };

  const e = engineRef.current;
  const t = displayRef.current;
  const c = clock(t);
  const phase = e.phase(t);
  const now = performance.now() / 1000;
  const live = saidRef.current.filter((s) => s.at <= now);
  const bubbles: Bubble[] = [];
  for (const s of live) { const i = bubbles.findIndex((b) => b.actor === s.actor); if (i >= 0) bubbles.splice(i, 1); bubbles.push(s); }
  const pendingBeat = e.pending ? e.beats[e.pending] : null;
  const sel = e.actors[selected];
  const selActor = STORY.actors.find((a) => a.id === selected)!;
  const results = e.evaluate();
  const fails = results.filter((r) => r.status === "fail").length;
  const passes = results.filter((r) => r.status === "pass").length;

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-[radial-gradient(ellipse_at_top,#2a2230_0%,#121014_55%,#0b0a0d_100%)] text-stone-100" style={{ fontFamily: "'Noto Serif SC','Songti SC',serif" }}>
      <header className="flex flex-wrap items-center gap-x-6 gap-y-2 border-b border-amber-200/10 px-5 py-2.5">
        <div>
          <h1 className="text-xl tracking-[0.2em] text-amber-200">安眠者有福 <span className="text-sm tracking-normal text-stone-400">· 核心剧情演出台</span></h1>
          <p className="text-[11px] text-stone-500">dual_ontology_world_reconstruct_2 · 正式 DV 前五日 → 精简 Core → Godot 箱庭演出</p>
        </div>
        <div className="flex items-baseline gap-3">
          <span className="font-mono text-3xl text-amber-100 tabular-nums">{c.text}</span>
          <span className="text-sm text-amber-300/80">第{c.day > 5 ? 5 : c.day}日</span>
        </div>
        <div className="min-w-[220px] flex-1">
          <div className="text-sm text-stone-200">{phase.title}</div>
          <div className="text-[11px] text-stone-500">{phase.subtitle}</div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5 text-[12px]">
          <button onClick={() => setPlaying((p) => !p)} className="rounded bg-amber-400 px-3 py-1 font-semibold text-stone-900 hover:bg-amber-300">{playing ? "❚❚ 暂停" : "▶ 播放"}</button>
          {SPEEDS.map((s) => (
            <button key={s} onClick={() => setSpeed(s)} className={cn("rounded px-2 py-1", speed === s ? "bg-stone-200 text-stone-900" : "bg-stone-800 hover:bg-stone-700")}>{s}×</button>
          ))}
          <button onClick={nextBeat} className="rounded bg-stone-800 px-2 py-1 hover:bg-stone-700">⏭ 下一节拍</button>
          {[1, 2, 3, 4, 5].map((d) => (
            <button key={d} onClick={() => jump(d)} className="rounded bg-stone-900 px-1.5 py-1 text-stone-400 ring-1 ring-stone-700 hover:text-amber-200">D{d}</button>
          ))}
          <button onClick={() => restart()} className="rounded bg-stone-800 px-2 py-1 hover:bg-stone-700">↺ 重来</button>
          <label className="ml-1 flex cursor-pointer items-center gap-1 text-stone-400">
            <input type="checkbox" checked={auto} onChange={toggleAuto} className="accent-amber-400" />抉择自动（按回归记录）
          </label>
        </div>
      </header>

      <div className="flex min-h-0 flex-1">
        <main className="relative flex min-w-0 flex-1 flex-col">
          <div className="relative min-h-0 flex-1 p-2">
            <StageMap engine={e} t={t} selected={selected} onSelect={(id) => { setSelected(id); setTab("mind"); }} bubbles={bubbles} />
            <div className="pointer-events-none absolute left-4 top-4 max-w-[300px] rounded-lg border border-amber-200/15 bg-black/55 p-2.5 text-[12px] backdrop-blur">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full ring-1 ring-amber-100/50" style={{ background: selActor.color }} />
                <b className="text-amber-100">{selActor.name}</b><span className="text-stone-400">{selActor.role}</span>
              </div>
              <div className="mt-1 text-stone-300">{sel.travel ? "行走中" : e.roomLabel(sel.room)}</div>
              <div className="text-stone-400">{e.activity(selected)}</div>
            </div>
            <div className="pointer-events-none absolute bottom-4 left-4 flex gap-3 rounded bg-black/40 px-2 py-1 text-[11px] text-stone-400">
              <span><i className="mr-1 inline-block h-2.5 w-2.5 rounded-sm bg-[#5aa665]" />门已开</span>
              <span><i className="mr-1 inline-block h-2.5 w-2.5 rounded-sm bg-[#c0392b]" />门锁闭</span>
              <span><i className="mr-1 inline-block h-2.5 w-2.5 rounded-sm bg-[#8e5bd6]" />勤务暗井</span>
              <span>金框 = 侦探所在 · 点击人物查看其认知</span>
            </div>
            <div className={cn("absolute right-4 top-4 rounded-full px-3 py-1 text-[12px] font-semibold", fails ? "bg-rose-700/80" : "bg-emerald-800/70")}>
              核心剧情 ✓{passes} {fails ? `✗${fails}` : ""} / {results.length}{e.finished ? " · 已完结" : ""}
            </div>
          </div>
          <div className="mx-2 mb-2 min-h-[92px] rounded-lg border border-amber-200/10 bg-black/50 px-4 py-2">
            {live.slice(-3).map((s, i, arr) => (
              <div key={`${s.at}-${i}`} className={cn("text-[15px] leading-relaxed transition-opacity", i < arr.length - 1 ? "opacity-50" : "opacity-100")}>
                <span className="mr-2 font-semibold" style={{ color: tint(s.actor) === "#0e0c10" ? "#c79bff" : tint(s.actor) }}>{nameOf(s.actor)}</span>
                <span className="text-stone-100">{s.text}</span>
              </div>
            ))}
            {!live.length && <div className="pt-6 text-center text-[12px] text-stone-600">— 字幕 —</div>}
          </div>
        </main>

        <aside className="flex w-[430px] shrink-0 flex-col border-l border-amber-200/10 bg-black/30">
          <nav className="flex border-b border-stone-800">
            {TABS.map(([k, label]) => (
              <button key={k} onClick={() => setTab(k)} className={cn("flex-1 py-2 text-[13px]", tab === k ? "border-b-2 border-amber-300 text-amber-200" : "text-stone-400 hover:text-stone-200")}>{label}</button>
            ))}
          </nav>
          <div className="min-h-0 flex-1 p-3">
            {tab === "log" && (
              <div className="flex h-full flex-col gap-2">
                <label className="flex items-center gap-2 text-[12px] text-stone-400">
                  <input type="checkbox" checked={viewerOnly} onChange={() => setViewerOnly((v) => !v)} className="accent-amber-400" />
                  仅侦探亲历（同处一室才能听见）
                </label>
                <div className="min-h-0 flex-1"><NarrativeLog engine={e} count={e.events.length} viewerOnly={viewerOnly} /></div>
              </div>
            )}
            {tab === "mind" && <Knowledge engine={e} actor={selected} onActor={setSelected} />}
            {tab === "check" && <Checklist engine={e} />}
            {tab === "godot" && <GodotExport />}
          </div>
        </aside>
      </div>

      {pendingBeat?.choice && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="w-[620px] rounded-xl border border-amber-200/25 bg-stone-950/95 p-5 shadow-2xl">
            <div className="text-[11px] tracking-widest text-amber-300/70">{clock(e.time).full} · {pendingBeat.label}</div>
            <h2 className="mt-1 text-lg text-amber-100">{pendingBeat.choice.prompt}</h2>
            <div className="mt-3 space-y-2">
              {pendingBeat.choice.options.map((o) => (
                <button key={o.id} onClick={() => e.choose(pendingBeat.id, o.id)} className="block w-full rounded-lg border border-stone-700 bg-stone-900 px-3 py-2 text-left hover:border-amber-300/70 hover:bg-stone-800">
                  <div className="text-[14px] text-stone-100">{o.label}{o.id === pendingBeat.choice!.auto && <span className="ml-2 rounded bg-emerald-800 px-1.5 text-[10px] text-emerald-100">正式回归记录</span>}</div>
                  <div className="text-[12px] text-stone-400">{o.note}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
