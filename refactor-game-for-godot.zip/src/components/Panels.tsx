import { memo, useEffect, useMemo, useRef, useState } from "react";
import { StoryEngine, clock, type ExpResult } from "../story/engine";
import { STORY } from "../story/data";
import type { StoryData } from "../story/types";
import { download, makeZip } from "../lib/zip";
import engineGd from "../godot/story_engine.gd?raw";
import stageGd from "../godot/story_stage.gd?raw";
import mainGd from "../godot/story_main.gd?raw";
import mainTscn from "../godot/story_main.tscn?raw";
import verifyGd from "../godot/story_verify.gd?raw";
import readme from "../godot/README.md?raw";
import { cn } from "../utils/cn";

const nameOf = (id: string) => STORY.actors.find((a) => a.id === id)?.name ?? id;
const colorOf = (id: string) => STORY.actors.find((a) => a.id === id)?.color ?? "#999";

// ───────── 剧情日志 ─────────
export const NarrativeLog = memo(function NarrativeLog({ engine, count, viewerOnly }: { engine: StoryEngine; count: number; viewerOnly: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const rows = useMemo(() => {
    const viewer = engine.data.viewer;
    let room = engine.data.actors.find((a) => a.id === viewer)!.home;
    const out: { t: number; kind: string; who?: string; text: string; sub?: string }[] = [];
    for (const e of engine.events.slice(0, count)) {
      if (e.actor === viewer && e.type === "walk") room = "";
      if (e.actor === viewer && e.type === "arrive") room = e.room!;
      if (e.type === "world" || e.type === "expire") out.push({ t: e.t, kind: "world", text: e.label! });
      else if (e.type === "intervene") out.push({ t: e.t, kind: "rule", who: e.actor, text: e.label!, sub: e.lines?.map((l) => `${nameOf(l[0])}：${l[1]}`).join("　") });
      else if (e.type === "choice") out.push({ t: e.t, kind: "choice", who: e.actor, text: `决定：${e.label}` });
      else if (e.type === "finish") out.push({ t: e.t, kind: "world", text: "第五日观察结束 · 观察窗完整走完" });
      else if (e.type === "start") {
        const mine = e.actor === viewer;
        const heard = !!e.lines?.length && e.room === room;
        if (viewerOnly ? mine || heard : mine || e.lines?.length)
          out.push({ t: e.t, kind: mine ? "self" : "other", who: e.actor, text: e.label!, sub: e.lines?.map((l) => `${nameOf(l[0])}：${l[1]}`).join("　") });
      }
    }
    return out.slice(-260);
  }, [engine, count, viewerOnly]);
  useEffect(() => { ref.current?.scrollTo({ top: ref.current.scrollHeight }); }, [rows.length]);
  return (
    <div ref={ref} className="h-full space-y-1.5 overflow-y-auto pr-1 text-[13px] leading-relaxed">
      {rows.map((r, i) => (
        <div key={i} className={cn("rounded-md border-l-2 px-2 py-1",
          r.kind === "world" && "border-sky-400/70 bg-sky-950/30 text-sky-100",
          r.kind === "rule" && "border-fuchsia-400 bg-fuchsia-950/40 text-fuchsia-100",
          r.kind === "choice" && "border-violet-300 bg-violet-950/40 text-violet-100",
          r.kind === "self" && "border-amber-300/80 bg-amber-950/20 text-amber-50",
          r.kind === "other" && "border-stone-500/60 bg-stone-900/40 text-stone-200")}>
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-[11px] text-stone-500">{clock(r.t).text}</span>
            {r.who && <span className="font-semibold" style={{ color: colorOf(r.who) === "#0e0c10" ? "#c79bff" : undefined }}>{nameOf(r.who)}</span>}
            <span>{r.text}</span>
          </div>
          {r.sub && <div className="mt-0.5 text-[12px] italic text-stone-300/90">{r.sub}</div>}
        </div>
      ))}
    </div>
  );
}, (a, b) => a.count === b.count && a.viewerOnly === b.viewerOnly && a.engine === b.engine);

// ───────── 人物认知 ─────────
const FACET: [RegExp, string][] = [[/\.infer\./, "推论"], [/\.trace\.|\.lock\.mechanism/, "痕迹与物证"], [/\.doc\./, "文书与证词"], [/./, "身体与现场"]];
export function Knowledge({ engine, actor, onActor }: { engine: StoryEngine; actor: string; onActor: (id: string) => void }) {
  const known = engine.known[actor] ?? {};
  const keys = Object.keys(known);
  const groups: Record<string, string[]> = {};
  for (const k of keys) { const g = FACET.find(([re]) => re.test(k))![1]; (groups[g] ??= []).push(k); }
  const fmt = (v: unknown) => (v === true ? "成立" : v === false ? "否" : String(v));
  return (
    <div className="flex h-full flex-col gap-2">
      <div className="flex flex-wrap gap-1">
        {engine.order.map((id) => (
          <button key={id} onClick={() => onActor(id)} className={cn("rounded px-1.5 py-0.5 text-[11px]", id === actor ? "bg-amber-300 text-stone-900" : "bg-stone-800 text-stone-300 hover:bg-stone-700")}>{nameOf(id)}</button>
        ))}
      </div>
      <div className="rounded-md border border-stone-700/60 bg-stone-900/50 p-2 text-[12px] text-stone-300">
        <b className="text-amber-200">{nameOf(actor)}</b> 当前：{engine.activity(actor)}　·　已知 {keys.length} 条
        {actor === engine.data.viewer && <div className="mt-1 text-stone-400">昨夜真相：<span className="text-rose-300">{"night0.phys.truth" in known ? "已知" : "未知（只能由痕迹推断）"}</span></div>}
      </div>
      <div className="flex-1 space-y-3 overflow-y-auto pr-1">
        {["推论", "痕迹与物证", "文书与证词", "身体与现场"].filter((g) => groups[g]).map((g) => (
          <div key={g}>
            <div className="mb-1 text-[11px] uppercase tracking-widest text-amber-300/70">{g} · {groups[g].length}</div>
            <div className="space-y-1">
              {groups[g].map((k) => (
                <div key={k} className="rounded bg-stone-900/60 px-2 py-1 text-[12px]">
                  <div className="text-stone-200">{STORY.labels[k] ?? k}</div>
                  <div className="text-stone-400">{fmt(known[k])}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ───────── 核心剧情校验 ─────────
const ICON = { pass: "✓", fail: "✗", pending: "…", na: "－" } as const;
const STRATS = [["lock", "机械锁门（回归）"], ["watch", "公开轮值"], ["diversion", "虚构盘点"], ["trap", "奇策·耳罩"]] as const;
type Batch = { id: string; label: string; pass: number; fail: number; na: number; events: number; ms: number; end: string };
export function Checklist({ engine }: { engine: StoryEngine }) {
  const results = engine.evaluate();
  const byId: Record<string, ExpResult> = {};
  for (const r of results) byId[r.id] = r;
  const c = { pass: 0, fail: 0, pending: 0, na: 0 };
  for (const r of results) c[r.status]++;
  const [batch, setBatch] = useState<Batch[] | null>(null);
  const [running, setRunning] = useState(false);
  const runAll = async () => {
    setRunning(true); setBatch([]);
    const out: Batch[] = [];
    for (const [id, label] of STRATS) {
      await new Promise((r) => setTimeout(r, 30));
      const data: StoryData = JSON.parse(JSON.stringify(STORY));
      data.beats.find((b) => b.choice)!.choice!.auto = id;
      const t0 = performance.now();
      const e = new StoryEngine(data, true);
      e.advanceTo(data.end + 1);
      const rs = e.evaluate();
      out.push({ id, label, pass: rs.filter((r) => r.status === "pass").length, fail: rs.filter((r) => r.status !== "pass" && r.status !== "na").length,
        na: rs.filter((r) => r.status === "na").length, events: e.events.length, ms: Math.round(performance.now() - t0), end: clock(e.time).full });
      setBatch([...out]);
    }
    setRunning(false);
  };
  return (
    <div className="flex h-full flex-col gap-2">
      <div className="grid grid-cols-4 gap-1 text-center text-[12px]">
        {(["pass", "fail", "pending", "na"] as const).map((k) => (
          <div key={k} className={cn("rounded py-1", k === "pass" && "bg-emerald-900/50 text-emerald-200", k === "fail" && "bg-rose-900/50 text-rose-200", k === "pending" && "bg-stone-800 text-stone-300", k === "na" && "bg-stone-800/60 text-stone-500")}>
            <div className="text-lg font-semibold">{c[k]}</div>{{ pass: "通过", fail: "失败", pending: "未决", na: "不适用" }[k]}
          </div>
        ))}
      </div>
      <div className="rounded-md border border-emerald-700/40 bg-emerald-950/20 p-2 text-[12px] text-emerald-100/90">
        <div className="flex items-center justify-between">
          <b>全量校验：四种第四夜策略各跑完整五日</b>
          <button disabled={running} onClick={runAll} className="rounded bg-emerald-600 px-2 py-0.5 text-white hover:bg-emerald-500 disabled:opacity-50">{running ? "运行中…" : "运行"}</button>
        </div>
        {batch && batch.map((b) => (
          <div key={b.id} className="mt-1 flex justify-between font-mono text-[11px]">
            <span>{b.label}</span><span className={b.fail ? "text-rose-300" : "text-emerald-300"}>✓{b.pass} ✗{b.fail} －{b.na} · {b.events}事件 · {b.ms}ms</span>
          </div>
        ))}
        <div className="mt-1 text-[11px] text-emerald-200/60">Godot 4.4.1 headless 实测：story_verify.gd 四种策略退出码均为 0；时间线与本页引擎逐行一致（1899/1899、1905/1905）。</div>
      </div>
      <div className="flex-1 space-y-3 overflow-y-auto pr-1">
        {[1, 2, 3, 4, 5].map((d) => (
          <div key={d}>
            <div className="mb-1 text-[11px] tracking-widest text-amber-300/70">第{d}日 · {STORY.phases[d - 1].title}</div>
            {STORY.expectations.filter((e) => e.day === d).map((e) => {
              const r = byId[e.id];
              return (
                <div key={e.id} className="flex gap-2 border-b border-stone-800/60 py-1 text-[12px]">
                  <span className={cn("w-4 shrink-0 text-center font-bold", r.status === "pass" && "text-emerald-400", r.status === "fail" && "text-rose-400", r.status === "pending" && "text-stone-500", r.status === "na" && "text-stone-600")}>{ICON[r.status]}</span>
                  <span className={cn("flex-1", r.status === "na" ? "text-stone-500" : "text-stone-200")}>{e.label}</span>
                  <span className="shrink-0 text-right text-[11px] text-stone-500">{r.detail}</span>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

// ───────── Godot 导出 ─────────
const FILES = [
  { path: "assets/data/story/core_story.json", text: () => JSON.stringify(STORY, null, 1), note: "唯一剧情数据（Web 与 Godot 共用）" },
  { path: "scenes/story/story_engine.gd", text: () => engineGd, note: "确定性 Core：时间、通行、认知、契约、校验" },
  { path: "scenes/story/story_stage.gd", text: () => stageGd, note: "箱庭演出：只读 Core 并插值；自动加载 GLB" },
  { path: "scenes/story/story_main.gd", text: () => mainGd, note: "入口：HUD、字幕、气泡、抉择、实时校验" },
  { path: "scenes/story/story_main.tscn", text: () => mainTscn, note: "入口场景" },
  { path: "scenes/story/story_verify.gd", text: () => verifyGd, note: "无界面校验（CI）" },
  { path: "scenes/story/README.md", text: () => readme, note: "接入说明" },
];
export function GodotExport() {
  const [sel, setSel] = useState(1);
  const texts = useMemo(() => FILES.map((f) => f.text()), []);
  const gdLines = texts.slice(1, 6).reduce((s, t) => s + t.split("\n").length, 0);
  return (
    <div className="flex h-full flex-col gap-2 text-[12px]">
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-md border border-rose-800/40 bg-rose-950/20 p-2 text-rose-100/80">
          <div className="text-[11px] text-rose-300/70">原工程</div>
          79 个 .cs（Core ≈ 777 KB）<br />34 个 DV 场景 ≈ 5.3 MB<br />C# Bridge ↔ JSON ↔ GDScript 往返
        </div>
        <div className="rounded-md border border-emerald-700/40 bg-emerald-950/20 p-2 text-emerald-100/90">
          <div className="text-[11px] text-emerald-300/70">精简后</div>
          1 份 JSON（{(texts[0].length / 1024).toFixed(0)} KB）<br />{gdLines} 行 GDScript · 无 C# 依赖<br />{STORY.beats.length} 个节拍 · {STORY.expectations.length} 项校验
        </div>
      </div>
      <button onClick={() => download("dowr2-story-godot.zip", makeZip(FILES.map((f, i) => ({ path: f.path, text: texts[i] }))))}
        className="rounded-md bg-amber-400 py-1.5 font-semibold text-stone-900 hover:bg-amber-300">⬇ 下载 Godot 补丁包（zip，按工程路径解压）</button>
      <div className="space-y-1">
        {FILES.map((f, i) => (
          <div key={f.path} onClick={() => setSel(i)} className={cn("flex cursor-pointer items-center gap-2 rounded px-2 py-1", sel === i ? "bg-stone-700/70" : "bg-stone-900/50 hover:bg-stone-800")}>
            <span className="flex-1 truncate font-mono text-[11px] text-amber-100">{f.path}</span>
            <span className="text-[10px] text-stone-500">{texts[i].split("\n").length} 行</span>
            <button onClick={(ev) => { ev.stopPropagation(); download(f.path.split("/").pop()!, texts[i]); }} className="text-stone-400 hover:text-amber-200">⬇</button>
          </div>
        ))}
      </div>
      <div className="text-[11px] text-stone-400">{FILES[sel].note}</div>
      <pre className="flex-1 overflow-auto rounded-md border border-stone-800 bg-black/60 p-2 font-mono text-[11px] leading-snug text-stone-300">{texts[sel].slice(0, 60000)}</pre>
    </div>
  );
}
