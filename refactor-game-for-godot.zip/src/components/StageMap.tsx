import type { StoryEngine } from "../story/engine";
import type { Door, Room } from "../story/types";

const ZONE: Record<string, string> = {
  A: "#2c3650", B: "#3d3027", C: "#233b36", D: "#3b2939", M: "#2d2c35", F: "#3c3426", U: "#20242b", X: "#29351f", S: "#17131b",
};
const REGIONS = [
  { x: -0.6, y: -2.6, w: 47.2, h: 31.2, label: "二楼 · 四区宿舍与中翼" },
  { x: 49.4, y: -2.6, w: 22.2, h: 16.2, label: "外围四院 · 风窗 09–17 开放" },
  { x: 49.4, y: 14.6, w: 23.2, h: 13.0, label: "一楼 · 食堂与监测" },
  { x: 49.4, y: 28.6, w: 23.2, h: 12.0, label: "地下 B1 / B2" },
];

type P = { x: number; y: number };
const center = (r: Room): P => ({ x: r.x + r.w / 2, y: r.y + r.h / 2 });
const lerp = (a: P, b: P, f: number): P => ({ x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f });

/** 与 story_stage.gd 的 door_point 相同：相邻取共享边中点，否则返回 null（楼梯/接驳廊画虚线） */
export function doorPoint(ra: Room, rb: Room, west = false): P | null {
  const ox0 = Math.max(ra.x, rb.x), ox1 = Math.min(ra.x + ra.w, rb.x + rb.w);
  const oy0 = Math.max(ra.y, rb.y), oy1 = Math.min(ra.y + ra.h, rb.y + rb.h);
  if (ox1 - ox0 > -1.2 && oy1 - oy0 > -1.2) return { x: west ? Math.min(ox0, ox1) + 0.8 : (ox0 + ox1) / 2, y: (oy0 + oy1) / 2 };
  return null;
}
const slot = (i: number, r: Room): P => {
  const cols = Math.max(1, Math.floor((r.w - 0.6) / 1.4)), rows = Math.max(1, Math.floor((r.h - 1.2) / 1.5));
  const col = i % cols, row = Math.floor(i / cols) % rows;
  return { x: (col - (cols - 1) / 2) * 1.4, y: (row - (rows - 1) / 2) * 1.5 + 0.4 };
};

export interface Bubble { actor: string; text: string }

export function StageMap({ engine, t, selected, onSelect, bubbles }: {
  engine: StoryEngine; t: number; selected: string; onSelect: (id: string) => void; bubbles: Bubble[];
}) {
  const rooms: Record<string, Room> = {};
  for (const r of engine.data.rooms) rooms[r.id] = r;
  const viewer = engine.data.viewer;
  const counts: Record<string, number> = {};
  const pos: Record<string, P> = {};
  for (const id of engine.order) {
    const seg = engine.segment(id, t);
    if (seg.from === seg.to) {
      const i = counts[seg.from] ?? 0;
      counts[seg.from] = i + 1;
      const c = center(rooms[seg.from]), o = slot(i, rooms[seg.from]);
      pos[id] = { x: c.x + o.x, y: c.y + o.y };
    } else {
      const a = rooms[seg.from], b = rooms[seg.to];
      const mid = doorPoint(a, b) ?? lerp(center(a), center(b), 0.5);
      pos[id] = seg.f < 0.5 ? lerp(center(a), mid, seg.f * 2) : lerp(mid, center(b), (seg.f - 0.5) * 2);
    }
  }
  const viewerRoom = engine.actors[viewer].travel ? "" : engine.actors[viewer].room;
  const open = (d: Door) => !d.lock || engine.facts[d.lock] === true;

  return (
    <svg viewBox="-1 -3.2 74.6 44.6" className="h-full w-full select-none" style={{ fontFamily: "'Noto Serif SC', 'Songti SC', serif" }}>
      <defs>
        <radialGradient id="demonGlow">
          <stop offset="0%" stopColor="#b44cff" stopOpacity="0.7" />
          <stop offset="100%" stopColor="#b44cff" stopOpacity="0" />
        </radialGradient>
        <filter id="soft"><feGaussianBlur stdDeviation="0.25" /></filter>
      </defs>
      {REGIONS.map((g) => (
        <g key={g.label}>
          <rect x={g.x} y={g.y} width={g.w} height={g.h} rx={0.8} fill="none" stroke="#c8a96a" strokeOpacity={0.25} strokeWidth={0.12} strokeDasharray="0.6 0.4" />
          <text x={g.x + 0.5} y={g.y + 1.25} fontSize={0.95} fill="#c8a96a" fillOpacity={0.75} letterSpacing={0.08}>{g.label}</text>
        </g>
      ))}
      {engine.data.doors.map((d, i) => {
        const a = rooms[d.a], b = rooms[d.b];
        if (doorPoint(a, b) || d.only) return null;
        const ca = center(a), cb = center(b);
        return <line key={`l${i}`} x1={ca.x} y1={ca.y} x2={cb.x} y2={cb.y} stroke={open(d) ? "#6fbf73" : "#c0392b"} strokeOpacity={0.35} strokeWidth={0.18} strokeDasharray="0.5 0.5" />;
      })}
      {engine.data.rooms.map((r) => {
        const here = r.id === viewerRoom;
        return (
          <g key={r.id}>
            <rect x={r.x + 0.1} y={r.y + 0.1} width={r.w - 0.2} height={r.h - 0.2} rx={0.35} fill={ZONE[r.zone]}
              stroke={here ? "#e7c77d" : "#000"} strokeOpacity={here ? 0.9 : 0.5} strokeWidth={here ? 0.22 : 0.1} />
            <text x={r.x + 0.4} y={r.y + 1.05} fontSize={r.w < 6 ? 0.62 : 0.78} fill="#e9dfc7" fillOpacity={0.7}>{r.label}</text>
          </g>
        );
      })}
      {engine.data.doors.map((d, i) => {
        const p = doorPoint(rooms[d.a], rooms[d.b], !!d.only);
        if (!p) return null;
        const o = open(d);
        if (d.only && !o) return null;
        const big = !!d.lock;
        return (
          <g key={`d${i}`}>
            <rect x={p.x - (big ? 0.55 : 0.35)} y={p.y - (big ? 0.55 : 0.35)} width={big ? 1.1 : 0.7} height={big ? 1.1 : 0.7} rx={0.15}
              fill={d.only ? "#8e5bd6" : o ? "#5aa665" : "#c0392b"} fillOpacity={big ? 0.95 : 0.55} stroke="#000" strokeWidth={0.08} />
            {big && d.label && !d.only && <text x={p.x + 0.8} y={p.y + 0.3} fontSize={0.6} fill={o ? "#9fd8a5" : "#f19a8f"}>{d.label}{o ? "" : "·锁"}</text>}
          </g>
        );
      })}
      {engine.order.map((id) => {
        if (!engine.visible(id)) return null;
        const a = engine.data.actors.find((x) => x.id === id)!;
        const p = pos[id];
        const sel = id === selected, isViewer = id === viewer;
        return (
          <g key={id} transform={`translate(${p.x} ${p.y})`} onClick={() => onSelect(id)} style={{ cursor: "pointer" }}>
            {a.hidden && <circle r={2.2} fill="url(#demonGlow)" />}
            {(sel || isViewer) && <circle r={1.0} fill="none" stroke={isViewer ? "#e7c77d" : "#9ecbff"} strokeWidth={0.14} strokeDasharray={sel && !isViewer ? "0.3 0.2" : undefined} />}
            <circle r={0.66} fill={a.color} stroke={a.hidden ? "#b44cff" : "#f2e6c9"} strokeWidth={0.12} />
            <text y={0.25} fontSize={0.72} textAnchor="middle" fill="#fff" style={{ pointerEvents: "none" }}>{a.name[0]}</text>
            <text y={1.55} fontSize={0.62} textAnchor="middle" fill="#f2e6c9" stroke="#000" strokeWidth={0.12} paintOrder="stroke" style={{ pointerEvents: "none" }}>{a.name}</text>
          </g>
        );
      })}
      {bubbles.map((b, i) => {
        const p = pos[b.actor];
        if (!p || !engine.visible(b.actor)) return null;
        const text = b.text.length > 22 ? b.text.slice(0, 21) + "…" : b.text;
        const w = Math.max(4, text.length * 0.78 + 1.2);
        const x = Math.min(Math.max(p.x - w / 2, -0.8), 73 - w);
        return (
          <g key={`b${i}`} style={{ pointerEvents: "none" }}>
            <rect x={x} y={p.y - 3.1} width={w} height={1.7} rx={0.5} fill="#f6efdc" fillOpacity={0.95} stroke="#5b4a2e" strokeWidth={0.08} filter="url(#soft)" />
            <rect x={x} y={p.y - 3.1} width={w} height={1.7} rx={0.5} fill="#f6efdc" stroke="#5b4a2e" strokeWidth={0.06} />
            <path d={`M ${p.x - 0.35} ${p.y - 1.42} L ${p.x} ${p.y - 0.85} L ${p.x + 0.35} ${p.y - 1.42} Z`} fill="#f6efdc" />
            <text x={x + 0.6} y={p.y - 1.92} fontSize={0.72} fill="#2b2117">{text}</text>
          </g>
        );
      })}
    </svg>
  );
}
