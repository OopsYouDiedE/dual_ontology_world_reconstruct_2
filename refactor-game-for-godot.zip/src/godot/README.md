# 核心剧情 · Godot 演出补丁（精简重构）

把下列文件按路径放进 `dual_ontology_world_reconstruct_2`（Godot 4.x，纯 GDScript，不依赖 C# Core）：

| 路径 | 作用 |
| --- | --- |
| `assets/data/story/core_story.json` | 唯一剧情数据：房间/门锁、17 名人物、事实、节拍、契约规则、世界事件、校验期望 |
| `scenes/story/story_engine.gd` | 确定性 Core：固定 0.25 分钟步长；决定时间、通行、认知与结果 |
| `scenes/story/story_stage.gd` | 箱庭演出：只读 Core，按 Core 给出的路径与时刻插值；自动加载 `model_XX.glb` |
| `scenes/story/story_main.gd` / `story_main.tscn` | 入口：HUD、字幕、对白气泡、第四夜抉择、实时核心剧情校验 |
| `scenes/story/story_verify.gd` | 无界面校验脚本（CI 可用） |

## 接入

```gdscript
# scenes/main/Main.gd —— 用新演出替换原 CampaignPanel
func open_campaign() -> void:
	get_tree().change_scene_to_file("res://scenes/story/story_main.tscn")
```

## 校验

```bash
godot --headless --path . --import
godot --headless --path . --script res://scenes/story/story_verify.gd -- lock --timeline=/tmp/gd.json
# 也可换成 watch / diversion / trap；退出码 0 = 全部通过
```

## 为什么这样能"正确演出"

1. **Core 独占时间**：原工程由 Godot 宿主回报到场（`requires_host_completion`）后 Core 才继续，宿主与 Core 互相等待，导致大量 blocked 回执。这里出发时 Core 就算好每段路的到达时刻，演出层只插值，永不反向影响剧情。
2. **主观认知**：勘查/阅读/推演只进入本人认知；交谈只传给同处一室者；传声管（`tell`）显式远程告知。推演节拍以 `know` 检查本人已知证据，因此侦探不全知。
3. **契约规则数据化**：第七条在 `rules` 中声明——试图把不知情的伊莲娜带到阀门时，代管者显形、告知险情并撤离，而不是替众人守夜。
4. **逐行等价**：Web 预览的 `engine.ts` 与 `story_engine.gd` 在同一 JSON 上产出完全一致的时间线（Godot 4.4.1 headless 实测：默认路线 1899 行、奇策路线 1905 行逐行一致）。

## 删掉了什么

生活模拟的需要/口渴/情绪权重、候选评分、Lean 证明桥、NavigationGraph、C# Bridge 往返 JSON……约 78 万字节 C# Core 与 530 万字节 DV 场景，精简为一份 JSON + 约 900 行 GDScript；剧情节拍、人物所知与正式回归记录的关键时刻都保留。
