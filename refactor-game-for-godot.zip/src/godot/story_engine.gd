extends RefCounted
## 确定性剧情 Core（与 Web 端 src/story/engine.ts 逐函数对应）。
## 只有 Core 决定时间、通行与结果；演出层（story_stage.gd）只读状态并按路径时刻插值，因此演出不会让剧情失步。
## 用法：var core = preload("res://scenes/story/story_engine.gd").new(data, auto_choose); core.advance_to(minutes)

signal story_event(e: Dictionary)

const PRIVATE := ["deduce", "inspect", "read"] # 勘查、阅读、推演只进入本人认知
const EPS := 0.000001

var data: Dictionary
var time: float
var facts: Dictionary = {}
var known: Dictionary = {}
var actors: Dictionary = {}
var actor_info: Dictionary = {}
var order: Array = []
var agendas: Dictionary = {}
var beats: Dictionary = {}
var done: Dictionary = {}
var skipped: Dictionary = {}
var fired: Dictionary = {}
var snapshots: Dictionary = {}
var expiries: Array = []
var choices: Dictionary = {}
var events: Array = []
var pending := ""
var auto_choose := true
var finished := false
var room_ids: Array = []
var room_idx: Dictionary = {}


static func load_story(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		push_error("找不到剧情数据：" + path)
		return {}
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
	return parsed if parsed is Dictionary else {}


func _init(story: Dictionary, auto := true) -> void:
	data = story
	auto_choose = auto
	time = float(data["start"])
	facts = data["facts"].duplicate(true)
	for a in data["actors"]:
		var id: String = a["id"]
		order.append(id)
		agendas[id] = []
		known[id] = {}
		actor_info[id] = a
		actors[id] = {"id": id, "room": a["home"], "idx": 0, "busy": null, "travel": null, "blocked": ""}
		for k in a.get("knows", []):
			known[id][k] = facts.get(k)
	for b in data["beats"]:
		beats[b["id"]] = b
		agendas[b["actor"]].append(b["id"])
	for i in data["rooms"].size():
		room_ids.append(data["rooms"][i]["id"])
		room_idx[data["rooms"][i]["id"]] = i
	_tick()


# ── 推进 ──
func advance_to(target: float) -> void:
	var step := float(data["tick"])
	while not finished and pending == "" and time + step <= target + EPS:
		time += step
		_tick()


func choose(beat_id: String, option: String) -> void:
	if pending != beat_id:
		return
	choices[beat_id] = option
	pending = ""
	_decide_all()


func _tick() -> void:
	var t := time
	for e in data["events"]:
		if not fired.has(e["id"]) and float(e["at"]) <= t + EPS:
			fired[e["id"]] = t
			_apply(e["set"])
			var tell: Array = e.get("tell", [])
			for a in tell:
				_learn(a, e["set"].keys())
			_emit({"t": t, "type": "world", "beat": e["id"], "label": e["label"], "set": e["set"], "learned": tell})
	var i := 0
	while i < expiries.size():
		var x: Dictionary = expiries[i]
		if float(x["at"]) <= t + EPS:
			expiries.remove_at(i)
			fired[x["id"]] = t
			_apply(x["set"])
			_emit({"t": t, "type": "expire", "beat": x["id"], "label": x["label"], "set": x["set"]})
		else:
			i += 1
	for id in order:
		var s: Dictionary = actors[id]
		if s["busy"] != null and float(s["busy"]["end"]) <= t + EPS:
			_complete(s)
		if s["travel"] != null:
			var times: Array = s["travel"]["times"]
			if float(times[times.size() - 1]) <= t + EPS:
				var path: Array = s["travel"]["path"]
				s["room"] = path[path.size() - 1]
				s["travel"] = null
				_emit({"t": t, "type": "arrive", "actor": id, "room": s["room"]})
	for e in data["expectations"]:
		if e["type"] == "fact" and not snapshots.has(e["id"]) and float(e["by"]) <= t + EPS:
			snapshots[e["id"]] = facts.get(e["key"])
	_decide_all()
	if not finished and t >= float(data["end"]) - EPS:
		finished = true
		_emit({"t": t, "type": "finish", "label": "第五日观察结束"})


func _decide_all() -> void:
	for id in order:
		if pending != "":
			return
		var s: Dictionary = actors[id]
		if s["busy"] == null and s["travel"] == null:
			_decide(s)


func _decide(s: Dictionary) -> void:
	var t := time
	var agenda: Array = agendas[s["id"]]
	while int(s["idx"]) < agenda.size():
		var id: String = agenda[int(s["idx"])]
		var b: Dictionary = beats[id]
		if b.has("skipIf") and _match(b["skipIf"]):
			_skip(s, b, "条件不再适用")
			continue
		if b.has("branch"):
			var v = facts.get(b["branch"]["key"])
			if v == null or (v is String and v == ""):
				return
			if not _includes(b["branch"]["values"], v):
				_skip(s, b, "未选择此分支")
				continue
		if b.has("earliest") and t < float(b["earliest"]) - EPS:
			return
		if s["room"] != b["at"]:
			var path = find_path(s["id"], s["room"], b["at"])
			if path == null:
				if s["blocked"] != id:
					s["blocked"] = id
					_emit({"t": t, "type": "blocked", "actor": s["id"], "beat": id, "room": b["at"], "label": b["label"]})
				return
			s["blocked"] = ""
			var times := [t]
			for k in range(1, path.size()):
				times.append(float(times[k - 1]) + _edge_min(s["id"], path[k - 1], path[k]))
			s["travel"] = {"beat": id, "path": path, "times": times}
			_emit({"t": t, "type": "walk", "actor": s["id"], "beat": id, "room": b["at"], "path": path, "times": times, "label": b["label"]})
			return
		if not _ready_beat(s, b):
			return
		var rule = _guard(b)
		if rule != null:
			_intervene(rule, b)
			_skip(s, b, str(rule["article"]) + "拦截")
			continue
		if b.has("choice"):
			var opt = choices.get(id)
			if opt == null:
				if not auto_choose:
					pending = id
					return
				opt = b["choice"]["auto"]
				choices[id] = opt
			var o: Dictionary = b["choice"]["options"][0]
			for x in b["choice"]["options"]:
				if x["id"] == opt:
					o = x
			_apply(o["set"])
			_emit({"t": t, "type": "choice", "actor": s["id"], "beat": id, "option": o["id"], "label": o["label"], "set": o["set"]})
		s["busy"] = {"beat": id, "start": t, "end": t + float(b["min"]), "show": b.get("show", false)}
		_emit({"t": t, "type": "start", "actor": s["id"], "beat": id, "room": b["at"], "label": b["label"], "lines": b.get("say", [])})
		return


func _ready_beat(s: Dictionary, b: Dictionary) -> bool:
	if b.has("req") and not _match(b["req"]):
		return false
	for a in b.get("after", []):
		if not done.has(a) and not skipped.has(a) and not fired.has(a):
			return false
	for k in b.get("know", []):
		if not known[s["id"]].has(k):
			return false
	for w in b.get("with", []):
		if not present(w, b["at"]):
			return false
	return true


func _complete(s: Dictionary) -> void:
	var busy: Dictionary = s["busy"]
	s["busy"] = null
	var t := time
	var bid: String = busy["beat"]
	if bid.begins_with("!"):
		_emit({"t": t, "type": "end", "actor": s["id"], "beat": bid, "room": s["room"]})
		return
	var b: Dictionary = beats[bid]
	var set_facts: Dictionary = b.get("set", {})
	_apply(set_facts)
	var keys: Array = set_facts.keys() + b.get("reveal", [])
	var audience := _audience(s["id"], b)
	for a in audience:
		_learn(a, keys)
	if b.has("expires"):
		expiries.append({"id": bid + ":expire", "at": t + float(b["expires"]["after"]), "set": b["expires"]["set"], "label": b["expires"]["label"]})
	done[bid] = {"start": busy["start"], "end": t}
	s["idx"] = int(s["idx"]) + 1
	_emit({"t": t, "type": "end", "actor": s["id"], "beat": bid, "room": b["at"], "label": b["label"], "set": set_facts, "learned": audience})


func _audience(actor: String, b: Dictionary) -> Array:
	var out := [actor]
	for a in b.get("tell", []):
		if not out.has(a):
			out.append(a)
	if not PRIVATE.has(b.get("kind", "work")):
		for id in order:
			if not out.has(id) and not actor_info[id].get("hidden", false) and present(id, b["at"]):
				out.append(id)
	return out


func _guard(b: Dictionary) -> Variant:
	for r in data["rules"]:
		if r["guard"].has(b["id"]) and _match(r["when"]):
			return r
	return null


func _intervene(r: Dictionary, b: Dictionary) -> void:
	var t := time
	var set_facts: Dictionary = r.get("set", {})
	_apply(set_facts)
	var audience: Array = [r["by"]] + r.get("tell", [])
	for a in audience:
		_learn(a, set_facts.keys())
	if actors.has(r["by"]):
		var d: Dictionary = actors[r["by"]]
		if d["busy"] == null:
			d["travel"] = null
			d["room"] = b["at"]
			d["busy"] = {"beat": "!" + str(r["id"]), "start": t, "end": t + float(r["showFor"]), "show": true}
	fired[str(r["id"]) + "@" + str(b["id"])] = t
	_emit({"t": t, "type": "intervene", "actor": r["by"], "beat": b["id"], "room": b["at"], "label": str(r["article"]) + "：" + str(r["label"]), "lines": r["say"], "set": set_facts, "reason": r["id"]})


func _skip(s: Dictionary, b: Dictionary, reason: String) -> void:
	skipped[b["id"]] = reason
	s["idx"] = int(s["idx"]) + 1
	_emit({"t": time, "type": "skip", "actor": s["id"], "beat": b["id"], "label": b["label"], "reason": reason})


# ── 空间 ──
func _usable(d: Dictionary, actor: String) -> bool:
	if d.has("lock") and not _eq(facts.get(d["lock"]), true):
		return false
	if d.has("only") and not d["only"].has(actor):
		return false
	return true


func find_path(actor: String, from: String, to: String) -> Variant:
	var n := room_ids.size()
	var dist := []
	var prev := []
	var closed := []
	for i in n:
		dist.append(INF)
		prev.append(-1)
		closed.append(false)
	var g: int = room_idx[to]
	dist[room_idx[from]] = 0.0
	while true:
		var u := -1
		for i in n:
			if not closed[i] and dist[i] < INF and (u < 0 or dist[i] < dist[u]):
				u = i
		if u < 0:
			return null
		if u == g:
			break
		closed[u] = true
		for d in data["doors"]:
			if not _usable(d, actor):
				continue
			var ia: int = room_idx[d["a"]]
			var ib: int = room_idx[d["b"]]
			var v := -1
			if ia == u:
				v = ib
			elif ib == u:
				v = ia
			if v < 0 or closed[v]:
				continue
			if dist[u] + float(d["min"]) < dist[v]:
				dist[v] = dist[u] + float(d["min"])
				prev[v] = u
	var path := []
	var w := g
	while w != -1:
		path.push_front(room_ids[w])
		w = prev[w]
	return path


func _edge_min(actor: String, a: String, b: String) -> float:
	var m := INF
	for d in data["doors"]:
		if _usable(d, actor) and ((d["a"] == a and d["b"] == b) or (d["a"] == b and d["b"] == a)):
			m = minf(m, float(d["min"]))
	return m


func door_open(d: Dictionary) -> bool:
	return not d.has("lock") or _eq(facts.get(d["lock"]), true)


# ── 认知与事实 ──
func _apply(set_facts: Dictionary) -> void:
	for k in set_facts:
		facts[k] = set_facts[k]


func _learn(actor: String, keys: Array) -> void:
	if not known.has(actor):
		return
	for key in keys:
		known[actor][key] = facts.get(key)


func _match(c: Dictionary) -> bool:
	for k in c:
		if not _eq(facts.get(k), c[k]):
			return false
	return true


static func _eq(a, b) -> bool:
	var ta := typeof(a)
	var tb := typeof(b)
	if (ta == TYPE_INT or ta == TYPE_FLOAT) and (tb == TYPE_INT or tb == TYPE_FLOAT):
		return absf(float(a) - float(b)) < EPS
	return ta == tb and a == b


func _includes(values: Array, v) -> bool:
	for x in values:
		if _eq(x, v):
			return true
	return false


func present(id: String, room: String) -> bool:
	if not actors.has(id):
		return false
	var s: Dictionary = actors[id]
	return s["room"] == room and s["travel"] == null


func _emit(e: Dictionary) -> void:
	events.append(e)
	story_event.emit(e)


# ── 供演出层读取（只读） ──
func visible(id: String) -> bool:
	var a: Dictionary = actor_info[id]
	var s: Dictionary = actors[id]
	if not a.get("hidden", false):
		return true
	if s["busy"] != null and s["busy"]["show"]:
		return true
	return s["travel"] == null and a.get("visibleIn", []).has(s["room"])


func segment(id: String, t: float) -> Dictionary:
	var s: Dictionary = actors[id]
	if s["travel"] == null:
		return {"from": s["room"], "to": s["room"], "f": 0.0}
	var path: Array = s["travel"]["path"]
	var times: Array = s["travel"]["times"]
	for k in range(1, path.size()):
		if t < float(times[k]):
			var span := float(times[k]) - float(times[k - 1])
			return {"from": path[k - 1], "to": path[k], "f": clampf((t - float(times[k - 1])) / span, 0.0, 1.0)}
	return {"from": path[path.size() - 1], "to": path[path.size() - 1], "f": 0.0}


func room_label(id: String) -> String:
	for r in data["rooms"]:
		if r["id"] == id:
			return r["label"]
	return id


func activity(id: String) -> String:
	var s: Dictionary = actors[id]
	if s["busy"] != null:
		var bid: String = s["busy"]["beat"]
		return "显形干预" if bid.begins_with("!") else str(beats[bid]["label"])
	if s["travel"] != null:
		var path: Array = s["travel"]["path"]
		return "前往 " + room_label(path[path.size() - 1])
	var agenda: Array = agendas[id]
	if int(s["idx"]) >= agenda.size():
		return "—"
	var nxt: String = agenda[int(s["idx"])]
	return ("受阻：" if s["blocked"] == nxt else "等待：") + str(beats[nxt]["label"])


func phase() -> Dictionary:
	var p: Dictionary = data["phases"][0]
	for x in data["phases"]:
		if time >= float(x["from"]):
			p = x
	return p


static func clock_text(t: float) -> String:
	var m := maxf(0.0, roundf(t * 60.0) / 60.0)
	return "第%d日 %02d:%02d" % [int(m / 1440.0) + 1, int(fmod(m, 1440.0) / 60.0), int(fmod(m, 60.0))]


func occurrence(id: String) -> Variant:
	if done.has(id):
		return done[id]
	if fired.has(id):
		return {"start": fired[id], "end": fired[id]}
	return null


func _started(id: String) -> Variant:
	for k in order:
		var b = actors[k]["busy"]
		if b != null and b["beat"] == id:
			return {"start": b["start"], "end": INF}
	return null


# ── 核心剧情校验（与 Web 端同一套期望） ──
func evaluate() -> Array:
	var out := []
	for e in data["expectations"]:
		var r := _eval_one(e)
		out.append({"id": e["id"], "day": e["day"], "label": e["label"], "status": r[0], "detail": r[1]})
	return out


func _eval_one(e: Dictionary) -> Array:
	var t := time
	if e.has("branch"):
		var v = facts.get(e["branch"]["key"])
		if v != null and not (v is String and v == "") and not _includes(e["branch"]["values"], v):
			return ["na", "本局未选此分支"]
	match str(e["type"]):
		"happens":
			var o = occurrence(e["beat"])
			if o != null:
				return ["pass", clock_text(o["end"])]
			if skipped.has(e["beat"]):
				return ["fail", "被跳过：" + str(skipped[e["beat"]])]
			return ["fail", "未发生"] if finished else ["pending", "尚未发生"]
		"order":
			var a = occurrence(e["before"])
			var b = occurrence(e["after"])
			if b == null:
				b = _started(e["after"])
			if b != null and (a == null or float(a["end"]) > float(b["start"]) + EPS):
				return ["fail", "顺序颠倒"]
			if a != null and b != null:
				return ["pass", clock_text(a["end"]) + " → " + clock_text(b["start"])]
			return ["fail", "未发生"] if finished else ["pending", "尚未发生"]
		"near":
			var o = occurrence(e["beat"])
			if o != null:
				var ok := absf(float(o["end"]) - float(e["t"])) <= float(e["tol"]) + EPS
				return ["pass" if ok else "fail", "实际 " + clock_text(o["end"])]
			return ["fail", "未在窗口内发生"] if (t > float(e["t"]) + float(e["tol"]) or finished) else ["pending", "尚未发生"]
		"fact":
			if not snapshots.has(e["id"]):
				return ["pending", "当前 " + str(facts.get(e["key"]))]
			var v = snapshots[e["id"]]
			return ["pass" if _eq(v, e["value"]) else "fail", "检查点时为 " + str(v)]
		"notKnows":
			if known[e["actor"]].has(e["key"]):
				return ["fail", "已被告知"]
			return ["pass", "全程未知"] if finished else ["pending", "目前未知"]
		"knows":
			if known[e["actor"]].has(e["key"]):
				return ["pass", "已知"]
			return ["fail", "未得知"] if (t > float(e["by"]) or finished) else ["pending", "尚未得知"]
		"startAfter":
			var o = occurrence(e["beat"])
			if o == null:
				o = _started(e["beat"])
			if o != null:
				return ["pass" if float(o["start"]) >= float(e["t"]) - EPS else "fail", "开始于 " + clock_text(o["start"])]
			return ["fail", "未发生"] if finished else ["pending", "尚未发生"]
		"within":
			var o = occurrence(e["beat"])
			if o != null:
				var ok := float(o["start"]) >= float(e["from"]) - EPS and float(o["end"]) <= float(e["to"]) + EPS
				return ["pass" if ok else "fail", clock_text(o["start"]) + "–" + clock_text(o["end"])]
			return ["fail", "未发生"] if (t > float(e["to"]) or finished) else ["pending", "尚未发生"]
	return ["fail", "未知期望类型"]
