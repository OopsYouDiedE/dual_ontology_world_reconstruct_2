extends Node
## 核心剧情演出入口：Core 推进时间 → 箱庭插值演出 → HUD（字幕、抉择、核心剧情校验）。
## 接入现有工程：把 scenes/main/Main.gd 的 open_campaign() 改为
##   get_tree().change_scene_to_file("res://scenes/story/story_main.tscn")
## 快捷键：空格 暂停 · 1/2/3/4 倍速 · F 跟随/全景 · Tab 切换焦点人物 · 右键拖拽旋转 · 滚轮缩放

const StoryCore := preload("res://scenes/story/story_engine.gd")
const StoryStage := preload("res://scenes/story/story_stage.gd")
const SPEEDS := [1.0, 10.0, 60.0, 240.0]

@export var story_path := "res://assets/data/story/core_story.json"
@export var font_path := "res://assets/external/NotoSansSC/NotoSansSC[wght].ttf"
@export var auto_choose := false ## 关闭时在第四夜等抉择处暂停等待玩家
@export var minutes_per_second := 1.0 ## 1× 时每现实秒推进的游戏分钟

var core
var stage
var font: Font
var speed := 10.0
var paused := false
var display_time := 0.0
var cursor := 0
var eval_timer := 0.0
var elapsed := 0.0
var names := {}
var colors := {}
var subtitle_lines: Array[String] = []
var choice_built_for := ""
var banner_until := 0.0

var clock_label: Label
var phase_label: Label
var focus_label: Label
var check_label: Label
var subtitles: RichTextLabel
var log_box: RichTextLabel
var choice_panel: PanelContainer
var choice_box: VBoxContainer
var banner: Label


func _ready() -> void:
	var data := StoryCore.load_story(story_path)
	if data.is_empty():
		return
	if ResourceLoader.exists(font_path):
		font = load(font_path)
	core = StoryCore.new(data, auto_choose)
	display_time = core.time
	for a in data["actors"]:
		names[a["id"]] = str(a["name"])
		colors[a["id"]] = Color(str(a["color"])).lightened(0.45).to_html(false)
	stage = StoryStage.new()
	add_child(stage)
	stage.build(core, font)
	_build_ui()
	_consume()


func _process(delta: float) -> void:
	if core == null:
		return
	elapsed += delta
	if not paused and core.pending == "" and not core.finished:
		display_time += delta * minutes_per_second * speed
		core.advance_to(display_time)
	if core.pending != "" or core.finished:
		display_time = core.time
	_consume()
	stage.refresh(display_time, delta)
	_update_hud(delta)


func _consume() -> void:
	while cursor < core.events.size():
		var e: Dictionary = core.events[cursor]
		cursor += 1
		var stamp := StoryCore.clock_text(float(e["t"])).substr(3)
		match str(e["type"]):
			"start":
				for line in e.get("lines", []):
					_say(str(line[0]), str(line[1]))
				if e["actor"] == core.data["viewer"]:
					_log(stamp, "[color=#e7c77d]%s[/color] %s" % [names[e["actor"]], e["label"]])
			"intervene":
				_banner("【%s】" % e["label"])
				for line in e.get("lines", []):
					_say(str(line[0]), str(line[1]))
				_log(stamp, "[color=#d36b6b]%s[/color]" % e["label"])
			"world", "expire":
				_banner(str(e["label"]))
				_log(stamp, "[color=#8fb6d8]%s[/color]" % e["label"])
			"choice":
				_log(stamp, "[color=#c9a0ff]决定：%s[/color]" % e["label"])
			"finish":
				_banner("第五日观察结束")
	if core.pending != "" and choice_built_for != core.pending:
		_build_choice()
	choice_panel.visible = core.pending != ""


func _say(actor: String, text: String) -> void:
	var who: String = names.get(actor, actor)
	subtitle_lines.append("[color=#%s]%s[/color]：%s" % [colors.get(actor, "ffffff"), who, text])
	while subtitle_lines.size() > 4:
		subtitle_lines.pop_front()
	subtitles.text = "\n".join(subtitle_lines)
	stage.say(actor, text, clampf(3.0 + text.length() / 10.0, 3.0, 9.0))


func _log(stamp: String, text: String) -> void:
	log_box.append_text("[color=#777777]%s[/color] %s\n" % [stamp, text])


func _banner(text: String) -> void:
	banner.text = text
	banner_until = elapsed + 4.0


func _build_choice() -> void:
	choice_built_for = core.pending
	for c in choice_box.get_children():
		c.queue_free()
	var b: Dictionary = core.beats[core.pending]
	var title := Label.new()
	title.text = str(b["choice"]["prompt"])
	title.add_theme_font_size_override("font_size", 20)
	choice_box.add_child(title)
	for o in b["choice"]["options"]:
		var btn := Button.new()
		btn.text = "%s\n%s" % [o["label"], o["note"]]
		btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		var beat_id: String = core.pending
		var option_id: String = o["id"]
		btn.pressed.connect(func(): core.choose(beat_id, option_id))
		choice_box.add_child(btn)


func _update_hud(delta: float) -> void:
	var phase: Dictionary = core.phase()
	clock_label.text = StoryCore.clock_text(display_time)
	phase_label.text = "%s · %s   %s%d×" % [phase["title"], phase["subtitle"], "⏸ " if paused else "", int(speed)]
	var f: String = stage.focus
	focus_label.text = "焦点：%s @ %s\n%s" % [names.get(f, f), core.room_label(core.actors[f]["room"]), core.activity(f)]
	banner.visible = elapsed < banner_until
	eval_timer -= delta
	if eval_timer <= 0.0:
		eval_timer = 1.0
		var c := {"pass": 0, "fail": 0, "pending": 0, "na": 0}
		var bad := []
		for r in core.evaluate():
			c[r["status"]] += 1
			if r["status"] == "fail":
				bad.append("✗ " + str(r["label"]))
		check_label.text = "核心剧情校验  ✓%d  ✗%d  …%d  －%d\n%s" % [c["pass"], c["fail"], c["pending"], c["na"], "\n".join(bad)]


func _cycle_focus() -> void:
	var i: int = core.order.find(stage.focus)
	for k in range(1, core.order.size() + 1):
		var id: String = core.order[(i + k) % core.order.size()]
		if core.visible(id):
			stage.focus = id
			stage.follow = true
			return


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match (event as InputEventKey).keycode:
			KEY_SPACE:
				paused = not paused
			KEY_1, KEY_2, KEY_3, KEY_4:
				speed = SPEEDS[(event as InputEventKey).keycode - KEY_1]
			KEY_F:
				stage.follow = not stage.follow
			KEY_TAB:
				_cycle_focus()


func _label(parent: Node, size: int) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	parent.add_child(l)
	return l


func _button(parent: Node, text: String, callback: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.pressed.connect(callback)
	parent.add_child(b)


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var theme := Theme.new()
	if font != null:
		theme.default_font = font
	theme.default_font_size = 16
	root.theme = theme
	layer.add_child(root)

	var top := PanelContainer.new()
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	root.add_child(top)
	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 12)
	top.add_child(bar)
	clock_label = _label(bar, 22)
	phase_label = _label(bar, 15)
	phase_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_button(bar, "暂停/继续", func(): paused = not paused)
	for s in SPEEDS:
		var v: float = s
		_button(bar, "%d×" % int(v), func(): speed = v)
	_button(bar, "跟随/全景", func(): stage.follow = not stage.follow)
	_button(bar, "切换焦点", _cycle_focus)

	var side := PanelContainer.new()
	side.anchor_left = 1.0
	side.anchor_right = 1.0
	side.anchor_bottom = 1.0
	side.offset_left = -380.0
	side.offset_top = 56.0
	side.offset_bottom = -172.0
	root.add_child(side)
	var col := VBoxContainer.new()
	side.add_child(col)
	focus_label = _label(col, 14)
	focus_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	check_label = _label(col, 13)
	check_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	log_box = RichTextLabel.new()
	log_box.bbcode_enabled = true
	log_box.scroll_following = true
	log_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(log_box)

	var bottom := PanelContainer.new()
	bottom.anchor_top = 1.0
	bottom.anchor_right = 1.0
	bottom.anchor_bottom = 1.0
	bottom.offset_left = 16.0
	bottom.offset_right = -16.0
	bottom.offset_top = -160.0
	bottom.offset_bottom = -12.0
	root.add_child(bottom)
	subtitles = RichTextLabel.new()
	subtitles.bbcode_enabled = true
	subtitles.add_theme_font_size_override("normal_font_size", 19)
	bottom.add_child(subtitles)

	banner = Label.new()
	banner.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	banner.grow_horizontal = Control.GROW_DIRECTION_BOTH
	banner.offset_top = 72.0
	banner.add_theme_font_size_override("font_size", 22)
	banner.add_theme_color_override("font_color", Color("f3d98b"))
	banner.visible = false
	root.add_child(banner)

	choice_panel = PanelContainer.new()
	choice_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	choice_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	choice_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	choice_panel.visible = false
	root.add_child(choice_panel)
	choice_box = VBoxContainer.new()
	choice_box.custom_minimum_size = Vector2(560, 0)
	choice_panel.add_child(choice_box)
