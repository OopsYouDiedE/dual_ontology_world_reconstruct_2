extends Node3D
## 箱庭演出层：只读 Core（story_engine.gd）状态，不做任何剧情判断。
## 人物位置 = Core 给出的路径与各段时刻的插值；倍速、掉帧、暂停都不会让演出与剧情失步。
## GLB 角色存在时自动加载（character_art.dv 的 model_XX.glb，统一缩放到 1.32m），否则用彩色胶囊占位。

const FLOOR_Y := {"2F": 0.6, "OUT": 0.45, "1F": 0.3, "B1": 0.0, "B2": -0.15}
const ZONE_COLOR := {"A": "3b4660", "B": "4c3d31", "C": "2f4b45", "D": "4b3548", "M": "3b3a44", "F": "4d4331", "U": "2a2f37", "X": "35432f", "S": "1d1921"}
const ACTOR_HEIGHT := 1.32

var core
var font: Font
var rooms := {}
var actor_nodes := {}
var bubbles := {}
var bubble_until := {}
var door_meshes := []
var camera: Camera3D
var sun: DirectionalLight3D
var env: Environment
var focus := ""
var follow := true
var yaw := -0.55
var pitch := 0.95
var distance := 22.0
var _look := Vector3(36, 0, 20)
var _dragging := false
var _clock := 0.0


func build(engine, cjk_font: Font = null) -> void:
	core = engine
	font = cjk_font
	focus = str(core.data.get("viewer", ""))
	for r in core.data["rooms"]:
		rooms[r["id"]] = r
	for r in core.data["rooms"]:
		_add_room(r)
	for d in core.data["doors"]:
		_add_door(d)
	for a in core.data["actors"]:
		_add_actor(a)
	_add_camera_and_light()


func room_center(id: String) -> Vector3:
	var r: Dictionary = rooms[id]
	return Vector3(float(r["x"]) + float(r["w"]) * 0.5, FLOOR_Y.get(r["floor"], 0.0), float(r["y"]) + float(r["h"]) * 0.5)


## 两房间相邻（间隙≤1.2m）时取共享边中点作为门点，否则取中心连线中点（楼梯/接驳廊）。
func door_point(a: String, b: String, west := false) -> Vector3:
	var ra: Dictionary = rooms[a]
	var rb: Dictionary = rooms[b]
	var ox0 := maxf(float(ra["x"]), float(rb["x"]))
	var ox1 := minf(float(ra["x"]) + float(ra["w"]), float(rb["x"]) + float(rb["w"]))
	var oy0 := maxf(float(ra["y"]), float(rb["y"]))
	var oy1 := minf(float(ra["y"]) + float(ra["h"]), float(rb["y"]) + float(rb["h"]))
	var y := maxf(room_center(a).y, room_center(b).y)
	if ox1 - ox0 > -1.2 and oy1 - oy0 > -1.2:
		var x := (ox0 + ox1) * 0.5
		if west:
			x = minf(ox0, ox1) + 0.8
		return Vector3(x, y, (oy0 + oy1) * 0.5)
	return (room_center(a) + room_center(b)) * 0.5 + Vector3(0, 0.6, 0)


func _label(text: String, size: int, color: Color) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font_size = size
	l.pixel_size = 0.01
	l.modulate = color
	l.outline_size = 10
	l.outline_modulate = Color(0, 0, 0, 0.85)
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	if font != null:
		l.font = font
	return l


func _add_room(r: Dictionary) -> void:
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(float(r["w"]) - 0.2, 0.12, float(r["h"]) - 0.2)
	mesh.mesh = box
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(ZONE_COLOR.get(r["zone"], "333333"))
	mat.roughness = 0.9
	mesh.material_override = mat
	mesh.position = room_center(r["id"]) - Vector3(0, 0.06, 0)
	add_child(mesh)
	var label := _label(str(r["label"]), 40, Color(0.9, 0.84, 0.7, 0.8))
	label.billboard = BaseMaterial3D.BILLBOARD_DISABLED
	label.rotation_degrees = Vector3(-90, 0, 0)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	label.position = Vector3(float(r["x"]) + 0.3, FLOOR_Y.get(r["floor"], 0.0) + 0.02, float(r["y"]) + 0.55)
	add_child(label)


func _add_door(d: Dictionary) -> void:
	var mi := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(0.8, 0.25, 0.8)
	mi.mesh = box
	mi.material_override = StandardMaterial3D.new()
	mi.position = door_point(d["a"], d["b"], d.has("only"))
	add_child(mi)
	door_meshes.append([d, mi])


func _add_actor(a: Dictionary) -> void:
	var root := Node3D.new()
	root.name = str(a["id"])
	add_child(root)
	var body: Node3D = null
	var model_path := str(a.get("model", ""))
	if model_path != "" and ResourceLoader.exists(model_path):
		var scene = load(model_path)
		if scene is PackedScene:
			body = scene.instantiate()
			root.add_child(body)
			body.rotation_degrees.y = -90.0
			_fit_height(body, ACTOR_HEIGHT)
	if body == null:
		var mi := MeshInstance3D.new()
		var cap := CapsuleMesh.new()
		cap.radius = 0.26
		cap.height = 1.2
		mi.mesh = cap
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(str(a["color"])).lightened(0.15)
		mi.material_override = mat
		mi.position.y = 0.6
		root.add_child(mi)
	var tag := _label(str(a["name"]), 44, Color(1, 0.95, 0.85))
	tag.position.y = ACTOR_HEIGHT + 0.3
	root.add_child(tag)
	var bubble := _label("", 40, Color(1, 1, 1))
	bubble.position.y = ACTOR_HEIGHT + 1.0
	bubble.width = 900.0
	bubble.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	bubble.visible = false
	root.add_child(bubble)
	root.position = room_center(core.actors[a["id"]]["room"])
	actor_nodes[a["id"]] = root
	bubbles[a["id"]] = bubble


func _fit_height(model: Node3D, height: float) -> void:
	var box := AABB()
	var first := true
	for n in model.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		if mi.mesh == null:
			continue
		var xf := Transform3D.IDENTITY
		var cur: Node = mi
		while cur != null and cur != model:
			if cur is Node3D:
				xf = (cur as Node3D).transform * xf
			cur = cur.get_parent()
		var b := xf * mi.mesh.get_aabb()
		box = b if first else box.merge(b)
		first = false
	if not first and box.size.y > 0.001:
		var s := height / box.size.y
		model.scale = Vector3.ONE * s
		model.position.y = -box.position.y * s


func _add_camera_and_light() -> void:
	camera = Camera3D.new()
	camera.fov = 45.0
	camera.far = 400.0
	add_child(camera)
	camera.current = true
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -35, 0)
	sun.shadow_enabled = true
	add_child(sun)
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_energy = 0.7
	we.environment = env
	add_child(we)


func say(actor: String, text: String, seconds := 4.0) -> void:
	if not bubbles.has(actor):
		return
	(bubbles[actor] as Label3D).text = text
	bubble_until[actor] = _clock + seconds


func _slot(i: int, r: Dictionary) -> Vector3:
	var cols := maxi(1, int((float(r["w"]) - 0.6) / 1.0))
	var rows := maxi(1, int((float(r["h"]) - 0.6) / 0.9))
	var col := i % cols
	var row := (i / cols) % rows
	return Vector3((col - (cols - 1) * 0.5) * 1.0, 0.0, (row - (rows - 1) * 0.5) * 0.9)


func _along(a: String, b: String, f: float) -> Vector3:
	var mid := door_point(a, b)
	return room_center(a).lerp(mid, f * 2.0) if f < 0.5 else mid.lerp(room_center(b), (f - 0.5) * 2.0)


## 每帧调用：t 为连续的演出时刻（分钟），只做插值。
func refresh(t: float, delta: float) -> void:
	_clock += delta
	var counts := {}
	for id in core.order:
		var node: Node3D = actor_nodes[id]
		node.visible = core.visible(id)
		var seg: Dictionary = core.segment(id, t)
		var target: Vector3
		var walking: bool = seg["from"] != seg["to"]
		if walking:
			target = _along(seg["from"], seg["to"], float(seg["f"]))
		else:
			var rid: String = seg["from"]
			var i: int = counts.get(rid, 0)
			counts[rid] = i + 1
			target = room_center(rid) + _slot(i, rooms[rid])
		var move := target - node.position
		node.position = target if walking or move.length() > 12.0 else node.position.lerp(target, clampf(delta * 6.0, 0.0, 1.0))
		if Vector2(move.x, move.z).length() > 0.02:
			node.rotation.y = lerp_angle(node.rotation.y, atan2(move.x, move.z), clampf(delta * 10.0, 0.0, 1.0))
		(bubbles[id] as Label3D).visible = node.visible and float(bubble_until.get(id, 0.0)) > _clock
	for item in door_meshes:
		var d: Dictionary = item[0]
		var mi: MeshInstance3D = item[1]
		var open: bool = core.door_open(d)
		mi.visible = open or not d.has("only")
		(mi.material_override as StandardMaterial3D).albedo_color = Color("6fbf73") if open else Color("c0392b")
	_update_light(t)
	_update_camera(delta)


func _update_light(t: float) -> void:
	var h := fmod(t, 1440.0) / 60.0
	var day := clampf(minf((h - 5.5) / 2.0, (20.5 - h) / 2.0), 0.0, 1.0)
	sun.light_energy = lerpf(0.18, 1.15, day)
	sun.light_color = Color(0.55, 0.62, 0.9).lerp(Color(1.0, 0.93, 0.8), day)
	env.background_color = Color("0b0f1a").lerp(Color("2a3a52"), day)
	env.ambient_light_color = Color("6c7aa0").lerp(Color("c8c2b0"), day)


func _update_camera(delta: float) -> void:
	var target := Vector3(36, 0, 20)
	if follow and actor_nodes.has(focus):
		target = (actor_nodes[focus] as Node3D).position
	_look = _look.lerp(target, clampf(delta * 3.0, 0.0, 1.0))
	var d := distance if follow else maxf(distance, 62.0)
	camera.position = _look + Vector3(sin(yaw) * cos(pitch), sin(pitch), cos(yaw) * cos(pitch)) * d
	camera.look_at(_look, Vector3.UP)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			distance = maxf(6.0, distance * 0.9)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			distance = minf(90.0, distance * 1.1)
		elif mb.button_index == MOUSE_BUTTON_RIGHT:
			_dragging = mb.pressed
	elif event is InputEventMouseMotion and _dragging:
		var mm := event as InputEventMouseMotion
		yaw -= mm.relative.x * 0.005
		pitch = clampf(pitch + mm.relative.y * 0.005, 0.25, 1.45)
