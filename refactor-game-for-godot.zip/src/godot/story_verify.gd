extends SceneTree
## 无界面核心剧情校验：
##   godot --headless --path . --script res://scenes/story/story_verify.gd -- [lock|watch|diversion|trap] [--timeline=输出.json]
## 退出码 0 = 全部通过；1 = 有失败或剧情未走完。

const StoryCore := preload("res://scenes/story/story_engine.gd")
const STORY_PATH := "res://assets/data/story/core_story.json"


func _init() -> void:
	var strategy := ""
	var timeline_path := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--timeline="):
			timeline_path = arg.substr(11)
		else:
			strategy = arg
	var data := StoryCore.load_story(STORY_PATH)
	if data.is_empty():
		quit(1)
		return
	if strategy != "":
		for b in data["beats"]:
			if b.has("choice"):
				b["choice"]["auto"] = strategy
	var started := Time.get_ticks_msec()
	var core = StoryCore.new(data, true)
	core.advance_to(float(data["end"]) + 1.0)
	var counts := {"pass": 0, "fail": 0, "pending": 0, "na": 0}
	var lines: Array[String] = []
	for r in core.evaluate():
		counts[r["status"]] += 1
		if r["status"] != "pass":
			lines.append("  [%s] D%d %s — %s" % [r["status"], int(r["day"]), r["label"], r["detail"]])
	print("Core %s | 策略 %s | 事件 %d | 用时 %d ms" % [StoryCore.clock_text(core.time), strategy if strategy != "" else "默认", core.events.size(), Time.get_ticks_msec() - started])
	print("核心剧情校验：通过 %d  失败 %d  未决 %d  不适用 %d" % [counts["pass"], counts["fail"], counts["pending"], counts["na"]])
	for l in lines:
		print(l)
	if timeline_path != "":
		var rows := []
		for e in core.events:
			if e["type"] in ["start", "end", "walk"]:
				rows.append([e["type"], e["actor"], e["beat"], e["t"]])
		var f := FileAccess.open(timeline_path, FileAccess.WRITE)
		f.store_string(JSON.stringify(rows))
		f.close()
	quit(0 if counts["fail"] == 0 and counts["pending"] == 0 and core.finished else 1)
