// 《安眠者有福》前五日核心剧情（据正式 DV：day1-morning / day2~day5 精简重写）。
// 只保留会推动剧情、产生认知或需要演出的节拍；需要/口渴等生活模拟全部删除。
import type { Actor, Beat, BeatKind, Door, Expectation, Facts, NewExpectation, Room, StoryData, WorldEvent } from "./types";

export const T = (day: number, h: number, m = 0) => (day - 1) * 1440 + h * 60 + m;

// ───────────────────────── 空间 ─────────────────────────
const room = (id: string, label: string, floor: string, zone: string, x: number, y: number, w: number, h: number): Room =>
  ({ id, label, floor, zone, x, y, w, h });

const rooms: Room[] = [
  room("R01", "R01 卢西安居室", "2F", "A", 0, 0, 5, 5), room("R02", "R02 顾平章居室", "2F", "A", 5, 0, 5, 5),
  room("R03", "R03 雀儿居室", "2F", "A", 10, 0, 5, 5), room("R04", "R04 沃德居室", "2F", "A", 15, 0, 5, 5),
  room("A-P", "甲区公共厅", "2F", "A", 0, 5, 20, 5),
  room("R05", "R05 侦探居室", "2F", "B", 26, 0, 5, 5), room("R06", "R06 霍铎居室", "2F", "B", 31, 0, 5, 5),
  room("R07", "R07 沈鼎居室", "2F", "B", 36, 0, 5, 5), room("R08", "R08 苏泠居室", "2F", "B", 41, 0, 5, 5),
  room("B-P", "乙区公共厅／小厨房", "2F", "B", 26, 5, 20, 5),
  room("2F-North-Stair", "北侧楼梯与联锁闸", "2F", "M", 0, 11, 8, 6),
  room("2F-cross-M", "二楼中翼交汇处", "2F", "M", 9, 11, 28, 6),
  room("T01", "T01 公共讲堂", "2F", "M", 38, 11, 8, 6),
  room("C-P", "丙区公共厅", "2F", "C", 0, 18, 20, 5),
  room("D-gate", "丁区边界门", "2F", "S", 21, 18, 4, 4),
  room("D-P", "丁区公共厅", "2F", "D", 26, 18, 20, 5),
  room("R09", "R09 赛尔玛居室", "2F", "C", 0, 23, 5, 5), room("R10", "R10 阮清月居室", "2F", "C", 5, 23, 5, 5),
  room("R11", "R11 伊莲娜居室", "2F", "C", 10, 23, 5, 5), room("R12", "R12 莫兰居室", "2F", "C", 15, 23, 5, 5),
  room("R13", "R13 维罗妮卡居室", "2F", "D", 26, 23, 5, 5), room("R14", "R14 贝尔特朗居室", "2F", "D", 31, 23, 5, 5),
  room("R15", "R15 玛格丽特居室", "2F", "D", 36, 23, 5, 5), room("R16", "R16 茉拉居室", "2F", "D", 41, 23, 5, 5),
  room("W-102", "文契院·纸墨分析室", "OUT", "X", 50, 0, 10, 6), room("S-102", "星仪院·精密仪器室", "OUT", "X", 61, 0, 10, 6),
  room("B-102", "白塔院·配药制备室", "OUT", "X", 50, 7, 10, 6), room("F-104", "铁工院·备件成品室", "OUT", "X", 61, 7, 10, 6),
  room("1F-Shaft-Monitor", "竖井监测壁龛", "1F", "F", 50, 17, 7, 5), room("F03", "F03 大食堂", "1F", "F", 58, 17, 8, 7),
  room("F05", "F05 热厨", "1F", "F", 67, 17, 5, 4), room("F04", "F04 配膳收发台", "1F", "F", 67, 21, 5, 3),
  room("1F-Infirmary", "临时医疗角", "1F", "F", 50, 23, 7, 4),
  room("U01-granary", "B1 主粮仓", "B1", "U", 50, 31, 7, 5), room("B1-hazard", "B1 服务廊与检修坡道", "B1", "U", 58, 31, 6, 5),
  room("B2-control", "B2 低位控制室", "B2", "U", 65, 31, 7, 5), room("B2-valve", "B2 低位阀廊", "B2", "U", 65, 37, 7, 3),
];

const doors: Door[] = [
  ...["R01", "R02", "R03", "R04"].map((r) => ({ a: r, b: "A-P", min: 1 })),
  ...["R05", "R06", "R07", "R08"].map((r) => ({ a: r, b: "B-P", min: 1 })),
  ...["R09", "R10", "R11", "R12"].map((r) => ({ a: r, b: "C-P", min: 1 })),
  ...["R13", "R14", "R15", "R16"].map((r) => ({ a: r, b: "D-P", min: 1 })),
  { a: "A-P", b: "2F-cross-M", min: 1, lock: "A_gate.lock.open", label: "甲区大门" },
  { a: "B-P", b: "2F-cross-M", min: 1, lock: "B_gate.lock.open", label: "乙区大门" },
  { a: "C-P", b: "2F-cross-M", min: 1, lock: "C_gate.lock.open", label: "丙区大门" },
  { a: "D-P", b: "2F-cross-M", min: 1, lock: "D_gate.lock.open", label: "丁区大门" },
  { a: "A-P", b: "2F-cross-M", min: 20, lock: "service_map.doc.route", only: ["quer"], label: "勤务暗井" },
  { a: "2F-cross-M", b: "T01", min: 3 },
  { a: "2F-cross-M", b: "2F-North-Stair", min: 1 },
  { a: "2F-cross-M", b: "D-gate", min: 2, only: ["demon"] },
  { a: "2F-North-Stair", b: "1F-Shaft-Monitor", min: 2, label: "北侧楼梯" },
  { a: "1F-Shaft-Monitor", b: "F03", min: 1 },
  { a: "F03", b: "F05", min: 1 }, { a: "F03", b: "F04", min: 1 }, { a: "F03", b: "1F-Infirmary", min: 2 },
  { a: "1F-Shaft-Monitor", b: "U01-granary", min: 3, label: "下行坡道" },
  { a: "1F-Shaft-Monitor", b: "B1-hazard", min: 3, label: "检修坡道" },
  { a: "B1-hazard", b: "B2-control", min: 3 }, { a: "B2-control", b: "B2-valve", min: 2 },
  { a: "2F-cross-M", b: "W-102", min: 8, lock: "wind_window.phys.open", label: "接驳廊" },
  { a: "2F-cross-M", b: "B-102", min: 8, lock: "wind_window.phys.open", label: "接驳廊" },
  { a: "2F-cross-M", b: "F-104", min: 6, lock: "wind_window.phys.open", label: "接驳廊" },
  { a: "2F-cross-M", b: "S-102", min: 7, lock: "wind_window.phys.open", label: "接驳廊" },
];

// ───────────────────────── 人物（character_art.dv 映射） ─────────────────────────
const M = (n: number) => `res://assets/characters/UserModels/model_${String(n).padStart(2, "0")}.glb`;
const actors: Actor[] = [
  { id: "lucian", name: "卢西安", role: "诗人", color: "#793e37", home: "R01", model: M(10) },
  { id: "gu", name: "顾平章", role: "考古学者", color: "#284f82", home: "R02", model: M(8) },
  { id: "quer", name: "雀儿", role: "锁匠", color: "#58614c", home: "R03", model: M(1) },
  { id: "ward", name: "沃德", role: "律师", color: "#2f3b57", home: "R04", model: M(14) },
  { id: "detective", name: "侦探", role: "侦探", color: "#654633", home: "R05", model: M(6), knows: ["detective.phys.right_hand"] },
  { id: "huo", name: "霍铎", role: "工程师", color: "#a35c36", home: "R06", model: M(4) },
  { id: "shen", name: "沈鼎", role: "厨师", color: "#d4c6a0", home: "R07", model: M(7) },
  { id: "su", name: "苏泠", role: "乐师", color: "#285852", home: "R08", model: M(16) },
  { id: "selma", name: "赛尔玛", role: "博物学者", color: "#62744b", home: "R09", model: M(5) },
  { id: "ruan", name: "阮清月", role: "棋手", color: "#ded8c4", home: "R10", model: M(17) },
  { id: "elena", name: "伊莲娜", role: "舞者", color: "#416579", home: "R11", model: M(11) },
  { id: "moran", name: "莫兰", role: "画家", color: "#66767d", home: "R12", model: M(12) },
  { id: "veronica", name: "维罗妮卡", role: "化学家", color: "#d3d1bf", home: "R13", model: M(2) },
  { id: "bertrand", name: "贝尔特朗", role: "弩手", color: "#59624d", home: "R14", model: M(3) },
  { id: "margaret", name: "玛格丽特", role: "建筑师", color: "#9b7050", home: "R15", model: M(13) },
  { id: "mora", name: "茉拉", role: "医生", color: "#c6d0bc", home: "R16", model: M(15) },
  { id: "demon", name: "代管者", role: "恶魔", color: "#0e0c10", home: "D-gate", model: M(9), hidden: true, visibleIn: ["T01"] },
];
const HUMANS = actors.filter((a) => !a.hidden).map((a) => a.id);

// ───────────────────────── 世界事实（物证预先存在于世界，需亲自勘查才会知道） ─────────────────────────
const facts: Facts = {
  "A_gate.lock.open": false, "B_gate.lock.open": false, "C_gate.lock.open": false, "D_gate.lock.open": false,
  "A_gate.lock.external_ready": false, "B_gate.lock.external_ready": false, "C_gate.lock.external_ready": false,
  "D_gate.lock.external_ready": false, "D_gate.lock.pin_released": false,
  "service_map.doc.route": false, "corridor_2F.phys.test_clear": false, "wind_window.phys.open": false,
  "night0.phys.truth": "昨夜23:31代管者清场：把梦游出门的苏泠拖回乙区、反扣门锁并转移湿布——无人记得",
  "reasoning.recalled_last_night": false,
  "detective.phys.right_hand": "手背抓痕与细丝擦伤",
  "B_foyer.trace.observation": "门口有两种鞋印与拖擦痕；自恢复门就在乙区厅内",
  "su_instrument.trace.observation": "右袖破损、鞋跟擦痕、琴盒黄铜高音弦断裂；昨夜动作没有记忆",
  "B_gate.trace.observation": "工具包里有曲柄销，门锁反扣且副栓到二档；本人不记得操作",
  "B_kitchen.trace.observation": "小厨房挂钩上有湿麻布仍在滴水，袖口潮湿；不知道谁挂回去",
  "B_foyer.trace.drag_direction": "鞋跟拖痕朝内，闭门器回弹方向与袖口受力一致",
  "B_case.infer.drag_direction_supported": false,
  "su.phys.gap_question": "",
  "B_threshold.trace.overlay": "水渍麻纤维叠压拖拽痕；当前向外气流",
  "B_threshold.trace.wedge": "门底留有削制软木楔；不能单凭刀痕唯一确认操作者",
  "B_foyer.trace.boots": "门前靴印较深、步幅均匀，与乙区四人鞋底都不符",
  "B_gate.lock.mechanism": "棘轮咬痕新鲜，反扣晚于湿布处理",
  "B_case.infer.sequence_supported": false, "B_case.infer.later_handling_suspected": false,
  "B_kitchen.trace.cloth_origin": "湿布折缝含与门槛相符的石灰岩粗粒与紫金微晶",
  "B_kitchen.trace.containers": "未使用的盆桶锅碗内壁干燥覆尘；沈鼎今晨用过的水杯单独标记",
  "B_corridor.trace.floor_dust": "门槛至挂钩的石粉带未见连续滴点、擦拭或拖抹痕",
  "B_window.trace.seal": "高窗铅封完整，窗缝积尘未动",
  "B_vent.trace.grate": "通风铁篦螺钉锈死，篦后积灰无手印",
  "B_case.infer.fifth_entity": false,
  "A_vent.trace.observation": "检修铁篦有新撬痕，与自己指缝砖灰相近；夹层内容尚未看见",
  "A_cuffs.trace.observation": "手铐被打开，带徽记的钥匙不见了",
  "A_pipe.trace.observation": "佩剑崩口与传声管托架上的新刮痕相合",
  "A_basin.trace.observation": "拓片浸在墨盆里，墨色晕开",
  "C_gate.trace.observation": "丙区门内侧完好，外侧偏心轮卡死",
  "D_gate.trace.observation": "丁区外闩扳不动，保险销仍在",
  "zones.doc.reports": "甲区手铐被开、乙区有人被拖回、丙区伊莲娜踝伤、丁区药瓶漏酸灼伤贝尔特朗",
  "direction_sign.doc.monitor": "联锁铭牌箭头指向一楼北侧竖井监测壁龛",
  "direction_sign.doc.T01": "二楼中翼东侧是公共讲堂",
  "central_pillar.doc.contract": "第1条四锚职责；第4条授权封存；第5条清场和字面真话；第6条不得拘禁；第7条具体险情知情判断；第9条风窗需09至17且压差实测达标；第12条第四十日可借此返乡",
  "central_pillar.doc.recording": "录音：代管者宣读清场时刻23:31；23:55另有工程日志，两段来源分开",
  "central_pillar.doc.steward_log": "署名代管者自述：N01封存、解开甲区手铐并收走带徽记钥匙、转移湿布与清场；保留自述来源",
  "north_stair.doc.interlock": "联锁闸只在压差达标时放行下行",
  "shaft_niche_1F.doc.active": "四锚仪表当前稳定",
  "shaft_niche_1F.doc.timeshare_log": "分时日志：导师轮值四锚座维持正压；23:31清场与23:55工程记录分属两条来源",
  "steward_request.phys.requested": false, "steward.doc.reply_day1_noon": "",
  "island_case.infer.history_correlated": false, "island_meeting.phys.done": false,
  "ward.doc.accusation_dropped": false, "hall_sound.phys.elena_help": false,
  "elena.phys.treated": false, "bertrand.phys.treated": false,
  "T01_board.phys.written": false, "lucian.trace.cuff": "", "T01_board.phys.claimed": false,
  "T01_board.doc.claimed_oracle": "",
  "T01_board.trace.writing_height": "起笔高176厘米，与卢西安抬臂范围相符",
  "T01_board.trace.chalk_poem": "蓝粉笔十四行诗：Le feu dort sous nos pas ; le vent mord nos grands murs……",
  "T01_board.doc.anachronism": "诗句引自晚于所称神谕年代三百年的戏文，且平仄失调",
  "T01_board.trace.prosody": "亚历山大体：六音节加六音节、ABBA ABBA CCDEED，合卢西安吟诵习惯",
  "lucian.trace.blue_chalk": "雀儿今晨在甲区走廊看见卢西安口袋里的半截蓝粉笔",
  "T01_case.infer.poem_attributed_to_lucian": false, "lucian.doc.confession": "",
  "T01_case.infer.author_confessed": false, "T01_board.doc.steward_comment": "", "gu.doc.poem_laughter": false,
  "F03_hall.phys.fault_seen": false, "F03_hall.phys.warm": false, "shen.phys.water_boiled": false,
  "F05_kitchen.phys.counted": false, "F05_kitchen.phys.flour_kg": 3.5, "F05_kitchen.phys.pork_kg": 1.2,
  "F05_kitchen.phys.cabbage_kg": 2, "F05_kitchen.phys.coal_kg": 6, "F05_kitchen.phys.dough_kg": 0,
  "meal_day1.doc.invited": false, "F03_meal.phys.ingredients_ready": false,
  "quer.phys.first_skins": false, "margaret.phys.first_skins": false, "ruan.phys.first_skins": false,
  "detective.phys.meal_work_done": false, "ward.phys.meal_work_done": false,
  "F03_meal.phys.cooked": false, "F03_meal.phys.dumplings": 0, "plan.doc.day2_granary": "",
  // 第二日
  "wind_window.doc.schedule": "第9条：每日09:00–17:00且压差实测达标时开放风窗，四院接驳廊可通行",
  "academy.doc.registry": "四院接驳登记图：文契院W-102、白塔院B-102、铁工院F-104、星仪院S-102",
  "granary.trace.stuck_door": "门扇斜向卡死，门槛沉降约两指；锁针与复位绞盘错位",
  "granary.doc.measured": false, "granary.phys.structure_braced": false, "granary.lock.picked": false,
  "granary.doc.supply_checked": false,
  "granary.doc.inventory": "封签清册：面粉40kg、腌肉12kg、干菜20kg、煤饼90kg；急救药剂两箱封签完好",
  "ration.doc.terms": "在册份额按人等额；热厨领用记录显示集中烹煮可省三成煤",
  "detective.infer.dual_ration": false, "ward.doc.ration_agreed": false, "shen.doc.ration_agreed": false,
  "ration.policy.mediated": false, "quer.doc.probes_sealed": false, "veronica.doc.records_sealed": false,
  "academy_W.trace.paper": "纸样与刮痕示例：借阅牌只授权阅览，不授权带出",
  "academy_B.trace.vials": "空瓶封口完好，量具齐全；缓冲药剂标签尚未配制",
  "academy_F.trace.parts": "止动销与棘齿样件尺寸与粮仓锁具相合，专用扳手在架",
  "academy_S.trace.instruments": "仪器零点漂移在容差内；压差对照表与风窗时段一致",
  "academy.doc.reports": "四位巡检者签名报告：可用设施与资源限制逐条列明",
  "detective.infer.academy_resource_limits": false,
  // 第三日
  "day3.doc.notice": "", "ration_crate.doc.log": "空箱回收原账：旧签名只出现在空箱回收栏",
  "receipt.trace.ink_layers": "斜光下签名与正文墨层不同：收件时间系后补",
  "ruan.doc.draft_ration": "棋盘夹层草稿：以旧签名调动配给权的“倒脱靴”布局",
  "detective.infer.ration_forgery": false, "day3.doc.hearing_called": false, "rations.phys.restored": false,
  "ward.doc.record_corrected": false, "case_day3.phys.resolved": false, "ruan.doc.test_admitted": false,
  // 第四日
  "contract.doc.article7": "第7条：不得令学员因不知具体险情而死；须使其知情或将其移离——不承担整夜守门",
  "valve.doc.topology": "阀路图：控制室、隔墙通口与低位阀廊相连，旁路可绕过紧闭门扇",
  "rescue_stock.doc.count": "救援药品：缓冲剂四支、夜间储备两份",
  "tools.doc.checked": false, "island_environment.phys.earthquake": false, "backflow.phys.active": false,
  "backflow.trace.bypass": "", "detective.infer.safe_airlock": false, "airlock.lock.sealed": false,
  "night_day4.doc.strategy": "", "night_day4.doc.ward_called": false, "night_day4.doc.margaret_called": false,
  "night_day4.phys.secured": false, "night_day4.doc.false_inventory": false, "night_day4.doc.report": false,
  "moran.phys.symptomatic": false, "bertrand.phys.symptomatic": false,
  "moran.phys.cured": false, "bertrand.phys.cured": false,
  "elena.phys.earmuffs": false, "elena.doc.hazard_known": false, "elena.doc.deception_discovered": false,
  "detective.infer.seventh_clause_limits": false,
  // 第五日
  "case.doc.archived": "", "steward_request_d5.phys.requested": false, "steward.doc.reply_day5": "",
  "victims.phys.rechecked": false, "autonomy.phase.active": false,
};

const labels: Record<string, string> = {
  "detective.phys.right_hand": "手背伤痕", "B_foyer.trace.observation": "门厅鞋印", "su_instrument.trace.observation": "苏泠右袖与断弦",
  "B_gate.trace.observation": "乙区门锁现状", "B_kitchen.trace.observation": "挂钩湿布", "B_foyer.trace.drag_direction": "闭门器与拖痕方向",
  "B_case.infer.drag_direction_supported": "推论：有人被拖回门内", "su.phys.gap_question": "苏泠的疑问",
  "B_threshold.trace.overlay": "门槛水渍叠压", "B_threshold.trace.wedge": "门底木楔", "B_foyer.trace.boots": "门前靴印",
  "B_gate.lock.mechanism": "棘轮咬痕", "B_case.infer.sequence_supported": "推论：拖拽→湿布→锁止的先后",
  "B_case.infer.later_handling_suspected": "推论：事后有人处理现场", "B_kitchen.trace.cloth_origin": "湿布来源",
  "B_kitchen.trace.containers": "厨房盆碗", "B_corridor.trace.floor_dust": "走廊石粉带", "B_window.trace.seal": "高窗铅封",
  "B_vent.trace.grate": "通风铁篦", "B_case.infer.fifth_entity": "推论：保留第五实体假说", "zones.doc.reports": "四区报告",
  "direction_sign.doc.monitor": "指路牌（监测壁龛）", "direction_sign.doc.T01": "指路牌（讲堂）", "central_pillar.doc.contract": "契约条文",
  "central_pillar.doc.recording": "清场录音", "central_pillar.doc.steward_log": "代管者交接册", "north_stair.doc.interlock": "联锁闸铭牌",
  "shaft_niche_1F.doc.active": "四锚仪表", "shaft_niche_1F.doc.timeshare_log": "分时日志", "steward.doc.reply_day1_noon": "代管者午间答复",
  "island_case.infer.history_correlated": "推论：四区旧事与空间证据相互印证", "lucian.trace.cuff": "卢西安右袖",
  "T01_board.doc.claimed_oracle": "卢西安的“神谕”宣称", "T01_board.trace.writing_height": "黑板起笔高度",
  "T01_board.trace.chalk_poem": "黑板原诗", "T01_board.doc.anachronism": "诗句年代错置", "T01_board.trace.prosody": "诗句格律",
  "lucian.trace.blue_chalk": "雀儿的蓝粉笔目击", "T01_case.infer.poem_attributed_to_lucian": "推论：讲堂诗稿出自卢西安",
  "lucian.doc.confession": "卢西安认账", "T01_board.doc.steward_comment": "代管者批注", "meal_day1.doc.invited": "沈鼎邀请包饺子",
  "plan.doc.day2_granary": "开仓分工", "wind_window.doc.schedule": "风窗时段（第9条）", "academy.doc.registry": "四院接驳登记图",
  "granary.trace.stuck_door": "粮仓门扇", "granary.doc.inventory": "粮药封签清册", "ration.doc.terms": "配给份额与领用记录",
  "detective.infer.dual_ration": "推论：等额份额与集中热餐可以并行", "ration.policy.mediated": "配给争议达成共同协议",
  "academy_W.trace.paper": "文契院纸样", "academy_B.trace.vials": "白塔院药瓶", "academy_F.trace.parts": "铁工院备件",
  "academy_S.trace.instruments": "星仪院仪器", "academy.doc.reports": "四院签名报告",
  "detective.infer.academy_resource_limits": "推论：四院可用设施与资源边界", "day3.doc.notice": "当事人登记",
  "ration_crate.doc.log": "空箱回收原账", "receipt.trace.ink_layers": "收件单墨层", "ruan.doc.draft_ration": "阮清月棋盘草稿",
  "detective.infer.ration_forgery": "推论：旧签名不能认证新授权", "case_day3.phys.resolved": "第三日授权争议已解决",
  "ruan.doc.test_admitted": "阮清月承认试探", "contract.doc.article7": "第七条适用条件", "valve.doc.topology": "阀路图",
  "rescue_stock.doc.count": "救援药品存量", "backflow.trace.bypass": "旁路回流", "detective.infer.safe_airlock": "推论：限定边界的短时封隔成立",
  "night_day4.phys.secured": "第四夜防护已落实", "detective.infer.seventh_clause_limits": "推论：第七条只含知情与移离义务",
  "case.doc.archived": "五日案记", "steward.doc.reply_day5": "代管者第五日答复", "victims.phys.rechecked": "两名倒灌伤者已复查",
  "night0.phys.truth": "昨夜真相", "reasoning.recalled_last_night": "恢复昨夜记忆", "T01_board.phys.written": "亲眼目睹写诗",
};

// ───────────────────────── 节拍编写助手 ─────────────────────────
type Opt = Partial<Omit<Beat, "id" | "actor" | "at" | "min" | "label">>;
type B = [string, string, number, string, Opt?];
const beats: Beat[] = [];
const KIND: [RegExp, BeatKind][] = [
  [/^wake/, "wake"], [/^sleep/, "sleep"], [/^(eat|supper|lunch|breakfast)/, "meal"], [/^deduce/, "deduce"],
  [/^read/, "read"], [/^(inspect|check|measure|scene)/, "inspect"], [/^(rest|wait|await|listen|guard|stay|relax)/, "rest"],
  [/^(share|tell|ask|persuade|recruit|report|accuse|claim|confess|expose|laugh|invite|brief|call|answer|admit|recite|mediate|warn|show_account|compare|secure|seal_medical|restore|interview)/, "talk"],
];
function ag(actor: string, day: number, list: B[]) {
  for (const [key, at, min, label, opt] of list) {
    const kind = opt?.kind ?? KIND.find(([re]) => re.test(key))?.[1] ?? "work";
    beats.push({ id: `d${day}.${actor}.${key}`, actor, at, min, label, ...opt, kind });
  }
}
const home = (id: string) => actors.find((a) => a.id === id)!.home;
const wake = (d: number, a: string, m: number, label = "醒来"): B => ["wake", home(a), 1, label, { earliest: T(d, 7, m) }];
const care = (a: string): B => ["care", home(a), 6, "饮水洗漱，整理随身器具"];
const lunch = (d: number, m = 0): B => ["lunch", "F03", 30, "在大食堂吃午饭", { earliest: T(d, 12, m) }];
const supper = (d: number, m = 0): B => ["supper", "F03", 30, "在大食堂吃晚饭", { earliest: T(d, 18, m) }];
const sleep = (d: number, a: string, h: number, m: number): B => ["sleep", home(a), 1, "洗漱后入睡", { earliest: T(d, h, m) }];
const cooked = { req: { "F03_meal.phys.cooked": true } };

// ═════════════════════ 第一日 · 门的这一侧 ═════════════════════
const BZ = ["B_foyer.trace.observation", "su_instrument.trace.observation", "B_gate.trace.observation", "B_kitchen.trace.observation", "B_foyer.trace.drag_direction"];
ag("detective", 1, [
  ["wake", "R05", 1, "醒来：手背发疼", { earliest: T(1, 7), say: [["detective", "……手背上是抓痕？昨夜的事，一点也想不起来。"]] }],
  ["wash", "R05", 6, "清洗手背抓伤"],
  ["drink", "B-P", 3, "在小厨房饮水"],
  ["inspect_shoes", "B-P", 5, "勘查门厅鞋印", { reveal: ["B_foyer.trace.observation"] }],
  ["inspect_sleeve", "B-P", 5, "检验苏泠右袖", { with: ["su"], reveal: ["su_instrument.trace.observation"] }],
  ["inspect_closer", "B-P", 5, "检查闭门器回弹方向", { after: ["d1.huo.share", "d1.shen.share", "d1.su.share"], reveal: ["B_foyer.trace.drag_direction"] }],
  ["deduce_drag", "B-P", 2, "脑内推演：鞋印、袖口与门扇的拖回方向", { know: BZ, set: { "B_case.infer.drag_direction_supported": true },
    say: [["detective", "拖痕朝内，闭门器回弹与袖口受力一致——有人被拖回了门内。防卫与冲突都未排除；缺乏动机不是反证。"]] }],
  ["tell_su", "B-P", 1, "向苏泠说明拖回分析", { with: ["su"], kind: "talk", say: [["detective", "苏泠小姐，你的右袖，是被人从门外拖回来时扯破的。"]] }],
  ["inspect_watermark", "B-P", 8, "勘查门槛水渍", { after: ["d1.su.ask_gap"], reveal: ["B_threshold.trace.overlay"] }],
  ["inspect_wedge", "B-P", 7, "检查门槛木楔", { reveal: ["B_threshold.trace.wedge"] }],
  ["inspect_boots", "B-P", 7, "勘查门前靴印", { reveal: ["B_foyer.trace.boots"] }],
  ["inspect_lock", "B-P", 8, "核对棘轮咬痕", { reveal: ["B_gate.lock.mechanism"] }],
  ["deduce_sequence", "B-P", 2, "脑内推演：拖拽、湿布与锁止的先后", {
    know: ["B_case.infer.drag_direction_supported", "B_threshold.trace.overlay", "B_threshold.trace.wedge", "B_gate.lock.mechanism"],
    set: { "B_case.infer.sequence_supported": true, "B_case.infer.later_handling_suspected": true },
    say: [["detective", "水渍叠压在拖痕之上，棘轮咬痕又晚于湿布——先拖回，再塞布，最后反扣。是事后有人处理了现场。"]] }],
  ["inspect_wetcloth", "B-P", 5, "检验挂钩湿布", { reveal: ["B_kitchen.trace.cloth_origin"] }],
  ["inspect_containers", "B-P", 5, "检视厨房盆碗", { reveal: ["B_kitchen.trace.containers"] }],
  ["inspect_dust", "B-P", 5, "勘查走廊石粉带", { reveal: ["B_corridor.trace.floor_dust"] }],
  ["inspect_window", "B-P", 8, "检查高窗铅封", { reveal: ["B_window.trace.seal"] }],
  ["inspect_vent", "B-P", 7, "检查通风铁篦", { reveal: ["B_vent.trace.grate"] }],
  ["deduce_fifth", "B-P", 2, "脑内推演：排查封窗与地面后保留的第五实体假说", {
    know: ["B_case.infer.sequence_supported", "B_kitchen.trace.cloth_origin", "B_kitchen.trace.containers", "B_corridor.trace.floor_dust", "B_window.trace.seal", "B_vent.trace.grate"],
    set: { "B_case.infer.fifth_entity": true },
    say: [["detective", "湿布没有沿地面留下滴痕，窗与篦都没被动过——乙区四人之外，昨夜还有第五个“实体”在场。"]] }],
  ["report_b", "B-P", 3, "通报乙区推论", { reveal: ["B_case.infer.sequence_supported", "B_case.infer.fifth_entity"],
    say: [["detective", "诸位，门锁是在湿布之后才反扣的——霍铎，照这个顺序倒着拆，门就能开。"], ["huo", "明白，先插回曲柄销，再卸棘轮。"]] }],
  ["notes_b", "B-P", 25, "整理乙区勘查笔记"],
  ["reexamine", "B-P", 30, "门开后复核乙区门锁内外两侧", { after: ["d1.huo.pull_b"] }],
  ["su_testimony", "B-P", 20, "记录苏泠关于断弦的陈述", { with: ["su"], kind: "talk" }],
  ["await_meeting", "B-P", 50, "在乙区门口等候各区安置伤员", { kind: "rest" }],
  ["compare", "2F-cross-M", 15, "听取四区报告", { earliest: T(1, 11), with: ["ward", "ruan", "margaret"], reveal: ["zones.doc.reports"],
    say: [["ward", "甲区：我的手铐被人打开，带徽记的钥匙不见了。"], ["ruan", "丙区：伊莲娜左踝扭伤，门外偏心轮卡死。"], ["margaret", "丁区：药瓶漏酸灼伤了贝尔特朗，外闩保险销一直插着。"]] }],
  ["read_signs", "2F-cross-M", 1, "阅读指路牌", { reveal: ["direction_sign.doc.monitor", "direction_sign.doc.T01"] }],
  ["read_contract", "2F-cross-M", 15, "阅读中央石柱上的契约", { reveal: ["central_pillar.doc.contract"] }],
  ["play_record", "2F-cross-M", 15, "播放清场录音", { kind: "inspect", reveal: ["central_pillar.doc.recording"] }],
  ["read_log", "2F-cross-M", 10, "阅读代管者交接册", { reveal: ["central_pillar.doc.steward_log"] }],
  ["inspect_stairs", "2F-North-Stair", 10, "检查联锁闸", { reveal: ["north_stair.doc.interlock"] }],
  ["read_gauges", "1F-Shaft-Monitor", 8, "读取四锚仪表", { reveal: ["shaft_niche_1F.doc.active"] }],
  ["read_monitor_log", "1F-Shaft-Monitor", 12, "阅读分时日志", { reveal: ["shaft_niche_1F.doc.timeshare_log"] }],
  ["ask_steward", "1F-Shaft-Monitor", 1, "通过传声管询问代管者", { set: { "steward_request.phys.requested": true },
    say: [["detective", "代管者，导师们现在在哪里？B1与外院何时开放？"]] }],
  ["deduce_records", "1F-Shaft-Monitor", 2, "脑内推演：契约、录音与分时日志的来源对照", {
    know: ["central_pillar.doc.contract", "central_pillar.doc.recording", "central_pillar.doc.steward_log", "shaft_niche_1F.doc.timeshare_log", "steward.doc.reply_day1_noon"],
    set: { "island_case.infer.history_correlated": true },
    say: [["detective", "录音、交接册与分时日志各有来源——23:31清场是代管者自述，23:55是工程记录。四区旧事与空间证据对得上。"]] }],
  ["briefing", "2F-cross-M", 10, "向在场同伴通报", { set: { "island_meeting.phys.done": true },
    reveal: ["island_case.infer.history_correlated", "central_pillar.doc.steward_log", "steward.doc.reply_day1_noon"],
    say: [["detective", "昨夜清场的是代管者本人：它封存N01、解开甲区手铐、转移湿布。导师在四锚座维持正压，B1与外院明日才开放。"]] }],
  ["show_account", "2F-cross-M", 1, "向沃德说明钥匙记录", { with: ["ward"], reveal: ["central_pillar.doc.steward_log"],
    say: [["detective", "沃德先生，交接册上代管者亲笔承认：是它解开手铐、收走了徽记钥匙。"], ["ward", "……所以，不是那丫头。"]] }],
  ["noon_notes", "2F-cross-M", 45, "整理案件笔记（午间）"],
  ["inspect_poet", "2F-cross-M", 2, "观察卢西安衣袖", { req: { "T01_board.phys.claimed": true }, with: ["lucian"], reveal: ["lucian.trace.cuff"] }],
  ["inspect_height", "T01", 3, "测量黑板字高", { with: ["lucian"], reveal: ["T01_board.trace.writing_height"] }],
  ["inspect_poem", "T01", 2, "近看黑板原诗与译句", { reveal: ["T01_board.trace.chalk_poem"] }],
  ["inspect_prosody", "T01", 4, "比对诗句格律与年代", { reveal: ["T01_board.doc.anachronism", "T01_board.trace.prosody"] }],
  ["deduce_poem", "T01", 2, "脑内推演：年代、笔迹高度与粉笔的作者证据", {
    know: ["T01_board.trace.writing_height", "lucian.trace.cuff", "T01_board.doc.anachronism", "T01_board.trace.prosody", "lucian.trace.blue_chalk"],
    set: { "T01_case.infer.poem_attributed_to_lucian": true } }],
  ["expose_poem", "T01", 2, "当众指出写诗造假证据", { with: ["lucian", "quer", "gu"], reveal: ["T01_case.infer.poem_attributed_to_lucian"],
    say: [["detective", "亚历山大体十四行，六加六音节，ABBA ABBA CCDEED——远古先知可写不出三百年后的格律。"],
      ["detective", "起笔高一百七十六厘米，正合你的抬臂；袖口这抹普鲁士蓝，卢西安，粉笔灰还没拍掉。"]] }],
  ["laugh", "T01", 3, "笑谈批注", { after: ["d1.demon.annotate"] }],
  ["afternoon", "T01", 90, "阅读讲义、整理疑点"],
  ["make_supper", "F03", 45, "包饺子", { req: { "F03_meal.phys.ingredients_ready": true }, set: { "detective.phys.meal_work_done": true } }],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  ["tea", "F03", 15, "饮茶"],
  ["plan_tomorrow", "F03", 25, "提出开仓分工", { kind: "talk", with: ["huo", "margaret", "quer", "shen"],
    set: { "plan.doc.day2_granary": "风窗实测达标后，由霍铎、玛格丽特、雀儿协作开启B1粮仓；沈鼎核对补给" },
    say: [["detective", "明天风窗一开：玛格丽特测门扇，霍铎顶千斤顶，雀儿挑锁，沈师傅核对补给。"], ["margaret", "斜向卡死的门，我来算角度。"]] }],
  ["wash_night", "R05", 10, "洗漱"],
  ["night_notes", "R05", 60, "记录首日备忘"],
  ["sleep", "R05", 1, "上床入睡", { earliest: T(1, 21, 30) }],
]);
ag("lucian", 1, [
  ["wake", "R01", 1, "醒来：佩剑崩口", { earliest: T(1, 7, 3) }],
  ["inspect_sword", "R01", 3, "察看佩剑崩口", { reveal: ["A_pipe.trace.observation"] }],
  ["mediate", "A-P", 5, "在甲区劝架", { after: ["d1.ward.accuse"], say: [["lucian", "二位且慢！拔剑之前，先听我一言——"]] }],
  ["join", "2F-cross-M", 3, "通过已开区门到中翼汇合"],
  ["wait_meeting", "2F-cross-M", 1, "等候岛务汇合", { after: ["d1.detective.briefing"] }],
  ["conceive", "2F-cross-M", 40, "构思诗句、反复推敲"],
  ["write_poem", "T01", 20, "独自在黑板上写诗", { set: { "T01_board.phys.written": true, "lucian.trace.cuff": "右袖有新鲜的普鲁士蓝粉笔灰" } }],
  ["claim_poem", "2F-cross-M", 2, "宣称发现神谕", { set: { "T01_board.phys.claimed": true, "T01_board.doc.claimed_oracle": "卢西安声称黑板上出现远古先知的灭世神谕" },
    say: [["lucian", "诸位！讲堂黑板上——凭空出现了远古先知的灭世神谕！"]] }],
  ["recite", "2F-cross-M", 6, "当众朗诵“神谕”", { say: [["lucian", "Le feu dort sous nos pas ; le vent mord nos grands murs."], ["lucian", "火睡在我们脚下，风咬着高墙……"]] }],
  ["guard_board", "T01", 1, "守在黑板前", { after: ["d1.detective.expose_poem"] }],
  ["confess", "T01", 1, "当众认账", { set: { "lucian.doc.confession": "黑板诗是我刚写的", "T01_case.infer.author_confessed": true },
    say: [["lucian", "……好吧好吧！是我写的。可这诗难道不美吗？"]] }],
  ["laugh", "T01", 2, "自嘲", { after: ["d1.demon.annotate"] }],
  ["afternoon", "T01", 90, "在讲堂翻阅《巴黎圣母院》"],
  ["set_table", "F03", 20, "帮忙摆碗筷", { req: { "meal_day1.doc.invited": true, "F03_meal.phys.ingredients_ready": true } }],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  sleep(1, "lucian", 22, 10),
]);
ag("gu", 1, [
  ["wake", "R02", 1, "醒来：拓片浸水", { earliest: T(1, 7, 4) }],
  ["rescue_rubbing", "R02", 6, "抢救浸水拓片", { reveal: ["A_basin.trace.observation"] }],
  ["join", "2F-cross-M", 3, "到中翼汇合"],
  ["wait_meeting", "2F-cross-M", 1, "等候岛务汇合", { after: ["d1.detective.briefing"] }],
  ["copy_pillar", "2F-cross-M", 40, "抄录中央石柱铭文"],
  ["visit_poem", "T01", 3, "去讲堂看“神谕”", { req: { "T01_board.phys.claimed": true } }],
  ["laugh", "T01", 2, "笑出声来", { after: ["d1.demon.annotate"], set: { "gu.doc.poem_laughter": true },
    say: [["gu", "哈哈哈！三百年后的戏文冒充远古神谕，老夫考据半生，头一回见！"]] }],
  ["afternoon", "T01", 80, "考订诗中典故"],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  sleep(1, "gu", 21, 40),
]);
ag("quer", 1, [
  ["wake", "R03", 1, "醒来：手腕压痕红肿", { earliest: T(1, 7, 3) }],
  ["check_probes", "R03", 1, "确认探针卷"],
  ["rub_wrist", "A-P", 2, "揉手腕"],
  ["inspect_vent", "A-P", 3, "察看检修铁篦", { reveal: ["A_vent.trace.observation"] }],
  ["remove_grate", "A-P", 8, "拆开通风篦"],
  ["recover_map", "A-P", 7, "从夹层取出管网图", { set: { "service_map.doc.route": true } }],
  ["invite", "A-P", 3, "说明图纸路线", { say: [["quer", "图上画着勤务暗井，能从夹层下到中翼——我先去把外面的插销拔了！"]] }],
  ["test_air", "2F-cross-M", 5, "读取通路检测面板", { set: { "corridor_2F.phys.test_clear": true } }],
  ["outside_a", "2F-cross-M", 5, "拔开甲区外插销", { set: { "A_gate.lock.external_ready": true } }],
  ["outside_b", "2F-cross-M", 8, "拆下乙区外锁盖板", { set: { "B_gate.lock.external_ready": true },
    say: [["quer", "（隔门）喂——里面的侦探先生！外锁盖板我拆了，剩下的得你们从里面来。"]] }],
  ["outside_d", "2F-cross-M", 7, "拨开丁区保险销", { set: { "D_gate.lock.pin_released": true } }],
  ["watch_panel", "2F-cross-M", 60, "守着通路检测面板"],
  ["wait_meeting", "2F-cross-M", 1, "等候岛务汇合", { after: ["d1.detective.briefing"] }],
  ["relax", "2F-cross-M", 1, "放松警戒", { after: ["d1.ward.resolve"] }],
  ["visit_poem", "T01", 3, "去讲堂看“神谕”", { req: { "T01_board.phys.claimed": true } }],
  ["report_chalk", "T01", 1, "说明蓝粉笔目击", { after: ["d1.detective.inspect_height"], reveal: ["lucian.trace.blue_chalk"],
    say: [["quer", "今早我在甲区走廊，看见他口袋里揣着半截蓝粉笔！"]] }],
  ["laugh", "T01", 2, "打趣卢西安", { after: ["d1.demon.annotate"], say: [["quer", "“第七行平仄失调”——哈！连代管者都给你批卷子了！"]] }],
  ["afternoon", "T01", 60, "整理探针"],
  ["skins", "F03", 10, "擀第一批饺子皮", { req: { "F03_meal.phys.ingredients_ready": true }, set: { "quer.phys.first_skins": true } }],
  ["eat_supper", "F03", 36, "吃团圆饺子", cooked],
  ["listen_plan", "F03", 1, "听取开仓分工", { after: ["d1.detective.plan_tomorrow"] }],
  sleep(1, "quer", 21, 50),
]);
ag("ward", 1, [
  ["wake", "R04", 1, "醒来：手铐被打开", { earliest: T(1, 7, 1) }],
  ["inspect_cuffs", "R04", 3, "检查被打开的手铐", { reveal: ["A_cuffs.trace.observation"] }],
  ["accuse", "A-P", 3, "当众质问雀儿", { with: ["quer"], say: [["ward", "钥匙呢？昨夜谁碰过我的手铐？——你，小贼！"], ["quer", "看清楚我手腕上的压痕！我自己也被铐着！"]] }],
  ["open_a", "A-P", 2, "退开甲区内闩", { req: { "A_gate.lock.external_ready": true } }],
  ["pull_a", "A-P", 1, "拉开甲区大门", { set: { "A_gate.lock.open": true } }],
  ["join", "2F-cross-M", 3, "到中翼汇合"],
  ["wait_meeting", "2F-cross-M", 1, "等候四区汇合", { after: ["d1.detective.compare"] }],
  ["resolve", "2F-cross-M", 1, "放下对雀儿的指控", { after: ["d1.detective.show_account"], kind: "talk", set: { "ward.doc.accusation_dropped": true },
    say: [["ward", "……是我错怪她了。"]] }],
  ["afternoon", "2F-cross-M", 90, "整理甲区记录"],
  ["wrap", "F03", 30, "包饺子", { req: { "F03_meal.phys.ingredients_ready": true }, set: { "ward.phys.meal_work_done": true } }],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  sleep(1, "ward", 22, 0),
]);
ag("huo", 1, [
  ["wake", "R06", 1, "醒来：满手机油", { earliest: T(1, 7, 2) }],
  ["soap", "R06", 1, "拿起皂角"],
  ["wash", "B-P", 3, "在水槽洗净机油"],
  ["turn_handle", "B-P", 1, "转动门把", { reveal: ["B_gate.trace.observation"], say: [["huo", "门锁反扣了，副栓卡在二档……我工具包里怎么有曲柄销？"]] }],
  ["share", "B-P", 1, "向同区同伴说明所见", { with: ["detective"], reveal: ["B_gate.trace.observation"] }],
  ["insert_pin", "B-P", 4, "插回曲柄销", { req: { "B_gate.lock.external_ready": true }, know: ["B_case.infer.sequence_supported"] }],
  ["release_ratchet", "B-P", 6, "卸除棘轮反扣"],
  ["open_b", "B-P", 5, "退回二档副栓"],
  ["pull_b", "B-P", 1, "拉开乙区大门", { set: { "B_gate.lock.open": true }, say: [["huo", "开了！"]] }],
  ["outside_c", "2F-cross-M", 8, "顶起丙区外偏心轮", { set: { "C_gate.lock.external_ready": true }, say: [["huo", "（敲门）丙区！外面的偏心轮顶起来了，里面拨内闩！"]] }],
  ["outside_d", "2F-cross-M", 5, "扳开丁区外闩", { req: { "D_gate.lock.pin_released": true }, set: { "D_gate.lock.external_ready": true } }],
  ["report_crust", "2F-cross-M", 1, "向玛格丽特说明采样孔残环", { with: ["margaret"] }],
  ["wait_meeting", "2F-cross-M", 1, "等候岛务汇合", { after: ["d1.detective.briefing"] }],
  ["inspect_heat", "F03", 10, "检查暖气", { set: { "F03_hall.phys.fault_seen": true } }],
  ["repair_heat", "F03", 25, "维修暖气", { set: { "F03_hall.phys.warm": true } }],
  ["afternoon", "F03", 90, "检修灶台风门、整理工具"],
  ["tend_stove", "F03", 45, "照看炉火", { req: { "F03_meal.phys.ingredients_ready": true } }],
  ["eat_supper", "F03", 38, "吃团圆饺子", cooked],
  ["listen_plan", "F03", 1, "听取开仓分工", { after: ["d1.detective.plan_tomorrow"] }],
  sleep(1, "huo", 21, 45),
]);
ag("shen", 1, [
  ["wake", "R07", 1, "醒来：口渴又湿了衣袖", { earliest: T(1, 7, 1) }],
  ["wash", "B-P", 2, "饮水洗脸"],
  ["notice_cloth", "B-P", 1, "察看挂钩湿布", { kind: "inspect", reveal: ["B_kitchen.trace.observation"] }],
  ["share", "B-P", 1, "向同区同伴说明所见", { with: ["detective"], reveal: ["B_kitchen.trace.observation"],
    say: [["shen", "挂钩上那块麻布还在滴水，不知道谁挂回去的。"]] }],
  ["boil_water", "B-P", 5, "烧一壶热水", { set: { "shen.phys.water_boiled": true } }],
  ["stocktake", "F05", 20, "清点热厨库存", { kind: "inspect", set: { "F05_kitchen.phys.counted": true },
    reveal: ["F05_kitchen.phys.flour_kg", "F05_kitchen.phys.pork_kg", "F05_kitchen.phys.cabbage_kg", "F05_kitchen.phys.coal_kg"] }],
  ["knead", "F05", 30, "和面", { set: { "F05_kitchen.phys.dough_kg": 3, "F05_kitchen.phys.flour_kg": 0.5 } }],
  ["rest", "F05", 60, "看着面团醒发"],
  ["invite", "F05", 2, "听见讲堂的笑声，邀大家一起包饺子", { req: { "gu.doc.poem_laughter": true, "T01_case.infer.author_confessed": true },
    set: { "meal_day1.doc.invited": true }, tell: HUMANS, say: [["shen", "（传声管）都别愣着了！面已经醒好——今晚包饺子，十六个人一起吃！"]] }],
  ["mince", "F05", 40, "剁猪肉白菜馅"],
  ["divide_dough", "F05", 10, "分剂子", { earliest: T(1, 16, 30) }],
  ["serve", "F05", 5, "把面剂与馅料端上餐桌", { set: { "F03_meal.phys.ingredients_ready": true } }],
  ["boil", "F03", 25, "煮饺子", { req: { "quer.phys.first_skins": true, "margaret.phys.first_skins": true, "ruan.phys.first_skins": true,
    "detective.phys.meal_work_done": true, "ward.phys.meal_work_done": true },
    set: { "F03_meal.phys.cooked": true, "F03_meal.phys.dumplings": 320, "F05_kitchen.phys.pork_kg": 0, "F05_kitchen.phys.cabbage_kg": 0,
      "F05_kitchen.phys.dough_kg": 0, "F05_kitchen.phys.coal_kg": 2 },
    say: [["shen", "三百二十只，一只不少——开饭！"]] }],
  ["eat_supper", "F03", 40, "吃团圆饺子"],
  ["listen_plan", "F03", 1, "听取开仓分工", { after: ["d1.detective.plan_tomorrow"] }],
  sleep(1, "shen", 22, 20),
]);
ag("su", 1, [
  ["wake", "R08", 1, "醒来：耳鸣畏寒", { earliest: T(1, 7, 2) }],
  ["inspect_string", "R08", 3, "察看断弦琴盒", { reveal: ["su_instrument.trace.observation"] }],
  ["share", "B-P", 1, "向同区同伴说明所见", { with: ["detective"], reveal: ["su_instrument.trace.observation"],
    say: [["su", "琴盒里的黄铜高音弦断了……袖子也破了。昨夜的事，我一点都不记得。"]] }],
  ["ask_gap", "B-P", 1, "追问门底缝隙", { after: ["d1.detective.tell_su"], set: { "su.phys.gap_question": "若门会回弹，门底缝隙后来怎么处理？" },
    say: [["su", "若门会回弹……门底的缝隙，后来是怎么处理的？"]] }],
  ["warm_drink", "B-P", 3, "灶边烤火喝温水", { req: { "shen.phys.water_boiled": true } }],
  ["rest_b", "B-P", 120, "在乙区灶边烤火休息"],
  ["join", "2F-cross-M", 3, "到中翼汇合"],
  ["tune", "R08", 120, "回房调音", { after: ["d1.detective.briefing"] }],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  sleep(1, "su", 21, 20),
]);
ag("selma", 1, [
  ["wake", "R09", 1, "被呼救声惊醒", { earliest: T(1, 7, 6) }],
  ["seek_elena", "R11", 3, "循呼救去看伊莲娜", { req: { "hall_sound.phys.elena_help": true }, with: ["elena"], kind: "talk",
    say: [["selma", "别动，让我看看你的脚踝——"]] }],
  ["support", "C-P", 5, "扶伊莲娜到公共厅坐下", { with: ["elena"] }],
  ["join", "2F-cross-M", 3, "到中翼汇合"],
  ["afternoon", "C-P", 150, "整理标本盒", { after: ["d1.detective.briefing"] }],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  sleep(1, "selma", 21, 55),
]);
ag("ruan", 1, [
  ["wake", "R10", 1, "醒来：掌心铜屑勒痛", { earliest: T(1, 7, 4) }],
  ["wash", "C-P", 3, "洗净伤手"],
  ["scene", "C-P", 3, "复盘丙区现场", { reveal: ["C_gate.trace.observation"] }],
  ["open_c", "C-P", 2, "拨开丙区内闩", { req: { "C_gate.lock.external_ready": true } }],
  ["pull_c", "C-P", 1, "拉开丙区大门", { set: { "C_gate.lock.open": true }, say: [["ruan", "多谢。棋盘上，先手往往在门外。"]] }],
  ["join", "2F-cross-M", 3, "到中翼汇合"],
  ["wait_meeting", "2F-cross-M", 1, "等候四区汇合", { after: ["d1.detective.compare"] }],
  ["afternoon", "2F-cross-M", 120, "独自复盘棋谱", { after: ["d1.detective.briefing"] }],
  ["skins", "F03", 10, "擀饺子皮", { req: { "F03_meal.phys.ingredients_ready": true }, set: { "ruan.phys.first_skins": true } }],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  sleep(1, "ruan", 22, 40),
]);
ag("elena", 1, [
  ["wake", "R11", 1, "醒来：左踝剧痛", { earliest: T(1, 7, 4) }],
  ["call_help", "R11", 2, "呼救", { set: { "hall_sound.phys.elena_help": true }, tell: ["selma", "ruan", "moran"], say: [["elena", "谁来……我的脚踝！"]] }],
  ["wait_help", "R11", 1, "倒在床边等人来", { after: ["d1.selma.seek_elena"] }],
  ["helped_out", "C-P", 5, "被扶到公共厅坐下"],
  ["to_infirmary", "1F-Infirmary", 1, "到临时医疗角等候诊治", { kind: "rest" }],
  ["after_treatment", "1F-Infirmary", 30, "伤踝已固定，静坐休息", { after: ["d1.mora.treat_elena"], set: { "elena.phys.treated": true } }],
  ["afternoon", "C-P", 120, "在丙区公共厅静坐"],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  sleep(1, "elena", 21, 0),
]);
ag("moran", 1, [
  ["wake", "R12", 1, "醒来：手腕粗绳勒伤", { earliest: T(1, 7, 8) }],
  ["untie", "R12", 5, "解开手腕粗绳、寻找镇纸"],
  ["scene", "C-P", 3, "察看丙区高窗", { reveal: ["C_gate.trace.observation"] }],
  ["join", "2F-cross-M", 3, "到中翼汇合"],
  ["sketch", "2F-cross-M", 150, "速写中翼穹顶"],
  ["copy_poem", "T01", 120, "在讲堂临摹黑板诗", { after: ["d1.demon.annotate"] }],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  sleep(1, "moran", 22, 30),
]);
ag("veronica", 1, [
  ["wake", "R13", 1, "醒来：衣摆被酸液蚀破", { earliest: T(1, 7, 5) }],
  ["seal_bottle", "R13", 5, "封存漏酸药瓶"],
  ["warn", "D-P", 2, "警示同区勿碰酸液"],
  ["join", "2F-cross-M", 3, "到中翼汇合"],
  ["wait_meeting", "2F-cross-M", 1, "等候岛务汇合", { after: ["d1.detective.briefing"] }],
  ["afternoon", "R13", 150, "在实验台记录药瓶批号"],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  sleep(1, "veronica", 22, 15),
]);
ag("bertrand", 1, [
  ["wake", "R14", 1, "醒来：前臂灼烧刺痛", { earliest: T(1, 7, 5) }],
  ["call_help", "D-P", 2, "呼救", { say: [["bertrand", "茉拉！我的胳膊——是酸！"]] }],
  ["to_infirmary", "1F-Infirmary", 1, "到临时医疗角等候换药", { kind: "rest" }],
  ["after_treatment", "1F-Infirmary", 20, "灼伤已敷药，静坐", { after: ["d1.mora.dress_burn"], set: { "bertrand.phys.treated": true } }],
  ["afternoon", "2F-cross-M", 150, "在中翼帮忙搬运"],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  sleep(1, "bertrand", 21, 30),
]);
ag("margaret", 1, [
  ["wake", "R15", 1, "醒来：虎口震麻", { earliest: T(1, 7, 3) }],
  ["rest_hand", "R15", 4, "坐下揉手"],
  ["scene", "D-P", 3, "勘察丁区门框", { reveal: ["D_gate.trace.observation"] }],
  ["open_d", "D-P", 2, "拨开丁区内闩", { req: { "D_gate.lock.external_ready": true } }],
  ["pull_d", "D-P", 1, "拉开丁区大门", { set: { "D_gate.lock.open": true } }],
  ["join", "2F-cross-M", 3, "到中翼汇合"],
  ["wait_meeting", "2F-cross-M", 1, "等候四区汇合", { after: ["d1.detective.compare"] }],
  ["repair_table", "F03", 20, "修好餐桌", { after: ["d1.detective.briefing"] }],
  ["afternoon", "F03", 90, "测绘一楼大食堂"],
  ["skins", "F03", 10, "擀饺子皮", { req: { "F03_meal.phys.ingredients_ready": true }, set: { "margaret.phys.first_skins": true } }],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  ["listen_plan", "F03", 1, "听取开仓分工", { after: ["d1.detective.plan_tomorrow"] }],
  sleep(1, "margaret", 22, 5),
]);
ag("mora", 1, [
  ["wake", "R16", 1, "醒来", { earliest: T(1, 7, 2) }],
  ["prepare", "R16", 4, "备药"],
  ["first_aid", "D-P", 10, "为贝尔特朗冲洗灼伤", { with: ["bertrand"] }],
  ["treat_elena", "1F-Infirmary", 30, "固定伊莲娜伤踝", { with: ["elena"], say: [["mora", "忍一下，夹板要绑紧。"]] }],
  ["dress_burn", "1F-Infirmary", 20, "为贝尔特朗清创换敷料", { with: ["bertrand"] }],
  ["afternoon", "1F-Infirmary", 120, "整理临时医疗角"],
  ["eat_supper", "F03", 40, "吃团圆饺子", cooked],
  sleep(1, "mora", 22, 25),
]);
ag("demon", 1, [
  ["answer", "D-gate", 1, "通过传声管答复询问", { req: { "steward_request.phys.requested": true }, tell: ["detective"],
    set: { "steward.doc.reply_day1_noon": "导师位于四锚座维持正压；B1及外院尚未达风窗阈值，预计第二日开放" },
    say: [["demon", "（传声管）侦探先生日安。导师们正在四锚座维持正压；B1及外院尚未达风窗阈值——依第九条，预计明日开放。"]] }],
  ["visit_board", "T01", 1, "悄然来到讲堂", { req: { "T01_board.phys.claimed": true }, kind: "move" }],
  ["read_poem", "T01", 2, "阅读黑板诗", { show: true, kind: "read" }],
  ["annotate", "T01", 1, "在黑板边写下批注", { req: { "lucian.doc.confession": "黑板诗是我刚写的" }, show: true, kind: "talk",
    set: { "T01_board.doc.steward_comment": "第七行平仄失调，第十一行意象尚可；卢西安学员已承认亲笔所作。——代管者谨注" },
    say: [["demon", "（白手套轻叩黑板）第七行平仄失调，第十一行意象尚可。——代管者谨注。"]] }],
  ["leave_board", "D-gate", 1, "回到丁区边界门", { kind: "move" }],
]);

// ═════════════════════ 第二日 · 风窗之约（开仓与四院） ═════════════════════
ag("detective", 2, [
  wake(2, "detective", 0, "醒来，确认身处自己的卧室"), care("detective"),
  ["inspect_wind", "1F-Shaft-Monitor", 3, "读取压差、风窗时段与四院接驳登记图", { reveal: ["wind_window.doc.schedule", "academy.doc.registry"] }],
  ["inspect_granary", "U01-granary", 5, "核对门槛、锁针与复位绞盘的相互位置", { reveal: ["granary.trace.stuck_door"] }],
  ["read_inventory", "U01-granary", 4, "按封签点验粮药清册", { req: { "granary.lock.picked": true }, reveal: ["granary.doc.inventory"] }],
  ["read_ration_terms", "F03", 4, "逐项比较在册份额与热厨领用记录", { reveal: ["ration.doc.terms"] }],
  ["deduce_ration", "F03", 3, "脑内推演：三人开仓与等额热餐可以同时成立", { know: ["granary.doc.inventory", "ration.doc.terms", "plan.doc.day2_granary"],
    set: { "detective.infer.dual_ration": true }, say: [["detective", "份额照册等额签收，烹煮集中到热厨——两件事并不冲突。"]] }],
  ["persuade_ward", "F03", 2, "向沃德提议保留签收定额、由热厨集中烹煮", { with: ["ward"], set: { "ward.doc.ration_agreed": true },
    say: [["detective", "签收定额照旧，只是统一下锅。账，您来记。"], ["ward", "……只要账目清楚，我没有异议。"]] }],
  ["persuade_shen", "F03", 2, "请沈鼎按签收份额供餐，并保留伤员代领", { with: ["shen"], set: { "shen.doc.ration_agreed": true, "ration.policy.mediated": true },
    say: [["shen", "按份下锅，伤员那份我留着——成！"]] }],
  ["secure_probes", "F03", 2, "建议雀儿把探针封入本人保管的工具卷", { with: ["quer"], set: { "quer.doc.probes_sealed": true } }],
  ["kitchen_audit", "F03", 30, "与沈鼎核对热厨领用新规", { with: ["shen"], kind: "talk" }],
  ["notes", "F03", 20, "记录配给协议"],
  ["seal_medical_records", "F03", 2, "建议维罗妮卡把验药记录逐页编号封存", { with: ["veronica"], set: { "veronica.doc.records_sealed": true } }],
  lunch(2),
  ["inspect_W102", "W-102", 5, "比对纸样、刮痕示例与借阅牌的授权范围", { reveal: ["academy_W.trace.paper"] }],
  ["inspect_B102", "B-102", 5, "查看空瓶封口、量具与未配制的药剂标签", { reveal: ["academy_B.trace.vials"] }],
  ["inspect_F104", "F-104", 5, "量看止动销、棘齿样件与专用工具尺寸", { reveal: ["academy_F.trace.parts"] }],
  ["inspect_S102", "S-102", 5, "核对仪器零点、记录时刻与压差对照表", { reveal: ["academy_S.trace.instruments"] }],
  ["read_academy_reports", "2F-cross-M", 3, "逐份核对四位巡检者的签名与资源限制", { reveal: ["academy.doc.reports"] }],
  ["deduce_academy", "2F-cross-M", 4, "脑内推演：四院现场与资源使用边界", {
    know: ["academy.doc.registry", "academy_W.trace.paper", "academy_B.trace.vials", "academy_F.trace.parts", "academy_S.trace.instruments", "academy.doc.reports"],
    set: { "detective.infer.academy_resource_limits": true } }],
  ["afternoon", "T01", 120, "在讲堂整理四院笔记"],
  supper(2), ["evening", "R05", 60, "誊写案记"], sleep(2, "detective", 21, 30),
]);
ag("margaret", 2, [wake(2, "margaret", 3), care("margaret"),
  ["measure", "U01-granary", 10, "测算斜向卡死的门扇", { req: { "wind_window.phys.open": true }, set: { "granary.doc.measured": true },
    say: [["margaret", "门扇偏了四度，沉降在铰链侧——从左下角顶。"]] }],
  ["guide", "U01-granary", 40, "指导矫正沉降石门"], lunch(2, 10),
  ["afternoon", "F03", 180, "绘制粮仓门扇矫正图"], supper(2, 5), sleep(2, "margaret", 22, 0)]);
ag("huo", 2, [wake(2, "huo", 2), care("huo"),
  ["prep_jack", "U01-granary", 30, "在粮仓门前架设千斤顶"],
  ["brace", "U01-granary", 15, "千斤顶复位门扇", { after: ["d2.margaret.measure"], set: { "granary.phys.structure_braced": true } }],
  ["repair_hinge", "U01-granary", 40, "加固铰链"], lunch(2, 5),
  ["afternoon", "F04", 180, "修理配膳台的升降架"], supper(2, 10), sleep(2, "huo", 21, 45)]);
ag("quer", 2, [wake(2, "quer", 3), care("quer"),
  ["wait_brace", "U01-granary", 1, "在粮仓门前候着", { kind: "rest" }],
  ["pick", "U01-granary", 15, "挑开双栓重锁", { req: { "granary.phys.structure_braced": true }, set: { "granary.lock.picked": true },
    say: [["quer", "咔哒——双栓都开了。"]] }],
  ["tidy_tools", "U01-granary", 40, "整理开仓工具"],
  ["register", "F03", 15, "在食堂登记探针"], lunch(2, 15),
  ["afternoon", "A-P", 180, "在甲区修补门闩"], supper(2, 15), sleep(2, "quer", 21, 50)]);
ag("shen", 2, [wake(2, "shen", 1), care("shen"),
  ["breakfast", "F05", 60, "备早饭"],
  ["supply", "U01-granary", 10, "核对补给", { after: ["d2.quer.pick"], set: { "granary.doc.supply_checked": true } }],
  ["cook_lunch", "F03", 120, "按份备午饭"], lunch(2, 20),
  ["afternoon", "F05", 200, "熬汤、点验煤饼"], supper(2), sleep(2, "shen", 22, 20)]);
ag("ward", 2, [wake(2, "ward", 1), care("ward"),
  ["ration_desk", "F03", 120, "监督配给登记", { earliest: T(2, 9, 30) }], lunch(2, 30),
  ["afternoon", "2F-cross-M", 180, "核对甲区账目"], supper(2), sleep(2, "ward", 22, 0)]);
ag("veronica", 2, [wake(2, "veronica", 5), care("veronica"),
  ["white_tower", "B-102", 90, "清点白塔院药剂", { req: { "wind_window.phys.open": true } }],
  ["register", "F03", 20, "登记验药记录", { earliest: T(2, 11, 45) }], lunch(2, 25),
  ["afternoon", "B-102", 180, "在白塔院比对试剂"], supper(2), sleep(2, "veronica", 22, 15)]);
const simpleDay = (d: number, a: string, wm: number, morning: B, afternoon: B, sh: number, sm: number) =>
  ag(a, d, [wake(d, a, wm), care(a), morning, lunch(d, (wm * 3) % 30), afternoon, supper(d, wm % 15), sleep(d, a, sh, sm)]);
simpleDay(2, "lucian", 3, ["morning", "T01", 150, "朗读《堂吉诃德》"], ["afternoon", "2F-cross-M", 180, "与顾平章争论诗律"], 22, 10);
simpleDay(2, "gu", 4, ["morning", "W-102", 150, "在文契院查阅岛志", { req: { "wind_window.phys.open": true } }], ["afternoon", "W-102", 180, "拓印碑文"], 21, 40);
simpleDay(2, "su", 2, ["morning", "R08", 150, "换上新弦调音"], ["afternoon", "T01", 180, "在讲堂试奏"], 21, 20);
simpleDay(2, "selma", 6, ["morning", "S-102", 150, "在星仪院整理标本", { req: { "wind_window.phys.open": true } }], ["afternoon", "C-P", 180, "照看伊莲娜"], 21, 55);
simpleDay(2, "ruan", 4, ["morning", "R10", 150, "独自打谱"], ["afternoon", "2F-cross-M", 180, "旁观众人、暗记棋局"], 22, 40);
simpleDay(2, "elena", 4, ["morning", "C-P", 150, "静坐护踝"], ["afternoon", "C-P", 180, "做上肢练习"], 21, 0);
simpleDay(2, "moran", 8, ["morning", "2F-cross-M", 150, "写生开仓场面"], ["afternoon", "T01", 180, "整理画夹"], 22, 30);
simpleDay(2, "bertrand", 5, ["morning", "1F-Infirmary", 60, "复查灼伤"], ["afternoon", "F04", 180, "搬运粮袋"], 21, 30);
simpleDay(2, "mora", 2, ["morning", "1F-Infirmary", 150, "为伤员复查换药"], ["afternoon", "1F-Infirmary", 180, "清点医疗箱"], 22, 25);

// ═════════════════════ 第三日 · 倒脱靴（阮清月的试探） ═════════════════════
ag("ward", 3, [wake(3, "ward", 1), care("ward"),
  ["post_notice", "2F-cross-M", 5, "张贴当事人登记", { earliest: T(3, 7, 25), set: { "day3.doc.notice": "当事人登记：六份口粮被以旧签名领走，沃德指控有人冒领" },
    say: [["ward", "六份口粮，凭一张旧签名就领走了——我要一个交代。"]] }],
  ["attend", "T01", 1, "赴讲堂公开核证", { req: { "day3.doc.hearing_called": true }, kind: "rest" }],
  ["wait_verdict", "T01", 1, "听取推演", { after: ["d3.detective.persuade_ward_ration"], kind: "rest" }],
  lunch(3, 30), ["afternoon", "2F-cross-M", 180, "更正配给账"], supper(3), sleep(3, "ward", 22, 0)]);
ag("detective", 3, [wake(3, "detective", 0, "醒来，确认身处自己的卧室"), care("detective"),
  ["read_notice", "2F-cross-M", 2, "阅读当事人登记，区分指控与已观察到的事实", { req: { "day3.doc.notice": "当事人登记：六份口粮被以旧签名领走，沃德指控有人冒领" }, reveal: ["day3.doc.notice"] }],
  ["read_crate_log", "F03", 6, "对照空箱回收原账，询问沈鼎所见", { with: ["shen"], reveal: ["ration_crate.doc.log"] }],
  ["inspect_receipt", "F04", 6, "斜光检视新旧墨层，分开签名、正文与收件时间", { reveal: ["receipt.trace.ink_layers"] }],
  ["inspect_ration_draft", "R10", 3, "经阮清月同意，比对棋盘草稿中调动配给权的安排", { with: ["ruan"], reveal: ["ruan.doc.draft_ration"] }],
  ["deduce_ration_forgery", "R10", 3, "脑内推演：旧签名只认证空箱回收，收件时刻无法认证新授权", {
    know: ["day3.doc.notice", "ration_crate.doc.log", "receipt.trace.ink_layers", "ruan.doc.draft_ration"], set: { "detective.infer.ration_forgery": true } }],
  ["call_hearing", "R10", 2, "通过传声管召集配给授权公开核证", { set: { "day3.doc.hearing_called": true }, tell: HUMANS,
    say: [["detective", "（传声管）配给授权一事证据已备，请当事人到讲堂公开核证。"]] }],
  ["restore_rations", "T01", 2, "公开核证：要求归还六份口粮，撤销旧签名的新授权", { with: ["ruan", "ward", "shen"], set: { "rations.phys.restored": true },
    reveal: ["detective.infer.ration_forgery"],
    say: [["detective", "旧签名只认证过空箱回收；收件时间是后补的墨——它不能为新领取授权。六份口粮，请归还。"]] }],
  ["persuade_ward_ration", "T01", 2, "当面展示推演与已核实来源，请沃德更正记录", { with: ["ward"],
    set: { "ward.doc.record_corrected": true, "case_day3.phys.resolved": true }, say: [["ward", "……记录我会更正。"]] }],
  ["afternoon", "T01", 150, "整理三日案记"], lunch(3, 5),
  ["walk_academy", "S-102", 90, "在星仪院核对压差记录", { req: { "wind_window.phys.open": true } }],
  supper(3), ["evening", "R05", 60, "誊写案记"], sleep(3, "detective", 21, 30)]);
ag("ruan", 3, [wake(3, "ruan", 4), care("ruan"),
  ["draft", "R10", 60, "在棋盘前推演"],
  ["attend", "T01", 1, "赴讲堂公开核证", { req: { "day3.doc.hearing_called": true }, kind: "rest" }],
  ["admit", "T01", 2, "承认试探", { after: ["d3.detective.restore_rations"], set: { "ruan.doc.test_admitted": true },
    say: [["ruan", "这一手“倒脱靴”是我布的——想看看谁会先弃子。侦探先生，你没有。"]] }],
  lunch(3, 12), ["afternoon", "R10", 180, "复盘被识破的棋局"], supper(3, 4), sleep(3, "ruan", 22, 40)]);
ag("shen", 3, [wake(3, "shen", 1), care("shen"),
  ["breakfast", "F03", 60, "在大食堂备早饭"],
  ["attend", "T01", 1, "赴讲堂公开核证", { req: { "day3.doc.hearing_called": true }, kind: "rest" }],
  ["wait_verdict", "T01", 1, "听取推演", { after: ["d3.detective.restore_rations"], kind: "rest" }],
  ["return_rations", "F05", 20, "把六份口粮放回热厨"], lunch(3, 20),
  ["afternoon", "F05", 180, "腌菜"], supper(3), sleep(3, "shen", 22, 20)]);
simpleDay(3, "lucian", 3, ["morning", "T01", 150, "写信"], ["afternoon", "2F-cross-M", 180, "练剑"], 22, 10);
simpleDay(3, "gu", 4, ["morning", "W-102", 150, "查阅岛志", { req: { "wind_window.phys.open": true } }], ["afternoon", "T01", 180, "讲授碑文"], 21, 40);
simpleDay(3, "quer", 3, ["morning", "A-P", 150, "修补门闩"], ["afternoon", "F-104", 180, "在铁工院打磨探针", { req: { "wind_window.phys.open": true } }], 21, 50);
simpleDay(3, "huo", 2, ["morning", "F-104", 150, "在铁工院锻打止动销", { req: { "wind_window.phys.open": true } }], ["afternoon", "B2-control", 180, "巡检低位阀路"], 21, 45);
simpleDay(3, "su", 2, ["morning", "R08", 150, "调音"], ["afternoon", "T01", 180, "排练"], 21, 20);
simpleDay(3, "selma", 6, ["morning", "S-102", 150, "整理标本", { req: { "wind_window.phys.open": true } }], ["afternoon", "C-P", 180, "照看伊莲娜"], 21, 55);
simpleDay(3, "elena", 4, ["morning", "C-P", 150, "静坐护踝"], ["afternoon", "R11", 180, "午睡"], 21, 0);
simpleDay(3, "moran", 8, ["morning", "2F-cross-M", 150, "写生"], ["afternoon", "B1-hazard", 180, "在B1服务廊写生"], 22, 30);
simpleDay(3, "veronica", 5, ["morning", "B-102", 150, "配制试剂", { req: { "wind_window.phys.open": true } }], ["afternoon", "R13", 180, "记录试剂"], 22, 15);
simpleDay(3, "bertrand", 5, ["morning", "F04", 150, "搬运粮袋"], ["afternoon", "B1-hazard", 180, "搬运煤饼"], 21, 30);
simpleDay(3, "margaret", 3, ["morning", "U01-granary", 150, "测量粮仓沉降"], ["afternoon", "F03", 180, "绘图"], 22, 5);
simpleDay(3, "mora", 2, ["morning", "1F-Infirmary", 150, "复查伤员"], ["afternoon", "1F-Infirmary", 180, "清点药品"], 22, 25);

// ═════════════════════ 第四日 · 第四夜（错规之祸） ═════════════════════
const strategy = (v: string[]) => ({ key: "night_day4.doc.strategy", values: v });
ag("detective", 4, [wake(4, "detective", 0, "醒来，确认身处自己的卧室"), care("detective"),
  ["read_seventh_clause", "B1-hazard", 4, "逐字核对危险牌上的第七条适用条件", { reveal: ["contract.doc.article7"] }],
  ["inspect_topology", "B2-control", 5, "顺着阀路图核对控制室、隔墙通口与低位阀廊", { reveal: ["valve.doc.topology"] }],
  ["check_tools", "B2-control", 3, "当面核对雀儿探针卷与霍铎的反扣扳手", { with: ["quer", "huo"], set: { "tools.doc.checked": true } }],
  ["check_rescue_stock", "1F-Infirmary", 3, "逐剂核验救援药品与夜间储备", { reveal: ["rescue_stock.doc.count"] }],
  ["watch_gauges", "B2-control", 120, "在B2控制室监看阀路压差"], lunch(4),
  ["afternoon", "B2-control", 60, "核对阀路图与交接记录", { earliest: T(4, 13) }],
  ["inspect_backflow", "B2-control", 0.5, "观察旁路回流与紧闭门扇，确定污染如何越界", { req: { "backflow.phys.active": true }, reveal: ["backflow.trace.bypass"] }],
  ["deduce_airlock", "B2-control", 2, "脑内推演：把闭合边界与污染旁路分别建模，限定短时封隔", {
    know: ["contract.doc.article7", "valve.doc.topology", "backflow.trace.bypass"], set: { "detective.infer.safe_airlock": true } }],
  ["seal_airlock", "B2-control", 0.5, "言灵：「闭合之门，不纳污息」", { kind: "incant", set: { "airlock.lock.sealed": true },
    expires: { after: 45, set: { "airlock.lock.sealed": false }, label: "言灵到期：气闸短时封隔解除" },
    say: [["detective", "——闭合之门，不纳污息。"]] }],
  ["plan_night", "B2-control", 1, "权衡工具、值守储备与同伴，拟定第四夜策略", { kind: "strategy", choice: {
    prompt: "言灵只能撑四十五分钟。第四夜如何守住低位阀？", auto: "lock",
    options: [
      { id: "lock", label: "雀儿与霍铎共同机械锁门", note: "正式回归记录采用的方案：趁短时封隔把低位阀廊机械锁死。", set: { "night_day4.doc.strategy": "lock" } },
      { id: "watch", label: "公开险情并组织轮值", note: "正道：如实告知全员，由玛格丽特与侦探轮流看守控制侧通口。", set: { "night_day4.doc.strategy": "watch" } },
      { id: "diversion", label: "虚构内务盘点把人留在室内", note: "巧计：请沃德以紧急盘点留人；次日真相会被识破。", set: { "night_day4.doc.strategy": "diversion" } },
      { id: "trap", label: "奇策：给伊莲娜戴耳罩坐阀门", note: "试探第七条——代管者只须“使其知情或移离”，并不会替你守夜。", set: { "night_day4.doc.strategy": "trap" } },
    ] } }],
  ["recruit_huo", "B2-control", 2, "请霍铎利用短时封隔协作锁门", { with: ["huo"], branch: strategy(["lock"]),
    say: [["detective", "霍铎，言灵撑不过四十五分钟——趁现在把阀廊锁死。"], ["huo", "反扣扳手在手，交给我。"]] }],
  ["recruit_quer", "B2-control", 2, "请雀儿利用短时封隔协作锁门", { with: ["quer"], branch: strategy(["lock"]),
    say: [["quer", "双栓我来上，保证从外面挑不开。"]] }],
  ["recruit_diversion", "B2-control", 2, "以紧急内务盘点请沃德把同伴留在安全室内", { branch: strategy(["diversion"]), tell: ["ward"],
    set: { "night_day4.doc.ward_called": true }, say: [["detective", "（传声管）沃德先生，今夜请务必把大家留在室内做一次紧急盘点。"]] }],
  ["recruit_watch", "B2-control", 2, "公开险情，请玛格丽特与自己轮流看守", { branch: strategy(["watch"]), tell: ["margaret"],
    set: { "night_day4.doc.margaret_called": true }, say: [["detective", "（传声管）低位阀倒灌，今夜谁都不许下B1。玛格丽特，与我轮值。"]] }],
  ["seek_elena", "R11", 3, "可选试探：探访伊莲娜", { branch: strategy(["trap"]), kind: "move" }],
  ["offer_earmuffs", "R11", 1, "借安静休息之名给伊莲娜戴上隔音耳罩", { with: ["elena"], branch: strategy(["trap"]), kind: "talk",
    set: { "elena.phys.earmuffs": true }, say: [["detective", "星仪院要测地板微振，劳驾戴上耳罩静坐片刻。"], ["elena", "……好。"]] }],
  ["escort_elena", "R11", 4, "搀扶不知具体险情的伊莲娜到低位阀旁", { with: ["elena"], branch: strategy(["trap"]) }],
  ["return_control", "B2-control", 1, "返回B2低位控制室", { branch: strategy(["trap"]), kind: "move" }],
  ["recruit_watch_after_trap", "B2-control", 2, "只得公开险情，请玛格丽特轮值", { branch: strategy(["trap"]), tell: ["margaret"],
    set: { "night_day4.doc.margaret_called": true } }],
  ["report_crisis", "B2-control", 3, "将抢险、值守安排与言灵到期限制写入交接记录", { kind: "work", set: { "night_day4.doc.report": true } }],
  supper(4, 20), ["evening", "R05", 40, "誊写案记"], sleep(4, "detective", 22, 0),
]);
ag("huo", 4, [wake(4, "huo", 2), care("huo"),
  ["repair_valve", "B2-control", 150, "检修低位阀路"], lunch(4, 5),
  ["afternoon", "B2-control", 280, "复核反扣扳手", { earliest: T(4, 13) }],
  ["lock_valve", "B2-valve", 20, "与雀儿机械锁死低位阀廊", { branch: strategy(["lock"]), after: ["d4.detective.recruit_huo", "d4.detective.recruit_quer"],
    set: { "night_day4.phys.secured": true }, say: [["huo", "锁死了。今夜谁也开不了这道门。"]] }],
  supper(4, 25), sleep(4, "huo", 22, 15)]);
ag("quer", 4, [wake(4, "quer", 3), care("quer"),
  ["probe_valve", "B2-control", 150, "整理探针卷"], lunch(4, 10),
  ["afternoon", "B2-control", 280, "检查探针卷与锁芯", { earliest: T(4, 13) }],
  ["assist_lock", "B2-valve", 20, "给低位阀廊上双栓", { branch: strategy(["lock"]), after: ["d4.detective.recruit_quer"] }],
  supper(4, 25), sleep(4, "quer", 22, 10)]);
ag("ward", 4, [wake(4, "ward", 1), care("ward"),
  ["morning", "2F-cross-M", 150, "更正配给账"], lunch(4, 30),
  ["afternoon", "F03", 270, "整理公约草案", { earliest: T(4, 13) }],
  ["false_inventory", "F03", 30, "以紧急盘点把同伴留在室内", { branch: strategy(["diversion"]), req: { "night_day4.doc.ward_called": true },
    set: { "night_day4.phys.secured": true, "night_day4.doc.false_inventory": true }, say: [["ward", "今晚全员盘点，谁也不许离开！"]] }],
  supper(4), sleep(4, "ward", 22, 0)]);
ag("margaret", 4, [wake(4, "margaret", 3), care("margaret"),
  ["morning", "U01-granary", 150, "复测粮仓沉降"], lunch(4, 10),
  ["afternoon", "F03", 270, "绘制避险路线图", { earliest: T(4, 13) }],
  ["night_watch", "B2-control", 30, "与侦探轮流看守控制侧通口", { branch: strategy(["watch", "trap"]), req: { "night_day4.doc.margaret_called": true },
    set: { "night_day4.phys.secured": true }, say: [["margaret", "上半夜我守。"]] }],
  supper(4, 5), sleep(4, "margaret", 22, 5)]);
ag("moran", 4, [wake(4, "moran", 8), care("moran"),
  ["morning", "2F-cross-M", 150, "写生"], lunch(4, 24),
  ["afternoon", "B1-hazard", 270, "在B1服务廊写生", { earliest: T(4, 13) }],
  ["to_infirmary", "1F-Infirmary", 1, "头晕发冷，去临时医疗角", { req: { "moran.phys.symptomatic": true }, kind: "rest" }],
  ["treated", "1F-Infirmary", 20, "服下缓冲剂后静卧", { after: ["d4.mora.rescue"] }],
  supper(4, 30), sleep(4, "moran", 22, 30)]);
ag("bertrand", 4, [wake(4, "bertrand", 5), care("bertrand"),
  ["morning", "F04", 150, "搬运粮袋"], lunch(4, 15),
  ["afternoon", "B1-hazard", 270, "搬运煤饼", { earliest: T(4, 13) }],
  ["to_infirmary", "1F-Infirmary", 1, "胸闷咳嗽，去临时医疗角", { req: { "bertrand.phys.symptomatic": true }, kind: "rest" }],
  ["treated", "1F-Infirmary", 20, "服下缓冲剂后静卧", { after: ["d4.mora.rescue"] }],
  supper(4, 30), sleep(4, "bertrand", 21, 30)]);
ag("mora", 4, [wake(4, "mora", 2), care("mora"),
  ["morning", "1F-Infirmary", 150, "复查伤员"], lunch(4, 6),
  ["afternoon", "1F-Infirmary", 270, "整理夜间储备", { earliest: T(4, 13) }],
  ["rescue", "1F-Infirmary", 30, "用夜间储备救治两名倒灌伤者", { with: ["moran", "bertrand"],
    set: { "moran.phys.cured": true, "bertrand.phys.cured": true }, say: [["mora", "吸入不深，缓冲剂来得及。躺好，别说话。"]] }],
  supper(4, 30), sleep(4, "mora", 22, 25)]);
ag("elena", 4, [wake(4, "elena", 4), care("elena"),
  ["morning", "C-P", 150, "静坐护踝"], lunch(4, 12),
  ["afternoon", "R11", 300, "在房中静养", { earliest: T(4, 13) }],
  supper(4, 10), sleep(4, "elena", 21, 0)]);
simpleDay(4, "lucian", 3, ["morning", "T01", 150, "朗读"], ["afternoon", "2F-cross-M", 270, "练剑"], 22, 10);
simpleDay(4, "gu", 4, ["morning", "W-102", 150, "查阅岛志", { req: { "wind_window.phys.open": true } }], ["afternoon", "T01", 270, "整理拓片"], 21, 40);
simpleDay(4, "shen", 1, ["morning", "F05", 150, "备饭"], ["afternoon", "F05", 270, "熬汤"], 22, 20);
simpleDay(4, "su", 2, ["morning", "R08", 150, "调音"], ["afternoon", "T01", 270, "排练"], 21, 20);
simpleDay(4, "selma", 6, ["morning", "S-102", 150, "整理标本", { req: { "wind_window.phys.open": true } }], ["afternoon", "C-P", 270, "照看伊莲娜"], 21, 55);
simpleDay(4, "ruan", 4, ["morning", "R10", 150, "打谱"], ["afternoon", "2F-cross-M", 270, "与卢西安下棋"], 22, 40);
simpleDay(4, "veronica", 5, ["morning", "B-102", 150, "配制缓冲剂", { req: { "wind_window.phys.open": true } }], ["afternoon", "R13", 270, "记录试剂"], 22, 15);

// ═════════════════════ 第五日 · 自主观察日 ═════════════════════
ag("detective", 5, [wake(5, "detective", 0, "醒来，确认身处自己的卧室"), care("detective"),
  ["review", "R05", 25, "翻阅五日案记"],
  ["deduce_case", "R05", 3, "脑内推演：五日案记归档", {
    know: ["B_case.infer.sequence_supported", "island_case.infer.history_correlated", "T01_case.infer.poem_attributed_to_lucian",
      "detective.infer.dual_ration", "detective.infer.ration_forgery", "detective.infer.safe_airlock"],
    set: { "case.doc.archived": "案记可以归档，人的下一步仍然开放" }, say: [["detective", "案记可以归档了。可人的下一步——仍然开放。"]] }],
  ["ask_steward", "1F-Shaft-Monitor", 1, "通过传声管询问代管者", { set: { "steward_request_d5.phys.requested": true },
    say: [["detective", "代管者，五日已过。契约之后，你还打算看着我们多久？"]] }],
  ["visit_infirmary", "1F-Infirmary", 20, "探望复查中的伤员"], lunch(5),
  ["afternoon", "T01", 180, "在讲堂读《暴风雨》"], supper(5), ["evening", "R05", 60, "写下第五日观察"], sleep(5, "detective", 22, 0)]);
ag("demon", 5, [["answer_d5", "D-gate", 1, "通过传声管答复", { req: { "steward_request_d5.phys.requested": true }, kind: "talk", tell: ["detective"],
  set: { "steward.doc.reply_day5": "第十二条的归乡期限未变；在那之前，诸位的下一步由诸位自己决定" },
  say: [["demon", "（传声管）第十二条的归乡期限未变。在那之前——诸位的下一步，由诸位自己决定。"]] }]]);
ag("mora", 5, [wake(5, "mora", 2), care("mora"),
  ["recheck", "1F-Infirmary", 15, "复查两名倒灌伤者", { earliest: T(5, 8), with: ["moran", "bertrand"], set: { "victims.phys.rechecked": true } }],
  ["morning", "1F-Infirmary", 120, "整理病历"], lunch(5, 6), ["afternoon", "R16", 180, "午后小憩、读书"], supper(5, 6), sleep(5, "mora", 22, 25)]);
for (const a of ["moran", "bertrand"]) {
  ag(a, 5, [wake(5, a, 5), care(a), ["recheck_wait", "1F-Infirmary", 1, "到临时医疗角复查", { after: ["d5.mora.recheck"], kind: "rest" }],
    lunch(5, 15), ["afternoon", a === "moran" ? "T01" : "F04", 180, a === "moran" ? "画下第四夜" : "搬运煤饼"], supper(5, 15), sleep(5, a, 22, 0)]);
}
simpleDay(5, "lucian", 3, ["morning", "T01", 150, "朗读《堂吉诃德》"], ["afternoon", "2F-cross-M", 180, "练剑"], 22, 10);
simpleDay(5, "gu", 4, ["morning", "W-102", 150, "查阅岛志", { req: { "wind_window.phys.open": true } }], ["afternoon", "T01", 180, "讲授碑文"], 21, 40);
simpleDay(5, "quer", 3, ["morning", "A-P", 150, "修补门闩"], ["afternoon", "F03", 180, "帮沈鼎劈柴"], 21, 50);
simpleDay(5, "ward", 1, ["morning", "2F-cross-M", 150, "起草生存公约"], ["afternoon", "F03", 180, "征询签名意见"], 22, 0);
simpleDay(5, "huo", 2, ["morning", "B2-control", 150, "复查阀廊锁"], ["afternoon", "F04", 180, "修理升降架"], 21, 45);
simpleDay(5, "shen", 1, ["morning", "F05", 150, "备饭"], ["afternoon", "F05", 180, "熬汤"], 22, 20);
simpleDay(5, "su", 2, ["morning", "R08", 150, "调音"], ["afternoon", "T01", 180, "为大家演奏"], 21, 20);
simpleDay(5, "selma", 6, ["morning", "C-P", 150, "整理标本"], ["afternoon", "C-P", 180, "照看伊莲娜"], 21, 55);
simpleDay(5, "ruan", 4, ["morning", "R10", 150, "打谱"], ["afternoon", "2F-cross-M", 180, "与侦探复盘"], 22, 40);
simpleDay(5, "elena", 4, ["morning", "C-P", 150, "静坐护踝"], ["afternoon", "T01", 180, "听苏泠演奏"], 21, 0);
simpleDay(5, "veronica", 5, ["morning", "R13", 150, "记录试剂"], ["afternoon", "1F-Infirmary", 180, "协助茉拉"], 22, 15);
simpleDay(5, "margaret", 3, ["morning", "F03", 150, "绘图"], ["afternoon", "U01-granary", 180, "复测粮仓"], 22, 5);

// ───────────────────────── 契约规则与世界事件 ─────────────────────────
const rules = [{
  id: "contract.7", article: "第七条", label: "具体险情知情判断：须使其知情或将其移离",
  guard: ["d4.detective.escort_elena"], when: { "elena.doc.hazard_known": false, "backflow.phys.active": true },
  by: "demon", showFor: 3, tell: ["detective", "elena"],
  set: { "elena.doc.hazard_known": true, "elena.doc.deception_discovered": true, "detective.infer.seventh_clause_limits": true, "elena.phys.earmuffs": false },
  say: [["demon", "侦探先生，伊莲娜学员对阀门倒灌毫不知情。依《契约》第七条，在下须使她知情——"],
    ["demon", "伊莲娜学员：低位阀正在倒灌源质，请勿靠近。"], ["demon", "知情之后，去留由己。在下不会替诸位整夜守门。"],
    ["elena", "……你要把我带到阀门底下？还让我戴着耳罩？"]] as [string, string][],
}];
const wind = (d: number): WorldEvent[] => [
  { id: `d${d}.wind_open`, at: T(d, 9), label: "09:00 风窗开放：压差实测达标，四院接驳廊可通行（第九条）", set: { "wind_window.phys.open": true } },
  { id: `d${d}.wind_close`, at: T(d, 17), label: "17:00 风窗关闭：接驳廊联锁落下", set: { "wind_window.phys.open": false } },
];
const events: WorldEvent[] = [
  ...wind(2), ...wind(3), ...wind(4), ...wind(5),
  { id: "d4.microquake", at: T(4, 17, 30), label: "17:30 地板与灯具短促震颤，楼下传来金属碰响", set: { "island_environment.phys.earthquake": true }, tell: HUMANS },
  { id: "d4.backflow", at: T(4, 17, 30), label: "微震震松低位联锁阀：源质沿旁路倒灌，B1服务廊中的莫兰与贝尔特朗吸入毒雾",
    set: { "backflow.phys.active": true, "backflow.trace.bypass": "污染沿旁路回流，越过紧闭门扇", "moran.phys.symptomatic": true, "bertrand.phys.symptomatic": true },
    tell: ["moran", "bertrand"] },
  { id: "d5.autonomy", at: T(5, 0), label: "自主观察日：各人依据已经知道的事与自己的责任安排生活", set: { "autonomy.phase.active": true } },
];

// ───────────────────────── 核心剧情校验（含原工程回归记录对照） ─────────────────────────
const ex: Expectation[] = [];
let n = 0;
const E = (e: NewExpectation) => ex.push({ id: `e${++n}`, ...e } as Expectation);
const near = (day: number, beat: string, h: number, m: number, label: string, tol = 15) =>
  E({ day, type: "near", beat, t: T(day, h, m), tol, label: `${label}（回归记录 ${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")} ±${tol}′）` });
near(1, "d1.detective.deduce_drag", 7, 33, "推演拖回方向");
near(1, "d1.detective.deduce_sequence", 8, 8, "推演拖拽→湿布→锁止");
near(1, "d1.detective.deduce_fifth", 8, 41, "保留第五实体假说");
near(1, "d1.detective.deduce_records", 12, 35, "契约、录音与分时日志来源对照");
near(1, "d1.detective.deduce_poem", 14, 14, "讲堂诗稿作者证据");
E({ day: 1, type: "order", before: "d1.su.share", after: "d1.detective.inspect_closer", label: "三人说明所见后才检查闭门器" });
E({ day: 1, type: "order", before: "d1.su.ask_gap", after: "d1.detective.inspect_watermark", label: "苏泠追问门缝 → 勘查门槛水渍" });
E({ day: 1, type: "order", before: "d1.detective.report_b", after: "d1.huo.insert_pin", label: "霍铎得知先后顺序后才动锁（认知门控）" });
E({ day: 1, type: "order", before: "d1.quer.outside_a", after: "d1.ward.pull_a", label: "雀儿拔外插销 → 沃德开甲区" });
E({ day: 1, type: "order", before: "d1.quer.outside_b", after: "d1.huo.pull_b", label: "雀儿拆盖板 → 霍铎开乙区" });
E({ day: 1, type: "order", before: "d1.huo.outside_c", after: "d1.ruan.pull_c", label: "霍铎顶偏心轮 → 阮清月开丙区" });
E({ day: 1, type: "order", before: "d1.huo.outside_d", after: "d1.margaret.pull_d", label: "霍铎扳外闩 → 玛格丽特开丁区" });
E({ day: 1, type: "startAfter", beat: "d1.detective.compare", t: T(1, 11), label: "侦探首次离开乙区在上午11:00之后" });
E({ day: 1, type: "order", before: "d1.detective.read_monitor_log", after: "d1.detective.briefing", label: "读完分时日志才向同伴通报" });
E({ day: 1, type: "order", before: "d1.detective.show_account", after: "d1.ward.resolve", label: "看过钥匙记录，沃德才撤回指控" });
E({ day: 1, type: "order", before: "d1.lucian.write_poem", after: "d1.lucian.claim_poem", label: "先独自写诗，后宣称神谕" });
E({ day: 1, type: "order", before: "d1.detective.expose_poem", after: "d1.lucian.confess", label: "当众指证 → 卢西安认账" });
E({ day: 1, type: "order", before: "d1.lucian.confess", after: "d1.demon.annotate", label: "认账之后代管者才批注（字面真话）" });
E({ day: 1, type: "notKnows", actor: "detective", key: "night0.phys.truth", label: "侦探不全知：昨夜真相从未被直接告知" });
E({ day: 1, type: "notKnows", actor: "detective", key: "T01_board.phys.written", label: "侦探未目睹写诗，只能凭痕迹推断" });
E({ day: 1, type: "notKnows", actor: "detective", key: "reasoning.recalled_last_night", label: "失忆者不恢复昨夜记忆" });
E({ day: 1, type: "fact", key: "F03_meal.phys.dumplings", value: 320, by: T(1, 23, 59), label: "大食堂包出320只饺子" });
E({ day: 1, type: "fact", key: "F05_kitchen.phys.flour_kg", value: 0.5, by: T(1, 23, 59), label: "剩余面粉0.5kg（不宣称食材归零）" });
E({ day: 1, type: "fact", key: "F05_kitchen.phys.coal_kg", value: 2, by: T(1, 23, 59), label: "剩余煤饼2kg" });
E({ day: 1, type: "within", beat: "d1.detective.plan_tomorrow", from: T(1, 17), to: T(1, 21, 35), label: "21:35回执截止前提出开仓分工" });
E({ day: 2, type: "order", before: "d2.wind_open", after: "d2.margaret.measure", label: "风窗开放后才测门扇" });
E({ day: 2, type: "order", before: "d2.huo.brace", after: "d2.quer.pick", label: "先千斤顶复位，再挑锁" });
E({ day: 2, type: "order", before: "d2.quer.pick", after: "d2.detective.read_inventory", label: "三匠开仓后才点验清册" });
near(2, "d2.detective.deduce_ration", 9, 56, "推演等额份额与集中热餐");
near(2, "d2.detective.persuade_ward", 9, 59, "说服沃德");
near(2, "d2.detective.persuade_shen", 10, 1, "说服沈鼎");
near(2, "d2.detective.secure_probes", 10, 35, "建议雀儿封存探针");
near(2, "d2.detective.seal_medical_records", 11, 52, "建议维罗妮卡封存验药记录");
near(2, "d2.detective.deduce_academy", 14, 1, "四院资源边界推演");
E({ day: 2, type: "fact", key: "ration.policy.mediated", value: true, by: T(2, 12), label: "配给争议达成共同协议" });
for (const r of ["W102", "B102", "F104", "S102"]) E({ day: 2, type: "within", beat: `d2.detective.inspect_${r}`, from: T(2, 9), to: T(2, 17), label: `${r} 勘查发生在风窗时段内` });
near(3, "d3.detective.deduce_ration_forgery", 8, 7, "推演旧签名不能认证新授权");
near(3, "d3.detective.restore_rations", 8, 15, "公开核证归还口粮");
near(3, "d3.detective.persuade_ward_ration", 8, 20, "请沃德更正记录");
E({ day: 3, type: "fact", key: "case_day3.phys.resolved", value: true, by: T(3, 12), label: "第三日授权争议已解决" });
E({ day: 3, type: "fact", key: "ruan.doc.test_admitted", value: true, by: T(3, 12), label: "阮清月承认试探" });
near(4, "d4.microquake", 17, 30, "第四日微震", 0);
E({ day: 4, type: "order", before: "d4.detective.read_seventh_clause", after: "d4.detective.deduce_airlock", label: "先核对第七条，再推演封隔" });
near(4, "d4.detective.deduce_airlock", 17, 32, "推演短时封隔");
near(4, "d4.detective.seal_airlock", 17, 33, "言灵「闭合之门，不纳污息」");
near(4, "d4.detective.seal_airlock:expire", 18, 18, "言灵到期");
near(4, "d4.detective.plan_night", 17, 34, "拟定第四夜策略");
E({ day: 4, type: "near", beat: "d4.detective.recruit_huo", t: T(4, 17, 37), tol: 15, label: "请霍铎协作锁门（回归记录 17:37 ±15′）", branch: strategy(["lock"]) });
E({ day: 4, type: "near", beat: "d4.detective.recruit_quer", t: T(4, 17, 39), tol: 15, label: "请雀儿协作锁门（回归记录 17:39 ±15′）", branch: strategy(["lock"]) });
E({ day: 4, type: "knows", actor: "detective", key: "detective.infer.seventh_clause_limits", by: T(4, 23), label: "奇策被第七条拦截：代管者只告知、不守夜", branch: strategy(["trap"]) });
E({ day: 4, type: "fact", key: "night_day4.phys.secured", value: true, by: T(4, 22), label: "第四夜防护已落实" });
E({ day: 4, type: "fact", key: "moran.phys.cured", value: true, by: T(4, 22), label: "莫兰获救" });
E({ day: 4, type: "fact", key: "bertrand.phys.cured", value: true, by: T(4, 22), label: "贝尔特朗获救" });
E({ day: 5, type: "fact", key: "autonomy.phase.active", value: true, by: T(5, 1), label: "进入自主观察日" });
near(5, "d5.detective.deduce_case", 7, 31, "五日案记归档推演");
near(5, "d5.detective.ask_steward", 7, 47, "询问代管者");
E({ day: 5, type: "fact", key: "victims.phys.rechecked", value: true, by: T(5, 12), label: "两名倒灌伤者已完成复查" });
E({ day: 5, type: "happens", beat: "d5.detective.sleep", label: "第五日观察窗完整走完" });

export const STORY: StoryData = {
  schema: "dowr2-core-story-v1",
  title: "安眠者有福 · 前五日核心剧情",
  viewer: "detective",
  start: T(1, 7) - 1,
  end: T(6, 0),
  tick: 0.25,
  phases: [
    { from: 0, title: "第一章 · 门的这一侧", subtitle: "四区封锁、乙区拖回之谜、讲堂“神谕”与团圆饺子" },
    { from: T(2, 0), title: "第二章 · 风窗之约", subtitle: "三匠开仓、配给协议与四院初探" },
    { from: T(3, 0), title: "第二章 · 倒脱靴", subtitle: "阮清月以旧签名布下的配给试探" },
    { from: T(4, 0), title: "第二章 · 第四夜", subtitle: "微震、倒灌与第七条的边界" },
    { from: T(5, 0), title: "自主观察日", subtitle: "各人依据已经知道的事安排生活" },
  ],
  rooms, doors, actors, facts, labels, beats, rules, events, expectations: ex,
};
