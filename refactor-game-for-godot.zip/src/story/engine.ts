// 确定性剧情引擎：固定步长推进；Core 独自决定时间与结果，演出层只按事件插值。
// scenes/story/story_engine.gd 与本文件逐函数对应——两端在同一份 core_story.json 上产生相同时间线。
import type { Beat, Expectation, Facts, Line, Rule, StoryData, Value } from "./types";

export type EvType = "start" | "end" | "walk" | "arrive" | "world" | "expire" | "intervene" | "skip" | "choice" | "blocked" | "finish";
export interface StoryEvent {
  t: number; type: EvType; actor?: string; beat?: string; room?: string; label?: string;
  lines?: Line[]; path?: string[]; times?: number[]; learned?: string[]; reason?: string; option?: string; set?: Facts;
}
interface Busy { beat: string; start: number; end: number; show: boolean }
interface Travel { beat: string; path: string[]; times: number[] }
export interface ActorState { id: string; room: string; idx: number; busy: Busy | null; travel: Travel | null; blocked: string }
export interface Occurrence { start: number; end: number }
export type ExpStatus = "pass" | "fail" | "pending" | "na";
export interface ExpResult { id: string; status: ExpStatus; detail: string }

const PRIVATE = new Set(["deduce", "inspect", "read"]); // 勘查、阅读、推演只进入本人认知
const EPS = 1e-6;

export const clock = (t: number) => {
  const m = Math.max(0, Math.round(t * 60) / 60);
  const day = Math.floor(m / 1440) + 1;
  const h = Math.floor((m % 1440) / 60), mm = Math.floor(m % 60);
  return { day, text: `${String(h).padStart(2, "0")}:${String(mm).padStart(2, "0")}`, full: `第${day}日 ${String(h).padStart(2, "0")}:${String(mm).padStart(2, "0")}` };
};

export class StoryEngine {
  readonly data: StoryData;
  time: number;
  facts: Facts;
  known: Record<string, Record<string, Value>> = {};
  actors: Record<string, ActorState> = {};
  order: string[] = [];
  agendas: Record<string, string[]> = {};
  beats: Record<string, Beat> = {};
  done: Record<string, Occurrence> = {};
  skipped: Record<string, string> = {};
  fired: Record<string, number> = {};
  snapshots: Record<string, Value> = {};
  expiries: { id: string; at: number; set: Facts; label: string }[] = [];
  choices: Record<string, string> = {};
  events: StoryEvent[] = [];
  pending: string | null = null;
  autoChoose: boolean;
  finished = false;
  private roomIds: string[];
  private roomIdx: Record<string, number> = {};

  constructor(data: StoryData, autoChoose = true) {
    this.data = data;
    this.autoChoose = autoChoose;
    this.time = data.start;
    this.facts = { ...data.facts };
    for (const a of data.actors) {
      this.order.push(a.id);
      this.agendas[a.id] = [];
      this.known[a.id] = {};
      this.actors[a.id] = { id: a.id, room: a.home, idx: 0, busy: null, travel: null, blocked: "" };
      for (const k of a.knows ?? []) this.known[a.id][k] = this.facts[k];
    }
    for (const b of data.beats) { this.beats[b.id] = b; this.agendas[b.actor].push(b.id); }
    this.roomIds = data.rooms.map((r) => r.id);
    this.roomIds.forEach((r, i) => (this.roomIdx[r] = i));
    this.tick();
  }

  // ── 推进 ──
  advanceTo(target: number) {
    while (!this.finished && this.pending === null && this.time + this.data.tick <= target + EPS) {
      this.time += this.data.tick;
      this.tick();
    }
  }

  choose(beatId: string, option: string) {
    if (this.pending !== beatId) return;
    this.choices[beatId] = option;
    this.pending = null;
    this.decideAll();
  }

  private tick() {
    const t = this.time;
    for (const e of this.data.events) {
      if (this.fired[e.id] === undefined && e.at <= t + EPS) {
        this.fired[e.id] = t;
        this.apply(e.set);
        const tell = e.tell ?? [];
        for (const a of tell) this.learn(a, Object.keys(e.set));
        this.emit({ t, type: "world", beat: e.id, label: e.label, set: e.set, learned: tell });
      }
    }
    let i = 0;
    while (i < this.expiries.length) {
      const x = this.expiries[i];
      if (x.at <= t + EPS) {
        this.expiries.splice(i, 1);
        this.fired[x.id] = t;
        this.apply(x.set);
        this.emit({ t, type: "expire", beat: x.id, label: x.label, set: x.set });
      } else i++;
    }
    for (const id of this.order) {
      const s = this.actors[id];
      if (s.busy && s.busy.end <= t + EPS) this.complete(s);
      if (s.travel && s.travel.times[s.travel.times.length - 1] <= t + EPS) {
        s.room = s.travel.path[s.travel.path.length - 1];
        s.travel = null;
        this.emit({ t, type: "arrive", actor: id, room: s.room });
      }
    }
    for (const e of this.data.expectations) {
      if (e.type === "fact" && this.snapshots[e.id] === undefined && e.by <= t + EPS) this.snapshots[e.id] = this.facts[e.key];
    }
    this.decideAll();
    if (!this.finished && t >= this.data.end - EPS) {
      this.finished = true;
      this.emit({ t, type: "finish", label: "第五日观察结束" });
    }
  }

  private decideAll() {
    for (const id of this.order) {
      if (this.pending !== null) return;
      const s = this.actors[id];
      if (!s.busy && !s.travel) this.decide(s);
    }
  }

  private decide(s: ActorState) {
    const t = this.time;
    const agenda = this.agendas[s.id];
    while (s.idx < agenda.length) {
      const id = agenda[s.idx];
      const b = this.beats[id];
      if (b.skipIf && this.match(b.skipIf)) { this.skip(s, b, "条件不再适用"); continue; }
      if (b.branch) {
        const v = this.facts[b.branch.key];
        if (v === "" || v === undefined) return;
        if (!b.branch.values.includes(v)) { this.skip(s, b, "未选择此分支"); continue; }
      }
      if (b.earliest !== undefined && t < b.earliest - EPS) return;
      if (s.room !== b.at) {
        const path = this.findPath(s.id, s.room, b.at);
        if (!path) {
          if (s.blocked !== id) { s.blocked = id; this.emit({ t, type: "blocked", actor: s.id, beat: id, room: b.at, label: b.label }); }
          return;
        }
        s.blocked = "";
        const times = [t];
        for (let k = 1; k < path.length; k++) times.push(times[k - 1] + this.edgeMin(s.id, path[k - 1], path[k]));
        s.travel = { beat: id, path, times };
        this.emit({ t, type: "walk", actor: s.id, beat: id, room: b.at, path, times, label: b.label });
        return;
      }
      if (!this.ready(s, b)) return;
      const rule = this.guard(b);
      if (rule) { this.intervene(rule, b); this.skip(s, b, `${rule.article}拦截`); continue; }
      if (b.choice) {
        let opt = this.choices[id];
        if (opt === undefined) {
          if (!this.autoChoose) { this.pending = id; return; }
          opt = b.choice.auto;
          this.choices[id] = opt;
        }
        const o = b.choice.options.find((x) => x.id === opt) ?? b.choice.options[0];
        this.apply(o.set);
        this.emit({ t, type: "choice", actor: s.id, beat: id, option: o.id, label: o.label, set: o.set });
      }
      s.busy = { beat: id, start: t, end: t + b.min, show: !!b.show };
      this.emit({ t, type: "start", actor: s.id, beat: id, room: b.at, label: b.label, lines: b.say });
      return;
    }
  }

  private ready(s: ActorState, b: Beat) {
    if (b.req && !this.match(b.req)) return false;
    for (const a of b.after ?? []) if (!this.done[a] && this.skipped[a] === undefined && this.fired[a] === undefined) return false;
    for (const k of b.know ?? []) if (!(k in this.known[s.id])) return false;
    for (const w of b.with ?? []) if (!this.present(w, b.at)) return false;
    return true;
  }

  private complete(s: ActorState) {
    const busy = s.busy!;
    s.busy = null;
    const t = this.time;
    if (busy.beat.startsWith("!")) { this.emit({ t, type: "end", actor: s.id, beat: busy.beat, room: s.room }); return; }
    const b = this.beats[busy.beat];
    if (b.set) this.apply(b.set);
    const keys = [...Object.keys(b.set ?? {}), ...(b.reveal ?? [])];
    const audience = this.audience(s.id, b);
    for (const a of audience) this.learn(a, keys);
    if (b.expires) this.expiries.push({ id: `${b.id}:expire`, at: t + b.expires.after, set: b.expires.set, label: b.expires.label });
    this.done[b.id] = { start: busy.start, end: t };
    s.idx++;
    this.emit({ t, type: "end", actor: s.id, beat: b.id, room: b.at, label: b.label, set: b.set, learned: audience });
  }

  private audience(actor: string, b: Beat) {
    const out = [actor];
    for (const a of b.tell ?? []) if (!out.includes(a)) out.push(a);
    if (!PRIVATE.has(b.kind ?? "work")) {
      for (const id of this.order) if (!out.includes(id) && !this.hiddenActor(id) && this.present(id, b.at)) out.push(id);
    }
    return out;
  }

  private guard(b: Beat): Rule | null {
    for (const r of this.data.rules) if (r.guard.includes(b.id) && this.match(r.when)) return r;
    return null;
  }

  private intervene(r: Rule, b: Beat) {
    const t = this.time;
    if (r.set) this.apply(r.set);
    const audience = [r.by, ...(r.tell ?? [])];
    for (const a of audience) this.learn(a, Object.keys(r.set ?? {}));
    const d = this.actors[r.by];
    if (d && !d.busy) { d.travel = null; d.room = b.at; d.busy = { beat: `!${r.id}`, start: t, end: t + r.showFor, show: true }; }
    this.fired[`${r.id}@${b.id}`] = t;
    this.emit({ t, type: "intervene", actor: r.by, beat: b.id, room: b.at, label: `${r.article}：${r.label}`, lines: r.say, set: r.set, reason: r.id });
  }

  private skip(s: ActorState, b: Beat, reason: string) {
    this.skipped[b.id] = reason;
    s.idx++;
    this.emit({ t: this.time, type: "skip", actor: s.id, beat: b.id, label: b.label, reason });
  }

  // ── 空间 ──
  private usable(d: StoryData["doors"][number], actor: string) {
    return (!d.lock || this.facts[d.lock] === true) && (!d.only || d.only.includes(actor));
  }

  findPath(actor: string, from: string, to: string): string[] | null {
    const n = this.roomIds.length;
    const dist = new Array<number>(n).fill(Infinity), prev = new Array<number>(n).fill(-1), closed = new Array<boolean>(n).fill(false);
    const s = this.roomIdx[from], g = this.roomIdx[to];
    dist[s] = 0;
    for (;;) {
      let u = -1;
      for (let i = 0; i < n; i++) if (!closed[i] && dist[i] < Infinity && (u < 0 || dist[i] < dist[u])) u = i;
      if (u < 0) return null;
      if (u === g) break;
      closed[u] = true;
      for (const d of this.data.doors) {
        if (!this.usable(d, actor)) continue;
        const ia = this.roomIdx[d.a], ib = this.roomIdx[d.b];
        const v = ia === u ? ib : ib === u ? ia : -1;
        if (v < 0 || closed[v]) continue;
        if (dist[u] + d.min < dist[v]) { dist[v] = dist[u] + d.min; prev[v] = u; }
      }
    }
    const path: string[] = [];
    for (let v = g; v !== -1; v = prev[v]) path.unshift(this.roomIds[v]);
    return path;
  }

  private edgeMin(actor: string, a: string, b: string) {
    let m = Infinity;
    for (const d of this.data.doors) if (this.usable(d, actor) && ((d.a === a && d.b === b) || (d.a === b && d.b === a))) m = Math.min(m, d.min);
    return m;
  }

  // ── 认知与事实 ──
  private apply(set: Facts) { for (const k of Object.keys(set)) this.facts[k] = set[k]; }
  private learn(actor: string, keys: string[]) {
    const k = this.known[actor];
    if (!k) return;
    for (const key of keys) k[key] = this.facts[key];
  }
  private match(c: Facts) { return Object.keys(c).every((k) => this.facts[k] === c[k]); }
  private hiddenActor(id: string) { return !!this.data.actors.find((a) => a.id === id)?.hidden; }
  present(id: string, room: string) { const s = this.actors[id]; return !!s && s.room === room && !s.travel; }

  private emit(e: StoryEvent) { this.events.push(e); }

  // ── 供演出层读取（只读） ──
  visible(id: string) {
    const a = this.data.actors.find((x) => x.id === id)!;
    const s = this.actors[id];
    if (!a.hidden) return true;
    if (s.busy?.show) return true;
    return !s.travel && (a.visibleIn ?? []).includes(s.room);
  }

  /** 在任意（连续）时刻 t 给出人物所在的线段：from→to 与插值比例 */
  segment(id: string, t: number) {
    const s = this.actors[id];
    if (!s.travel) return { from: s.room, to: s.room, f: 0 };
    const { path, times } = s.travel;
    for (let k = 1; k < path.length; k++) {
      if (t < times[k]) return { from: path[k - 1], to: path[k], f: Math.max(0, Math.min(1, (t - times[k - 1]) / (times[k] - times[k - 1]))) };
    }
    return { from: path[path.length - 1], to: path[path.length - 1], f: 0 };
  }

  activity(id: string) {
    const s = this.actors[id];
    if (s.busy) return s.busy.beat.startsWith("!") ? "显形干预" : this.beats[s.busy.beat].label;
    if (s.travel) return `前往 ${this.roomLabel(s.travel.path[s.travel.path.length - 1])}`;
    const next = this.agendas[id][s.idx];
    if (!next) return "—";
    return s.blocked === next ? `受阻：${this.beats[next].label}` : `等待：${this.beats[next].label}`;
  }

  roomLabel(id: string) { return this.data.rooms.find((r) => r.id === id)?.label ?? id; }

  phase(t = this.time) {
    let p = this.data.phases[0];
    for (const x of this.data.phases) if (t >= x.from) p = x;
    return p;
  }

  occurrence(id: string): Occurrence | null {
    if (this.done[id]) return this.done[id];
    if (this.fired[id] !== undefined) return { start: this.fired[id], end: this.fired[id] };
    return null;
  }

  private started(id: string): Occurrence | null {
    for (const k of this.order) { const b = this.actors[k].busy; if (b && b.beat === id) return { start: b.start, end: Infinity }; }
    return null;
  }

  // ── 核心剧情校验 ──
  evaluate(): ExpResult[] {
    const t = this.time, fin = this.finished;
    const c = (x: number) => clock(x).full;
    return this.data.expectations.map((e: Expectation): ExpResult => {
      const r = (status: ExpStatus, detail: string): ExpResult => ({ id: e.id, status, detail });
      if (e.branch) {
        const v = this.facts[e.branch.key];
        if (v !== "" && v !== undefined && !e.branch.values.includes(v)) return r("na", `本局未选此分支（${String(v)}）`);
      }
      switch (e.type) {
        case "happens": {
          const o = this.occurrence(e.beat);
          if (o) return r("pass", c(o.end));
          if (this.skipped[e.beat] !== undefined) return r("fail", `被跳过：${this.skipped[e.beat]}`);
          return fin ? r("fail", "未发生") : r("pending", "尚未发生");
        }
        case "order": {
          const a = this.occurrence(e.before), b = this.occurrence(e.after) ?? this.started(e.after);
          if (b && (!a || a.end > b.start + EPS)) return r("fail", a ? `${c(a.end)} 晚于 ${c(b.start)}` : `后者已于 ${c(b.start)} 发生`);
          if (a && b) return r("pass", `${clock(a.end).text} → ${clock(b.start).text}`);
          return fin ? r("fail", "未发生") : r("pending", a ? `前者 ${clock(a.end).text} 已发生` : "尚未发生");
        }
        case "near": {
          const o = this.occurrence(e.beat);
          if (o) return Math.abs(o.end - e.t) <= e.tol + EPS ? r("pass", `实际 ${clock(o.end).text}`) : r("fail", `实际 ${clock(o.end).text}`);
          return t > e.t + e.tol || fin ? r("fail", "未在窗口内发生") : r("pending", "尚未发生");
        }
        case "fact": {
          const v = this.snapshots[e.id];
          if (v === undefined) return r("pending", `当前 ${String(this.facts[e.key])}`);
          return v === e.value ? r("pass", `${clock(e.by).text} 时为 ${String(v)}`) : r("fail", `${clock(e.by).text} 时为 ${String(v)}`);
        }
        case "notKnows":
          if (e.key in this.known[e.actor]) return r("fail", "已被告知");
          return fin ? r("pass", "全程未知") : r("pending", "目前未知");
        case "knows":
          if (e.key in this.known[e.actor]) return r("pass", "已知");
          return t > e.by || fin ? r("fail", "未得知") : r("pending", "尚未得知");
        case "startAfter": {
          const o = this.occurrence(e.beat) ?? this.started(e.beat);
          if (o) return o.start >= e.t - EPS ? r("pass", `开始于 ${clock(o.start).text}`) : r("fail", `开始于 ${clock(o.start).text}`);
          return fin ? r("fail", "未发生") : r("pending", "尚未发生");
        }
        case "within": {
          const o = this.occurrence(e.beat);
          if (o) return o.start >= e.from - EPS && o.end <= e.to + EPS ? r("pass", `${clock(o.start).text}–${clock(o.end).text}`) : r("fail", `${clock(o.start).text}–${clock(o.end).text}`);
          return t > e.to || fin ? r("fail", "未发生") : r("pending", "尚未发生");
        }
      }
    });
  }
}
