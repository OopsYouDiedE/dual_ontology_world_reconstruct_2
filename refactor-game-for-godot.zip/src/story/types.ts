// 精简剧情模型：世界事实 + 人物议程(节拍) + 契约规则 + 世界事件 + 校验期望。
// 同一份数据导出为 core_story.json 供 Godot 的 story_engine.gd 读取，两端算法逐行对应。

export type Value = boolean | number | string;
export type Facts = Record<string, Value>;

export type BeatKind =
  | "wake" | "move" | "inspect" | "read" | "talk" | "deduce" | "work"
  | "meal" | "rest" | "sleep" | "incant" | "strategy";

export interface Room {
  id: string;
  label: string;
  floor: string; // 2F / 1F / B1 / B2 / OUT
  zone: string; // A B C D M(中翼) F(一楼) U(地下) X(外院) S(代管者)
  x: number; y: number; w: number; h: number; // 平面布置（米），Godot 中 x→X, y→Z
}

export interface Door {
  a: string; b: string;
  min: number; // 通行耗时（游戏分钟）
  lock?: string; // 为 true 时可通行的事实键
  only?: string[]; // 仅限这些人物（如勤务暗井）
  label?: string;
}

export interface Actor {
  id: string; name: string; role: string;
  color: string; // 服装主色（character_art.dv 的 cloth）
  home: string;
  model?: string; // Godot GLB 路径
  hidden?: boolean; // 代管者：默认不可见
  visibleIn?: string[]; // 在这些房间中显形
  knows?: string[]; // 开局已知事实键
}

export type Line = [string, string]; // [说话人, 台词]

export interface Choice {
  prompt: string;
  auto: string; // 自动推进时采用的选项（与原工程回归记录一致）
  options: { id: string; label: string; note: string; set: Facts }[];
}

export interface Beat {
  id: string; actor: string; at: string; min: number; label: string;
  kind?: BeatKind;
  earliest?: number; // 绝对分钟（第1日00:00为0）
  req?: Facts; // 世界事实条件
  know?: string[]; // 本人必须已经知道的事实（主观证据）
  after?: string[]; // 须已完成或已跳过的节拍
  with?: string[]; // 必须同处该房间的人物
  branch?: { key: string; values: Value[] }; // 分支：已决定且不符则跳过，未决定则等待
  skipIf?: Facts; // 条件成立时跳过
  set?: Facts; // 完成时写入
  reveal?: string[]; // 完成时让在场者得知的额外事实
  tell?: string[]; // 远程告知（传声管），不要求在场
  expires?: { after: number; set: Facts; label: string }; // 时效（言灵）
  say?: Line[];
  show?: boolean; // 隐藏人物在此节拍中显形
  choice?: Choice;
}

export interface Rule {
  id: string; article: string; label: string;
  guard: string[]; // 被拦截的节拍
  when: Facts;
  by: string; // 执行者（代管者）
  set?: Facts;
  tell?: string[];
  showFor: number;
  say: Line[];
}

export interface WorldEvent { id: string; at: number; label: string; set: Facts; tell?: string[] }

export type Expectation =
  | { id: string; day: number; label: string; type: "happens"; beat: string; branch?: Branch }
  | { id: string; day: number; label: string; type: "order"; before: string; after: string; branch?: Branch }
  | { id: string; day: number; label: string; type: "near"; beat: string; t: number; tol: number; branch?: Branch }
  | { id: string; day: number; label: string; type: "fact"; key: string; value: Value; by: number; branch?: Branch }
  | { id: string; day: number; label: string; type: "notKnows"; actor: string; key: string; branch?: Branch }
  | { id: string; day: number; label: string; type: "knows"; actor: string; key: string; by: number; branch?: Branch }
  | { id: string; day: number; label: string; type: "startAfter"; beat: string; t: number; branch?: Branch }
  | { id: string; day: number; label: string; type: "within"; beat: string; from: number; to: number; branch?: Branch };

export interface Branch { key: string; values: Value[] }

export type NewExpectation = Expectation extends infer E ? (E extends unknown ? Omit<E, "id"> : never) : never;

export interface Phase { from: number; title: string; subtitle: string }

export interface StoryData {
  schema: string;
  title: string;
  viewer: string;
  start: number;
  end: number;
  tick: number;
  phases: Phase[];
  rooms: Room[];
  doors: Door[];
  actors: Actor[];
  facts: Facts;
  labels: Record<string, string>;
  beats: Beat[];
  rules: Rule[];
  events: WorldEvent[];
  expectations: Expectation[];
}
