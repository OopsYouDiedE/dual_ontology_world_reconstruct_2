import { lazy, Suspense, useEffect, useState } from "react";
import { MainMenu } from "./components/MainMenu";
import { LifeView } from "./components/LifeView";
import { BuildingEditor } from "./components/BuildingEditor";
import { DEFAULT_BUILDING } from "./data/house";
import type { BuildingData } from "./engine/types";
import { LifeSim } from "./engine/sim";

const CharacterGallery = lazy(() => import("./components/CharacterGallery").then((m) => ({ default: m.CharacterGallery })));

type Screen = "menu" | "life" | "editor" | "gallery";

function loadDesign(): BuildingData {
  try {
    const s = localStorage.getItem("dowr2.building");
    if (s) return JSON.parse(s);
  } catch { /* ignore */ }
  return JSON.parse(JSON.stringify(DEFAULT_BUILDING));
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("menu");
  const [design, setDesign] = useState<BuildingData>(loadDesign);
  const [life, setLife] = useState<{ key: number; building: BuildingData; origin: "menu" | "editor"; save: string | null } | null>(null);
  const [galleryFrom, setGalleryFrom] = useState<Screen>("menu");

  useEffect(() => {
    document.title = "双本体世界·重构 — 五人生活推演";
  }, []);

  const startLife = (building: BuildingData, origin: "menu" | "editor", seed?: number) => {
    let save: string | null = null;
    if (seed !== undefined && seed !== 7) save = new LifeSim(JSON.parse(JSON.stringify(building)), seed).serialize();
    setLife({ key: Date.now(), building: JSON.parse(JSON.stringify(building)), origin, save });
    setScreen("life");
  };

  return (
    <div className="h-screen w-screen overflow-hidden bg-[#15110d] font-sans">
      {screen === "menu" && (
        <MainMenu
          onNewLife={(seed) => startLife(DEFAULT_BUILDING, "menu", seed)}
          onLoad={(s) => { setLife({ key: Date.now(), building: DEFAULT_BUILDING, origin: "menu", save: s }); setScreen("life"); }}
          onEditor={() => setScreen("editor")}
          onGallery={() => { setGalleryFrom("menu"); setScreen("gallery"); }}
        />
      )}
      {screen === "life" && life && (
        <LifeView key={life.key} building={life.building} origin={life.origin} initialSave={life.save}
          onExit={() => setScreen(life.origin === "editor" ? "editor" : "menu")} />
      )}
      {screen === "editor" && (
        <BuildingEditor building={design} setBuilding={setDesign}
          onBack={() => setScreen("menu")}
          onSimulate={() => startLife(design, "editor")}
          onGallery={() => { setGalleryFrom("editor"); setScreen("gallery"); }} />
      )}
      {screen === "gallery" && (
        <Suspense fallback={<div className="flex h-screen items-center justify-center text-[#cbb898]">正在生成角色模型……</div>}>
          <CharacterGallery onBack={() => setScreen(galleryFrom)} />
        </Suspense>
      )}
    </div>
  );
}
