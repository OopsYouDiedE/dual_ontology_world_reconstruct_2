import { useDeferredValue, useEffect, useMemo, useRef, useState } from "react";
import type { BuildingData, PropData, Vec2, WallData } from "../engine/types";
import { approachPoint, buildGeo, findPath, pointInProp, wallSegments } from "../engine/geometry";
import { drawFloor, drawProp, drawRoomLabels, drawWalls, sortedProps, type View } from "../engine/render";
import { CHARACTERS, KIND_LABELS } from "../data/characters";
import { DEFAULT_BUILDING } from "../data/house";
import { Modal } from "./Modal";

type Tool = "select" | "wall" | "door" | "arch" | "window" | "erase" | { place: string };

const PALETTE_KINDS = ["bed", "sofa", "chair", "bench", "table", "round_table", "cabinet", "wash_table", "bookshelf", "upright_piano", "easel", "painting", "planter", "wall_lantern", "rug", "chest", "nightstand", "banker_lamp", "pendant_lamp"];

const PARAM_SPECS: Record<string, [string, string, number, number][]> = {
  bed: [["bed_w", "宽", 0.9, 2], ["bed_l", "长", 1.8, 2.3]],
  cabinet: [["cab_w", "宽", 0.6, 2]],
  table: [["table_w", "宽", 0.8, 3], ["table_d", "深", 0.5, 1.4]],
  sofa: [["sofa_w", "宽", 1.2, 3], ["sofa_d", "深", 0.7, 1.1]],
  round_table: [["table_r", "半径", 0.3, 0.8]],
  bench: [["bench_len", "长", 0.8, 2.5]],
  rug: [["rug_w", "宽", 1, 4], ["rug_d", "深", 0.8, 3]],
  painting: [["frame_w", "宽", 0.5, 2]],
  bookshelf: [["shelf_w", "宽", 0.6, 2.5]],
  planter: [["plant_w", "尺寸", 0.4, 1], ["flower_count", "花朵", 0, 12]],
  chest: [["chest_w", "宽", 0.5, 1.4]],
};

const REQUIRED: [string, string][] = [["bed", "床（睡眠）"], ["cabinet", "储物柜（口粮）"], ["wash_table", "盥洗台（喝水/洗漱）"], ["chair", "椅子（用餐/学习）"], ["table", "桌子（用餐）"]];

const clone = <T,>(x: T): T => JSON.parse(JSON.stringify(x));
let uid = 0;
const newId = (k: string) => `ed_${k}_${Date.now().toString(36)}_${uid++}`;

export function toDV(b: BuildingData) {
  return `schema "dv-script-v1";\ndata life.building { value = ${JSON.stringify(b, null, 2)}; }\n`;
}
export function fromDV(text: string): BuildingData {
  const i = text.indexOf("value = ");
  const body = i >= 0 ? text.slice(i + 8, text.lastIndexOf("}; }") + 1) : text;
  const j = JSON.parse(body);
  if (!Array.isArray(j.walls) || !Array.isArray(j.props)) throw new Error("缺少 walls / props");
  return { name: j.name ?? "导入建筑", width: j.width ?? 16, depth: j.depth ?? 11, style: j.style ?? "parquet_wood", walls: j.walls, props: j.props };
}

interface Props {
  building: BuildingData;
  setBuilding: (b: BuildingData) => void;
  onBack: () => void;
  onSimulate: () => void;
  onGallery: () => void;
}

export function BuildingEditor({ building, setBuilding, onBack, onSimulate, onGallery }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const viewRef = useRef<View>({ scale: 40, ox: 0, oy: 0 });
  const [tool, setTool] = useState<Tool>("select");
  const [sel, setSel] = useState<{ type: "prop" | "wall"; id: string } | null>(null);
  const [draft, setDraft] = useState<Vec2[]>([]);
  const [hover, setHover] = useState<Vec2 | null>(null);
  const [undo, setUndo] = useState<BuildingData[]>([]);
  const [redo, setRedo] = useState<BuildingData[]>([]);
  const [modal, setModal] = useState<null | "export" | "import" | "new" | "help">(null);
  const [importText, setImportText] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [size, setSize] = useState({ w: 14, d: 10 });
  const drag = useRef<{ id: string; dx: number; dz: number; moved: boolean; before: BuildingData } | null>(null);

  const geo = useMemo(() => buildGeo(building), [building]);
  const deferred = useDeferredValue(building);
  const vgeo = useMemo(() => buildGeo(deferred), [deferred]);
  const [ver, setVer] = useState(0);
  const flash = (s: string) => { setMsg(s); setTimeout(() => setMsg(null), 2200); };

  const commit = (nb: BuildingData, before: BuildingData = building) => {
    setUndo((u) => [...u.slice(-60), clone(before)]);
    setRedo([]);
    setBuilding(nb);
  };
  const doUndo = () => {
    if (!undo.length) return;
    setRedo((r) => [...r, clone(building)]);
    setBuilding(undo[undo.length - 1]);
    setUndo((u) => u.slice(0, -1));
  };
  const doRedo = () => {
    if (!redo.length) return;
    setUndo((u) => [...u, clone(building)]);
    setBuilding(redo[redo.length - 1]);
    setRedo((r) => r.slice(0, -1));
  };

  // 校验
  const validation = useMemo(() => {
    const geo = vgeo, building = deferred;
    const issues: { ok: boolean; text: string }[] = [];
    issues.push({ ok: geo.rooms.length > 0, text: `封闭房间：${geo.rooms.length} 间${geo.rooms.length ? "（" + geo.rooms.map((r) => r.name).join("、") + "）" : ""}` });
    for (const [k, l] of REQUIRED) {
      const n = building.props.filter((p) => p.kind === k).length;
      issues.push({ ok: n > 0, text: `${l}：${n}` });
    }
    const beds = building.props.filter((p) => p.kind === "bed").length;
    issues.push({ ok: beds >= 4, text: `床位 ${beds} / 5 人${beds < 5 ? "（不足者将睡沙发或借床）" : ""}`, });
    // 可达性
    const rooms = geo.rooms;
    if (rooms.length) {
      const start = approachPoint(geo, building.props.find((p) => p.kind === "cabinet") ?? building.props[0] ?? { id: "x", kind: "chair", x: rooms[0].cx, z: rooms[0].cz, yaw: 0, params: {} });
      let unreachable = 0;
      for (const p of building.props) {
        if (["rug", "pendant_lamp", "banker_lamp", "painting"].includes(p.kind)) continue;
        const ap = approachPoint(geo, p);
        if (!ap || !start || !findPath(geo, start, ap)) unreachable++;
      }
      issues.push({ ok: unreachable === 0, text: unreachable ? `${unreachable} 件家具无法到达` : "所有家具均可到达" });
    }
    const blocking = issues.filter((i) => !i.ok && !i.text.startsWith("床位")).length;
    return { issues, ok: geo.rooms.length > 0 && blocking === 0 };
  }, [vgeo, deferred]);

  // 画布尺寸
  useEffect(() => {
    const resize = () => {
      const cv = canvasRef.current, wrap = wrapRef.current;
      if (!cv || !wrap) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      cv.width = wrap.clientWidth * dpr; cv.height = wrap.clientHeight * dpr;
      cv.style.width = wrap.clientWidth + "px"; cv.style.height = wrap.clientHeight + "px";
      const pad = 50 * dpr;
      const scale = Math.min((cv.width - pad * 2) / (building.width + 2), (cv.height - pad * 2) / (building.depth + 2));
      viewRef.current = { scale, ox: (cv.width - building.width * scale) / 2, oy: (cv.height - building.depth * scale) / 2 };
      setVer((x) => x + 1);
    };
    resize();
    const ro = new ResizeObserver(resize);
    if (wrapRef.current) ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, [building.width, building.depth]);

  // 绘制：每帧读取最新状态重绘，避免尺寸变化清屏后的竞态
  const drawRef = useRef<() => void>(() => {});
  useEffect(() => {
    let raf = 0;
    const loop = () => { drawRef.current(); raf = requestAnimationFrame(loop); };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);
  drawRef.current = () => {
    const cv = canvasRef.current;
    if (!cv) return;
    const ctx = cv.getContext("2d")!;
    const v = viewRef.current;
    ctx.fillStyle = "#1a1612"; ctx.fillRect(0, 0, cv.width, cv.height);
    drawFloor(ctx, geo, v);
    // 网格
    ctx.strokeStyle = "rgba(255,255,255,0.06)"; ctx.lineWidth = 1;
    for (let x = -1; x <= building.width + 1; x += 0.5) { ctx.beginPath(); ctx.moveTo(v.ox + x * v.scale, v.oy - v.scale); ctx.lineTo(v.ox + x * v.scale, v.oy + (building.depth + 1) * v.scale); ctx.stroke(); }
    for (let z = -1; z <= building.depth + 1; z += 0.5) { ctx.beginPath(); ctx.moveTo(v.ox - v.scale, v.oy + z * v.scale); ctx.lineTo(v.ox + (building.width + 1) * v.scale, v.oy + z * v.scale); ctx.stroke(); }
    drawRoomLabels(ctx, geo, v);
    for (const p of sortedProps(building)) drawProp(ctx, p, v, { selected: sel?.type === "prop" && sel.id === p.id, lit: true });
    drawWalls(ctx, building, v, "full", sel?.type === "wall" ? sel.id : null);
    // 床位归属
    ctx.font = `${Math.max(10, v.scale * 0.22)}px sans-serif`; ctx.textAlign = "center";
    for (const p of building.props) if (p.kind === "bed" && p.owner) {
      const c = CHARACTERS.find((x) => x.id === p.owner);
      if (c) { ctx.fillStyle = c.color; ctx.fillText(c.name, v.ox + p.x * v.scale, v.oy + p.z * v.scale + 4); }
    }
    // 尺寸标注
    ctx.fillStyle = "#cbb898"; ctx.font = `${Math.max(10, v.scale * 0.25)}px sans-serif`;
    ctx.fillText(`${building.width} m`, v.ox + (building.width / 2) * v.scale, v.oy - v.scale * 0.55);
    ctx.save(); ctx.translate(v.ox - v.scale * 0.55, v.oy + (building.depth / 2) * v.scale); ctx.rotate(-Math.PI / 2); ctx.fillText(`${building.depth} m`, 0, 0); ctx.restore();
    // 墙体草稿
    if (tool === "wall" && (draft.length || hover)) {
      ctx.strokeStyle = "#ffcc55"; ctx.lineWidth = 3; ctx.setLineDash([8, 6]);
      ctx.beginPath();
      const pts = hover ? [...draft, hover] : draft;
      pts.forEach((p, i) => (i ? ctx.lineTo(v.ox + p[0] * v.scale, v.oy + p[1] * v.scale) : ctx.moveTo(v.ox + p[0] * v.scale, v.oy + p[1] * v.scale)));
      ctx.stroke(); ctx.setLineDash([]);
      for (const p of pts) { ctx.fillStyle = "#ffcc55"; ctx.beginPath(); ctx.arc(v.ox + p[0] * v.scale, v.oy + p[1] * v.scale, 4, 0, Math.PI * 2); ctx.fill(); }
    }
    if (hover && typeof tool === "object") {
      drawProp(ctx, { id: "ghost", kind: tool.place, x: hover[0], z: hover[1], yaw: 0, params: {} }, v, { ghost: true });
    }
    if (hover && (tool === "door" || tool === "arch" || tool === "window" || tool === "erase")) {
      ctx.strokeStyle = tool === "erase" ? "#ff5555" : "#7fd0ff"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(v.ox + hover[0] * v.scale, v.oy + hover[1] * v.scale, 8, 0, Math.PI * 2); ctx.stroke();
    }
  };
  void ver;

  const toWorld = (e: React.MouseEvent): Vec2 => {
    const cv = canvasRef.current!;
    const r = cv.getBoundingClientRect();
    const dpr = cv.width / r.width;
    const v = viewRef.current;
    return [((e.clientX - r.left) * dpr - v.ox) / v.scale, ((e.clientY - r.top) * dpr - v.oy) / v.scale];
  };
  const snap = (v: number, s: number) => Math.round(v / s) * s;

  const hitProp = (x: number, z: number) => [...sortedProps(building)].reverse().find((p) => pointInProp(p, x, z, 0.06));
  const hitWall = (x: number, z: number, tol = 0.3) => {
    let best: { wall: WallData; seg: number; t: number; d: number } | null = null;
    for (const w of building.walls) for (const s of wallSegments(w)) {
      const ux = (s.b[0] - s.a[0]) / s.len, uz = (s.b[1] - s.a[1]) / s.len;
      const dx = x - s.a[0], dz = z - s.a[1];
      const t = dx * ux + dz * uz, d = Math.abs(-uz * dx + ux * dz);
      if (t >= 0 && t <= s.len && d < tol && (!best || d < best.d)) best = { wall: w, seg: s.index, t, d };
    }
    return best;
  };

  const onDown = (e: React.MouseEvent) => {
    if (e.button === 2) { finishWall(); return; }
    const [x, z] = toWorld(e);
    if (tool === "select") {
      const p = hitProp(x, z);
      if (p) {
        setSel({ type: "prop", id: p.id });
        drag.current = { id: p.id, dx: x - p.x, dz: z - p.z, moved: false, before: clone(building) };
        return;
      }
      const w = hitWall(x, z);
      setSel(w ? { type: "wall", id: w.wall.id } : null);
      return;
    }
    if (tool === "wall") {
      const pt: Vec2 = [snap(x, 0.5), snap(z, 0.5)];
      if (draft.length && Math.hypot(pt[0] - draft[draft.length - 1][0], pt[1] - draft[draft.length - 1][1]) < 0.01) { finishWall(); return; }
      setDraft((d) => [...d, pt]);
      return;
    }
    if (tool === "door" || tool === "arch" || tool === "window") {
      const h = hitWall(x, z, 0.4);
      if (!h) { flash("请点击墙体放置"); return; }
      const width = tool === "door" ? 1.1 : tool === "arch" ? 1.4 : 1.3;
      const segLen = wallSegments(h.wall).find((s) => s.index === h.seg)!.len;
      const center = Math.min(segLen - width / 2 - 0.15, Math.max(width / 2 + 0.15, snap(h.t, 0.05)));
      if (segLen < width + 0.3) { flash("墙段太短"); return; }
      const overlap = h.wall.openings.some((o) => o.segment === h.seg && Math.abs(o.center - center) < (o.width + width) / 2);
      if (overlap) { flash("与已有门窗重叠"); return; }
      const nb = clone(building);
      const w = nb.walls.find((q) => q.id === h.wall.id)!;
      w.openings.push({ id: newId(tool), segment: h.seg, center, width, type: tool === "door" ? "closed_door" : tool === "arch" ? "portal_arch" : "rectangular_window" });
      commit(nb);
      return;
    }
    if (tool === "erase") {
      const p = hitProp(x, z);
      const nb = clone(building);
      if (p) { nb.props = nb.props.filter((q) => q.id !== p.id); commit(nb); return; }
      const h = hitWall(x, z, 0.35);
      if (h) {
        const w = nb.walls.find((q) => q.id === h.wall.id)!;
        const op = w.openings.find((o) => o.segment === h.seg && Math.abs(o.center - h.t) < o.width / 2);
        if (op) w.openings = w.openings.filter((o) => o !== op);
        else nb.walls = nb.walls.filter((q) => q.id !== w.id);
        commit(nb);
      }
      return;
    }
    if (typeof tool === "object") {
      const kind = tool.place;
      const p: PropData = { id: newId(kind), kind, x: snap(x, 0.05), z: snap(z, 0.05), yaw: 0, params: {} };
      if (kind === "bed") p.params = { bed_w: 1.1, bed_l: 2 };
      const nb = clone(building);
      nb.props.push(p);
      commit(nb);
      setSel({ type: "prop", id: p.id });
      if (!e.shiftKey) setTool("select");
    }
  };

  const onMove = (e: React.MouseEvent) => {
    const [x, z] = toWorld(e);
    if (tool === "wall") setHover([snap(x, 0.5), snap(z, 0.5)]);
    else if (typeof tool === "object") setHover([snap(x, 0.05), snap(z, 0.05)]);
    else if (tool !== "select") setHover([x, z]);
    else setHover(null);
    const d = drag.current;
    if (d) {
      const nb = { ...building, props: building.props.map((p) => (p.id === d.id ? { ...p, x: snap(x - d.dx, e.shiftKey ? 0.5 : 0.05), z: snap(z - d.dz, e.shiftKey ? 0.5 : 0.05) } : p)) };
      d.moved = true;
      setBuilding(nb);
    }
  };
  const onUp = () => {
    const d = drag.current;
    if (d && d.moved) { setUndo((u) => [...u.slice(-60), d.before]); setRedo([]); }
    drag.current = null;
  };

  const finishWall = () => {
    if (draft.length >= 2) {
      const nb = clone(building);
      nb.walls.push({ id: newId("wall"), points: draft, thickness: 0.2, height: 3.2, openings: [] });
      commit(nb);
    }
    setDraft([]);
  };

  const selProp = sel?.type === "prop" ? building.props.find((p) => p.id === sel.id) : undefined;
  const selWall = sel?.type === "wall" ? building.walls.find((w) => w.id === sel.id) : undefined;

  const updateProp = (patch: Partial<PropData>, record = true) => {
    if (!selProp) return;
    const nb = { ...building, props: building.props.map((p) => (p.id === selProp.id ? { ...p, ...patch } : p)) };
    if (record) commit(nb); else setBuilding(nb);
  };

  // 快捷键
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === "INPUT" || (e.target as HTMLElement).tagName === "TEXTAREA") return;
      if (e.key === "Escape") { setDraft([]); setTool("select"); }
      if (e.key === "Enter") finishWall();
      if ((e.key === "r" || e.key === "R") && selProp) updateProp({ yaw: (selProp.yaw + 90) % 360 });
      if ((e.key === "Delete" || e.key === "Backspace") && sel) {
        const nb = clone(building);
        if (sel.type === "prop") nb.props = nb.props.filter((p) => p.id !== sel.id);
        else nb.walls = nb.walls.filter((w) => w.id !== sel.id);
        commit(nb); setSel(null);
      }
      if ((e.ctrlKey || e.metaKey) && e.key === "z") { e.preventDefault(); doUndo(); }
      if ((e.ctrlKey || e.metaKey) && e.key === "y") { e.preventDefault(); doRedo(); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const newBlank = () => {
    const W = Math.max(6, Math.min(30, size.w)), D = Math.max(5, Math.min(22, size.d));
    commit({
      name: "新建建筑", width: W, depth: D, style: "parquet_wood",
      walls: [{ id: "outer", points: [[0, 0], [W, 0], [W, D], [0, D], [0, 0]], thickness: 0.2, height: 3.2, openings: [{ id: "door_front", segment: 2, center: W / 2, width: 1.3, type: "closed_door" }] }],
      props: [],
    });
    setSel(null); setModal(null);
  };

  const toolBtn = (t: Tool, label: string, key: string) => {
    const active = typeof t === "string" ? tool === t : typeof tool === "object" && tool.place === t.place;
    return <button key={key} onClick={() => { setTool(t); setDraft([]); }} className={`rounded-md px-2.5 py-1.5 text-xs ${active ? "bg-amber-700 text-white" : "bg-[#2a2119] hover:bg-[#3a2d22]"}`}>{label}</button>;
  };

  return (
    <div className="flex h-screen flex-col bg-[#15110d] text-[#efe6d6]">
      <div className="flex flex-wrap items-center gap-2 border-b border-[#3b2f24] bg-[#1d1712] px-3 py-2 text-sm">
        <button className="btn" onClick={onBack}>← 主菜单</button>
        <span className="font-serif text-base tracking-wider text-[#e9c98a]">建筑设计器</span>
        <input value={building.name} onChange={(e) => setBuilding({ ...building, name: e.target.value })} className="w-40 rounded border border-[#4a3b2d] bg-black/30 px-2 py-1 text-xs" />
        <div className="flex gap-1">
          {toolBtn("select", "↖ 选择/移动", "s")}
          {toolBtn("wall", "▭ 墙体", "w")}
          {toolBtn("door", "🚪 门", "d")}
          {toolBtn("arch", "⌒ 拱门", "a")}
          {toolBtn("window", "▢ 窗", "win")}
          {toolBtn("erase", "✕ 删除", "e")}
        </div>
        <button className="btn" disabled={!undo.length} onClick={doUndo}>↶</button>
        <button className="btn" disabled={!redo.length} onClick={doRedo}>↷</button>
        <div className="ml-auto flex flex-wrap gap-2">
          <button className="btn" onClick={() => setModal("new")}>新建</button>
          <button className="btn" onClick={() => { commit(clone(DEFAULT_BUILDING)); setSel(null); }}>示范住宅</button>
          <button className="btn" onClick={() => { localStorage.setItem("dowr2.building", JSON.stringify(building)); flash("设计已保存到本地"); }}>💾 保存</button>
          <button className="btn" onClick={() => setModal("export")}>导出 DV</button>
          <button className="btn" onClick={() => { setImportText(""); setModal("import"); }}>导入 DV</button>
          <button className="btn" onClick={onGallery}>🧍 角色模型</button>
          <button className={`btn ${validation.ok ? "btn-hot" : "opacity-60"}`} onClick={() => (validation.ok ? onSimulate() : flash("当前设计未通过校验，见右侧"))}>▶ 生活模拟</button>
          <button className="btn" onClick={() => setModal("help")}>？</button>
        </div>
      </div>
      <div className="flex min-h-0 flex-1">
        <div className="w-44 shrink-0 overflow-y-auto border-r border-[#3b2f24] bg-[#1a1410] p-2">
          <div className="mb-2 text-[10px] tracking-widest text-[#8f7d66]">家具组件</div>
          <div className="grid grid-cols-1 gap-1">
            {PALETTE_KINDS.map((k) => (
              <button key={k} onClick={() => { setTool({ place: k }); setDraft([]); }}
                className={`flex items-center gap-2 rounded px-2 py-1 text-left text-xs ${typeof tool === "object" && tool.place === k ? "bg-amber-700 text-white" : "bg-[#221a14] hover:bg-[#3a2d22]"}`}>
                <PropIcon kind={k} /> {KIND_LABELS[k] ?? k}
              </button>
            ))}
          </div>
          <div className="mt-3 text-[10px] leading-relaxed text-[#8f7d66]">组件由代码程序化生成，参数可在右侧调整。按住 Shift 连续放置。</div>
        </div>
        <div ref={wrapRef} className="relative min-w-0 flex-1">
          <canvas ref={canvasRef} className={`block ${tool === "select" ? "cursor-default" : "cursor-crosshair"}`}
            onMouseDown={onDown} onMouseMove={onMove} onMouseUp={onUp} onMouseLeave={() => { onUp(); setHover(null); }}
            onDoubleClick={() => tool === "wall" && finishWall()} onContextMenu={(e) => e.preventDefault()} />
          {tool === "wall" && <div className="pointer-events-none absolute left-3 top-3 rounded bg-black/60 px-3 py-1.5 text-xs">点击添加墙点（0.5 m 网格），双击 / 右键 / Enter 结束，Esc 取消</div>}
          {msg && <div className="pointer-events-none absolute left-1/2 top-4 -translate-x-1/2 rounded-full bg-amber-700/90 px-4 py-1.5 text-sm">{msg}</div>}
        </div>
        <div className="w-72 shrink-0 overflow-y-auto border-l border-[#3b2f24] bg-[#1a1410] p-3 text-xs">
          {selProp && (
            <div className="mb-4 space-y-2 rounded-lg border border-[#4a3b2d] bg-black/20 p-3">
              <div className="flex items-center justify-between"><b className="text-sm text-[#e9c98a]">{KIND_LABELS[selProp.kind] ?? selProp.kind}</b><span className="text-[10px] text-[#8f7d66]">{selProp.id.slice(0, 18)}</span></div>
              <div className="grid grid-cols-2 gap-2">
                <label>X <input type="number" step={0.05} value={selProp.x} onChange={(e) => updateProp({ x: +e.target.value })} className="inp" /></label>
                <label>Z <input type="number" step={0.05} value={selProp.z} onChange={(e) => updateProp({ z: +e.target.value })} className="inp" /></label>
              </div>
              <div className="flex items-center gap-2">
                <span>朝向 {((selProp.yaw % 360) + 360) % 360}°</span>
                <button className="btn" onClick={() => updateProp({ yaw: selProp.yaw - 90 })}>⟲</button>
                <button className="btn" onClick={() => updateProp({ yaw: selProp.yaw + 90 })}>⟳ (R)</button>
              </div>
              {(PARAM_SPECS[selProp.kind] ?? []).map(([k, l, lo, hi]) => {
                const val = selProp.params[k] ?? (lo + hi) / 2;
                return (
                  <label key={k} className="block">{l}：{val.toFixed(k === "flower_count" ? 0 : 2)}
                    <input type="range" min={lo} max={hi} step={k === "flower_count" ? 1 : 0.05} value={val}
                      onChange={(e) => updateProp({ params: { ...selProp.params, [k]: +e.target.value } }, false)} className="w-full accent-amber-600" />
                  </label>
                );
              })}
              {selProp.kind === "bed" && (
                <label className="block">床主
                  <select value={selProp.owner ?? ""} onChange={(e) => updateProp({ owner: e.target.value || undefined })} className="inp">
                    <option value="">（自动分配）</option>
                    {CHARACTERS.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </label>
              )}
              <div className="flex gap-2 pt-1">
                <button className="btn" onClick={() => { const nb = clone(building); const np = { ...clone(selProp), id: newId(selProp.kind), x: selProp.x + 0.5, z: selProp.z + 0.5 }; nb.props.push(np); commit(nb); setSel({ type: "prop", id: np.id }); }}>复制</button>
                <button className="btn" onClick={() => { commit({ ...building, props: building.props.filter((p) => p.id !== selProp.id) }); setSel(null); }}>删除</button>
              </div>
            </div>
          )}
          {selWall && (
            <div className="mb-4 space-y-2 rounded-lg border border-[#4a3b2d] bg-black/20 p-3">
              <b className="text-sm text-[#e9c98a]">墙体 {selWall.id}</b>
              <div>{selWall.points.length - 1} 段 · 厚 {selWall.thickness} m · 高 {selWall.height} m</div>
              <div className="space-y-1">
                {selWall.openings.map((o) => (
                  <div key={o.id} className="flex items-center justify-between rounded bg-black/30 px-2 py-1">
                    <span>{o.type === "closed_door" ? "门" : o.type === "portal_arch" ? "拱门" : "窗"} · 段{o.segment} · {o.center.toFixed(2)} m · 宽 {o.width}</span>
                    <button className="text-red-300" onClick={() => { const nb = clone(building); const w = nb.walls.find((q) => q.id === selWall.id)!; w.openings = w.openings.filter((q) => q.id !== o.id); commit(nb); }}>✕</button>
                  </div>
                ))}
              </div>
              <button className="btn" onClick={() => { commit({ ...building, walls: building.walls.filter((w) => w.id !== selWall.id) }); setSel(null); }}>删除墙体</button>
            </div>
          )}
          <div className="mb-2 text-[10px] tracking-widest text-[#8f7d66]">生活模拟校验</div>
          <div className="space-y-1">
            {validation.issues.map((i, k) => (
              <div key={k} className={`flex gap-2 ${i.ok ? "text-emerald-300" : i.text.startsWith("床位") ? "text-amber-300" : "text-red-300"}`}><span>{i.ok ? "✓" : "!"}</span><span>{i.text}</span></div>
            ))}
          </div>
          <div className="mt-3 rounded border border-[#3b2f24] p-2 text-[10px] leading-relaxed text-[#8f7d66]">
            房间由墙体与门洞自动识别（门洞视作隔断，供推演计算邻接与噪音）。非卧室的储物柜视为口粮储藏柜。生活模拟会以当前未保存的设计开启独立新局，退出后回到这里。
          </div>
          <div className="mt-3 text-[10px] text-[#8f7d66]">家具 {building.props.length} 件 · 墙体 {building.walls.length} 道</div>
        </div>
      </div>

      {modal === "export" && (
        <Modal title="导出 DV（life.building）" onClose={() => setModal(null)} wide>
          <textarea readOnly value={toDV(building)} className="h-[55vh] w-full rounded bg-black/40 p-2 font-mono text-[11px]" />
          <div className="mt-2 flex gap-2">
            <button className="btn" onClick={() => { navigator.clipboard?.writeText(toDV(building)); flash("已复制"); }}>复制</button>
            <button className="btn" onClick={() => { const blob = new Blob([toDV(building)], { type: "text/plain" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "house.dv"; a.click(); }}>下载 house.dv</button>
          </div>
        </Modal>
      )}
      {modal === "import" && (
        <Modal title="导入 DV" onClose={() => setModal(null)} wide>
          <textarea value={importText} onChange={(e) => setImportText(e.target.value)} placeholder='schema "dv-script-v1"; data life.building { value = {...}; }' className="h-[45vh] w-full rounded bg-black/40 p-2 font-mono text-[11px]" />
          <div className="mt-2 flex gap-2">
            <label className="btn cursor-pointer">选择文件<input type="file" accept=".dv,.json,.txt" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) setImportText(await f.text()); }} /></label>
            <button className="btn btn-hot" onClick={() => { try { commit(fromDV(importText)); setModal(null); setSel(null); flash("导入成功"); } catch (err) { flash("解析失败：" + (err as Error).message); } }}>解析并加载</button>
          </div>
        </Modal>
      )}
      {modal === "new" && (
        <Modal title="新建空白建筑" onClose={() => setModal(null)}>
          <div className="space-y-3 text-sm">
            <label className="block">宽度（m）<input type="number" value={size.w} onChange={(e) => setSize({ ...size, w: +e.target.value })} className="inp" /></label>
            <label className="block">进深（m）<input type="number" value={size.d} onChange={(e) => setSize({ ...size, d: +e.target.value })} className="inp" /></label>
            <p className="text-xs text-[#a8957b]">将生成外墙与正门。之后用「墙体」工具划分房间，用「门/拱门」连通。</p>
            <button className="btn btn-hot" onClick={newBlank}>创建</button>
          </div>
        </Modal>
      )}
      {modal === "help" && (
        <Modal title="建筑器操作" onClose={() => setModal(null)}>
          <ul className="list-disc space-y-1 pl-5 text-sm text-[#e6dac6]">
            <li>选择/移动：拖动家具（Shift 吸附 0.5 m），R 旋转，Delete 删除，Ctrl+Z / Ctrl+Y 撤销重做。</li>
            <li>墙体：在 0.5 m 网格上逐点绘制折线墙，双击结束。</li>
            <li>门 / 拱门 / 窗：点击墙体放置开口。门与拱门可通行，窗不可通行。</li>
            <li>删除：点击家具、开口或墙体删除。</li>
            <li>右侧校验通过后即可「生活模拟」，用当前设计开启五人生活新局。</li>
          </ul>
        </Modal>
      )}
    </div>
  );
}

function PropIcon({ kind }: { kind: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d")!;
    ctx.clearRect(0, 0, 28, 28);
    const big = ["bed", "sofa", "table", "rug", "bookshelf", "upright_piano", "bench"].includes(kind);
    drawProp(ctx, { id: kind, kind, x: 0, z: 0, yaw: 0, params: kind === "bed" ? { bed_w: 1.1, bed_l: 2 } : {} }, { scale: big ? 10 : 22, ox: 14, oy: 14 }, { lit: true });
  }, [kind]);
  return <canvas ref={ref} width={28} height={28} className="shrink-0 rounded bg-[#c49464]/40" />;
}
