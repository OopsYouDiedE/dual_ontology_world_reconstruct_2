import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { CHARACTERS } from "../data/characters";
import { LIFE_RULES } from "../data/rules";
import { animateRig, buildCharacter, type Rig } from "../engine/characterModel";
import { Portrait } from "./Portrait";

type Pose = "stand" | "walk" | "sit" | "wave";

export function CharacterGallery({ onBack }: { onBack: () => void }) {
  const mount = useRef<HTMLDivElement>(null);
  const [idx, setIdx] = useState(0);
  const [pose, setPose] = useState<Pose>("stand");
  const [auto, setAuto] = useState(false);
  const state = useRef({ yaw: 0, targetYaw: 0, idx: 0, pose: "stand" as Pose, auto: false, rigs: [] as Rig[], chair: null as THREE.Group | null });
  state.current.idx = idx;
  state.current.pose = pose;
  state.current.auto = auto;

  useEffect(() => {
    const el = mount.current!;
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    el.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    scene.background = new THREE.Color("#1a1410");
    scene.fog = new THREE.Fog("#1a1410", 6, 14);
    const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 50);
    camera.position.set(0, 1.0, 3.6);
    camera.lookAt(0, 0.7, 0);

    scene.add(new THREE.HemisphereLight("#ffe8c8", "#2a1d12", 0.9));
    const key = new THREE.DirectionalLight("#ffd9a0", 2.2);
    key.position.set(2, 4, 3);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.camera.left = -2; key.shadow.camera.right = 2; key.shadow.camera.top = 3; key.shadow.camera.bottom = -1;
    scene.add(key);
    const rim = new THREE.DirectionalLight("#7fa8ff", 1.0);
    rim.position.set(-3, 2, -3);
    scene.add(rim);

    // 程序化木地板圆台
    const tex = document.createElement("canvas");
    tex.width = tex.height = 256;
    const tc = tex.getContext("2d")!;
    for (let y = 0; y < 16; y++) for (let x = 0; x < 4; x++) {
      const off = (y % 2) * 32;
      tc.fillStyle = `hsl(28, ${35 + ((x * 7 + y * 13) % 10)}%, ${32 + ((x * 11 + y * 5) % 9)}%)`;
      tc.fillRect(x * 64 + off - 32, y * 16, 63, 15);
      tc.fillRect(x * 64 + off + 224, y * 16, 63, 15);
    }
    const ft = new THREE.CanvasTexture(tex);
    ft.wrapS = ft.wrapT = THREE.RepeatWrapping; ft.repeat.set(3, 3);
    ft.colorSpace = THREE.SRGBColorSpace;
    const floor = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.35, 0.08, 48), new THREE.MeshStandardMaterial({ map: ft, roughness: 0.8 }));
    floor.position.y = -0.04;
    floor.receiveShadow = true;
    scene.add(floor);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.33, 0.015, 8, 64), new THREE.MeshStandardMaterial({ color: "#d3b56b", metalness: 0.7, roughness: 0.3 }));
    ring.rotation.x = Math.PI / 2;
    scene.add(ring);

    // 椅子（坐姿用）
    const chair = new THREE.Group();
    const wood = new THREE.MeshStandardMaterial({ color: "#7d5232", roughness: 0.7 });
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.05, 0.42), wood); seat.position.set(0, 0.42, -0.05); chair.add(seat);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.5, 0.04), wood); back.position.set(0, 0.7, -0.25); chair.add(back);
    for (const [x, z] of [[-0.18, -0.23], [0.18, -0.23], [-0.18, 0.13], [0.18, 0.13]]) { const l = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.42, 0.04), wood); l.position.set(x, 0.21, z); chair.add(l); }
    chair.traverse((o) => { (o as THREE.Mesh).castShadow = true; });
    scene.add(chair);
    state.current.chair = chair;

    const rigs = CHARACTERS.map((c) => {
      const r = buildCharacter(c);
      r.root.visible = false;
      scene.add(r.root);
      return r;
    });
    state.current.rigs = rigs;

    const resize = () => {
      const w = el.clientWidth, h = el.clientHeight;
      renderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(el);

    // 拖拽旋转
    let dragging = false, lastX = 0;
    const down = (e: PointerEvent) => { dragging = true; lastX = e.clientX; };
    const move = (e: PointerEvent) => { if (!dragging) return; state.current.targetYaw += (e.clientX - lastX) * 0.01; lastX = e.clientX; };
    const up = () => { dragging = false; };
    renderer.domElement.addEventListener("pointerdown", down);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);

    let raf = 0;
    const clock = new THREE.Clock();
    const loop = () => {
      const t = clock.getElapsedTime();
      const s = state.current;
      if (s.auto) s.targetYaw += 0.008;
      s.yaw += (s.targetYaw - s.yaw) * 0.12;
      rigs.forEach((r, i) => {
        r.root.visible = i === s.idx;
        if (i === s.idx) {
          r.root.rotation.y = s.yaw;
          animateRig(r, t, s.pose);
        }
      });
      chair.visible = s.pose === "sit";
      chair.rotation.y = s.yaw;
      ring.rotation.z = t * 0.1;
      renderer.render(scene, camera);
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      renderer.dispose();
      el.removeChild(renderer.domElement);
    };
  }, []);

  const c = CHARACTERS[idx];
  const ra = (LIFE_RULES.agents as any[]).find((a) => a.id === c.id);
  const lex = LIFE_RULES.lexicon;
  const rotate = (d: number) => { state.current.targetYaw += d; };

  return (
    <div className="flex h-screen flex-col bg-[#15110d] text-[#efe6d6]">
      <div className="flex items-center gap-3 border-b border-[#3b2f24] bg-[#1d1712] px-3 py-2 text-sm">
        <button className="btn" onClick={onBack}>← 返回</button>
        <span className="font-serif text-base tracking-wider text-[#e9c98a]">五人角色模型</span>
        <span className="text-xs text-[#8f7d66]">模型由代码程序化生成 · 统一身高 1.32（按 character_models.dv 比例缩放）</span>
      </div>
      <div className="flex min-h-0 flex-1 flex-col md:flex-row">
        <div className="relative min-h-[50vh] flex-1">
          <div ref={mount} className="absolute inset-0 cursor-grab active:cursor-grabbing" />
          <div className="absolute bottom-5 left-1/2 flex -translate-x-1/2 items-center gap-2">
            <button className="btn text-lg" onClick={() => rotate(-Math.PI / 4)}>⟲ 左转</button>
            <button className={`btn ${auto ? "btn-hot" : ""}`} onClick={() => setAuto((a) => !a)}>自动旋转</button>
            <button className="btn text-lg" onClick={() => rotate(Math.PI / 4)}>右转 ⟳</button>
          </div>
          <div className="absolute left-4 top-4 flex gap-1">
            {(["stand", "walk", "sit", "wave"] as Pose[]).map((p) => (
              <button key={p} onClick={() => setPose(p)} className={`rounded px-2.5 py-1 text-xs ${pose === p ? "bg-amber-700" : "bg-black/50 hover:bg-black/70"}`}>
                {{ stand: "站立", walk: "行走", sit: "坐姿", wave: "招手" }[p]}
              </button>
            ))}
          </div>
          <button className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-black/50 px-3 py-2 text-xl hover:bg-black/70" onClick={() => setIdx((idx + CHARACTERS.length - 1) % CHARACTERS.length)}>‹</button>
          <button className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-black/50 px-3 py-2 text-xl hover:bg-black/70" onClick={() => setIdx((idx + 1) % CHARACTERS.length)}>›</button>
        </div>
        <div className="w-full shrink-0 overflow-y-auto border-l border-[#3b2f24] bg-[#1a1410] p-4 md:w-96">
          <div className="mb-4 flex gap-2">
            {CHARACTERS.map((x, i) => (
              <button key={x.id} onClick={() => setIdx(i)} className={`flex flex-1 flex-col items-center rounded p-1 text-[11px] ${i === idx ? "bg-[#3a2d22] ring-1 ring-amber-500/60" : "hover:bg-[#2a2119]"}`}>
                <Portrait id={x.id} size={40} /><span style={{ color: x.color }}>{x.name}</span>
              </button>
            ))}
          </div>
          <div className="font-serif text-2xl" style={{ color: c.color }}>{c.name}</div>
          <div className="mb-3 text-sm text-[#a8957b]">{c.title}</div>
          <div className="mb-3 rounded-lg border border-[#3b2f24] bg-black/20 p-3 text-sm leading-relaxed">
            <div className="text-[11px] text-[#8f7d66]">当前想守住的事</div>
            <div>{c.purpose}</div>
            <div className="mt-2 text-[11px] text-[#8f7d66]">关于过去职业的自述</div>
            <div className="italic text-[#cbb898]">{c.memory}</div>
          </div>
          <div className="mb-3 text-xs">
            <div className="mb-1 text-[11px] text-[#8f7d66]">生活偏好（rules.dv 中显式写明）</div>
            {Object.entries(ra?.weights ?? {}).map(([k, v]) => <span key={k} className="mr-2 inline-block rounded bg-black/30 px-2 py-0.5">{k} ×{v as number}</span>)}
            <div className="mt-2 text-[11px] text-[#8f7d66]">行动动机</div>
            {Object.keys(ra?.action_motives ?? {}).map((k) => <span key={k} className="mr-2 inline-block rounded bg-black/30 px-2 py-0.5">{LIFE_RULES.actions[k]?.label ?? k}</span>)}
            <div className="mt-2 text-[11px] text-[#8f7d66]">社交动机</div>
            {Object.keys(ra?.social_motives ?? {}).map((k) => <span key={k} className="mr-2 inline-block rounded bg-black/30 px-2 py-0.5">{LIFE_RULES.social.categories[k]?.label ?? k}</span>)}
          </div>
          <div className="text-xs">
            <div className="mb-1 text-[11px] text-[#8f7d66]">心中的词义</div>
            {Object.entries(lex.terms).map(([k, t]: [string, any]) => (
              <div key={k} className="flex justify-between border-b border-[#2a2119] py-1"><span>“{t.word}”</span><span className="text-violet-300">{t.senses[lex.agents[c.id]?.[k]]?.label}</span></div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
