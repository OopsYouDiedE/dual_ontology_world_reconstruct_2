import { useState } from "react";
import type { LifeSim } from "../engine/sim";
import { fmtClock, senseLabel } from "../engine/sim";
import { CHARACTERS, CHAR_BY_ID, NEED_LABELS } from "../data/characters";
import { LIFE_RULES } from "../data/rules";
import { Portrait } from "./Portrait";

const GROUPS: [string, string[]][] = [
  ["身体", ["hunger", "thirst", "energy", "hygiene"]],
  ["心理", ["social", "fun", "comfort", "growth", "calm"]],
  ["本人", ["curiosity", "purpose", "agency"]],
];

const STAGE_COLOR: Record<string, string> = { 亲近: "text-pink-300", 友善: "text-emerald-300", 熟识: "text-sky-300", 生疏: "text-stone-400", 敌视: "text-red-400" };

function Bar({ v, label }: { v: number; label: string }) {
  const c = v < 20 ? "bg-red-500" : v < 45 ? "bg-amber-500" : v < 75 ? "bg-lime-500" : "bg-emerald-500";
  return (
    <div className="flex items-center gap-2 text-[11px]">
      <span className="w-14 shrink-0 text-[#cbb898]">{label}</span>
      <div className="h-2 flex-1 overflow-hidden rounded bg-black/40">
        <div className={`h-full ${c} transition-all`} style={{ width: `${Math.max(0, Math.min(100, v))}%` }} />
      </div>
      <span className="w-7 text-right font-mono text-[10px] text-[#a8957b]">{Math.round(v)}</span>
    </div>
  );
}

export function Inspector({ sim, selected, onSelect }: { sim: LifeSim; selected: string; onSelect: (id: string) => void }) {
  const [tab, setTab] = useState<"state" | "rel" | "mind" | "act">("state");
  const a = sim.agent(selected);
  const prof = CHAR_BY_ID[selected];
  const cands = tab === "act" ? sim.authorCandidates(a) : [];
  const myCommit = sim.commitments.filter((c) => !c.resolved && (c.from === a.id || c.to === a.id));

  return (
    <div className="flex w-[330px] shrink-0 flex-col border-r border-[#3b2f24] bg-[#1a1410]">
      <div className="flex gap-1 border-b border-[#3b2f24] p-2">
        {CHARACTERS.map((c) => (
          <button key={c.id} onClick={() => onSelect(c.id)} title={c.name}
            className={`flex flex-1 flex-col items-center rounded-md p-1 text-[11px] transition ${selected === c.id ? "bg-[#3a2d22] ring-1 ring-amber-500/60" : "hover:bg-[#2a2119]"}`}>
            <Portrait id={c.id} size={34} />
            <span style={{ color: c.color }}>{c.name}</span>
          </button>
        ))}
      </div>
      <div className="border-b border-[#3b2f24] p-3">
        <div className="flex items-baseline justify-between">
          <div className="font-serif text-lg" style={{ color: prof.color }}>{prof.name}<span className="ml-2 text-xs text-[#a8957b]">{prof.title}</span></div>
          <div className="text-xs text-[#cbb898]">心情 <b className="text-[#ffe2a8]">{Math.round(a.mood)}</b> · 压力 {Math.round(a.stress * 100)}%</div>
        </div>
        <div className="mt-1 rounded bg-black/25 px-2 py-1.5 text-xs">
          <span className="text-[#a8957b]">当前：</span>
          {a.action ? <b>{a.action.label}</b> : a.plan ? <b>前往 · {a.plan.cand.label}</b> : <span>空闲</span>}
          {a.action && <span className="ml-1 text-[#a8957b]">（剩 {Math.ceil(a.action.remaining)} 分）</span>}
          <span className="ml-1 text-[#a8957b]">@ {sim.roomName(a.room)}</span>
          {a.lastReason && <div className="mt-0.5 text-[10px] text-[#8f7d66]">依据：{a.lastReason}</div>}
        </div>
      </div>
      <div className="flex border-b border-[#3b2f24] text-xs">
        {([["state", "需要"], ["rel", "关系"], ["mind", "认知"], ["act", "提交行动"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`flex-1 py-2 ${tab === k ? "border-b-2 border-amber-500 text-amber-300" : "text-[#a8957b] hover:text-[#efe6d6]"}`}>{l}</button>
        ))}
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto p-3 text-xs">
        {tab === "state" && (
          <div className="space-y-3">
            <div className="rounded border border-[#3b2f24] bg-black/20 p-2 leading-relaxed">
              <div className="text-[10px] text-[#a8957b]">本人目的</div>
              <div className="text-[#e6dac6]">{prof.purpose}</div>
              <div className="mt-1.5 text-[10px] text-[#a8957b]">职业记忆</div>
              <div className="italic text-[#cbb898]">{prof.memory}</div>
            </div>
            {GROUPS.map(([g, ns]) => (
              <div key={g} className="space-y-1">
                <div className="text-[10px] uppercase tracking-widest text-[#8f7d66]">{g}</div>
                {ns.map((n) => <Bar key={n} v={a.needs[n]} label={NEED_LABELS[n]} />)}
              </div>
            ))}
            <div className="flex gap-3 text-[11px] text-[#cbb898]">
              <span>口粮 🍞 ×{a.food}</span><span>书 {a.book ? "📖 持有" : "—"}</span>
              <span>床位：{Object.entries(sim.bedOwner).find(([, o]) => o === a.id) ? "有" : "无（需借宿）"}</span>
            </div>
          </div>
        )}
        {tab === "rel" && (
          <div className="space-y-2">
            <div className="text-[10px] text-[#8f7d66]">有向关系：{a.name} 对他人的看法（对方的看法可能不同）</div>
            {Object.entries(a.rel).map(([oid, r]) => {
              const back = sim.agent(oid).rel[a.id];
              return (
                <div key={oid} className="rounded border border-[#3b2f24] bg-black/20 p-2">
                  <div className="mb-1 flex items-center justify-between">
                    <span className="flex items-center gap-1.5"><Portrait id={oid} size={20} /><b style={{ color: CHAR_BY_ID[oid].color }}>{CHAR_BY_ID[oid].name}</b></span>
                    <span className={STAGE_COLOR[r.stage]}>{r.stage}</span>
                  </div>
                  <div className="grid grid-cols-4 gap-1 text-[10px] text-[#cbb898]">
                    <span>好感 {r.affinity.toFixed(1)}</span><span>信任 {r.trust.toFixed(1)}</span><span>紧张 {r.tension.toFixed(1)}</span><span>熟悉 {r.familiarity.toFixed(0)}</span>
                  </div>
                  <div className="mt-1 text-[10px] text-[#8f7d66]">对方看{a.name}：<span className={STAGE_COLOR[back.stage]}>{back.stage}</span>{r.owe > 0 ? ` · 自认欠对方 ${r.owe} 份` : ""}</div>
                </div>
              );
            })}
          </div>
        )}
        {tab === "mind" && (
          <div className="space-y-3">
            <div>
              <div className="mb-1 text-[10px] text-[#8f7d66]">同词异义：{a.name}心中的词义</div>
              {Object.entries(LIFE_RULES.lexicon.terms).map(([k, t]: [string, any]) => (
                <div key={k} className="flex justify-between border-b border-[#2a2119] py-1"><span>“{t.word}”</span><span className="text-violet-300">{senseLabel(k, a.lexicon[k])}</span></div>
              ))}
            </div>
            <div>
              <div className="mb-1 text-[10px] text-[#8f7d66]">本人认知 · 储物柜口粮（可能过时）</div>
              {Object.keys(sim.stock).map((id) => {
                const b = a.beliefs.stock[id];
                return <div key={id} className="flex justify-between py-0.5"><span>{sim.roomName(sim.propRoom[id])}储物柜</span><span className="text-[#cbb898]">{b ? `${b.v} 份（${fmtClock(b.t)} 看到）` : "未知"}</span></div>;
              })}
            </div>
            <div>
              <div className="mb-1 text-[10px] text-[#8f7d66]">当前推理（只依据本人感知）</div>
              {a.beliefs.inferences.length ? a.beliefs.inferences.map((s, i) => <div key={i} className="py-0.5">· {s}</div>) : <div className="text-[#8f7d66]">（无）</div>}
              {a.irritation > 1 && <div className="mt-1 text-amber-300">烦躁值 {a.irritation.toFixed(1)} / {LIFE_RULES.social.irritation.threshold}</div>}
            </div>
            <div>
              <div className="mb-1 text-[10px] text-[#8f7d66]">承诺与期待</div>
              {myCommit.length ? myCommit.map((c) => {
                const isFrom = c.from === a.id;
                const dl = isFrom ? c.fromDeadline : c.toDeadline;
                return (
                  <div key={c.id} className="mb-1 rounded bg-black/25 p-1.5">
                    <div>{isFrom ? `我答应${CHAR_BY_ID[c.to].name}` : `${CHAR_BY_ID[c.from].name}答应我`}：{c.label}</div>
                    <div className="text-[10px] text-[#a8957b]">我心里的期限：{Number.isFinite(dl) ? fmtClock(dl) : "无需归还/无期限"}</div>
                  </div>
                );
              }) : <div className="text-[#8f7d66]">（无）</div>}
            </div>
          </div>
        )}
        {tab === "act" && (
          <div className="space-y-1">
            <div className="mb-2 text-[10px] leading-relaxed text-[#8f7d66]">Core 当前允许 {a.name} 执行的行动（含评分依据）。提交后将打断当前行动，并略微降低其「自主权」。</div>
            {cands.slice(0, 40).map((c, i) => (
              <button key={i} onClick={() => sim.submit(a, c)}
                className="group block w-full rounded border border-[#3b2f24] bg-black/20 p-1.5 text-left hover:border-amber-600 hover:bg-[#2a2119]">
                <div className="flex justify-between">
                  <span className={c.action === "social" ? "text-sky-300" : c.action === "fulfil" ? "text-violet-300" : ""}>
                    {c.label}{c.propId ? ` · ${sim.roomName(sim.propRoom[c.propId])}` : ""}
                  </span>
                  <span className="font-mono text-[10px] text-amber-300">{c.score.toFixed(2)}</span>
                </div>
                <div className="truncate text-[10px] text-[#8f7d66] group-hover:whitespace-normal">{c.parts.join("，")}</div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
