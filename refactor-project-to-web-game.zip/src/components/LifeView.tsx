import { useCallback, useEffect, useRef, useState } from "react";
import { LifeSim, fmtTime, END_MIN, START_MIN } from "../engine/sim";
import type { BuildingData, PropData } from "../engine/types";
import {
  darkness, drawAgent, drawBubble, drawFloor, drawStockBadge, drawLighting, drawProp, drawRoomLabels, drawWalls, fitView, sortedProps,
  type View, type WallMode,
} from "../engine/render";
import { pointInProp } from "../engine/geometry";
import { Inspector } from "./Inspector";
import { LogPanel } from "./LogPanel";
import { KIND_LABELS } from "../data/characters";
import { LIFE_RULES } from "../data/rules";
import { Modal } from "./Modal";
import { Report } from "./Report";

const SPEEDS = [1, 10, 30, 60, 120, 240];
const BASE = LIFE_RULES.time.minutes_per_second as number; // 0.5 内容分钟/秒

const ICONS: Record<string, string> = {
  sleep: "💤", nap: "😴", rest: "🪑", prepare_meal: "🍳", eat_meal: "🍽", eat_standing: "🥪", drink: "💧", wash: "🧼",
  study: "✍", read: "📚", play_piano: "🎹", paint: "🎨", admire: "🖼", tend_plant: "🌱", light_lamp: "🕯", douse_lamp: "🌑",
  wander: "", hangout: "💬", read_seated: "📖", return_book: "📚", inspect_pantry: "🔍", join_seat: "🤝",
};

interface Props {
  building: BuildingData;
  origin: "menu" | "editor";
  onExit: () => void;
  initialSave?: string | null;
}

export function LifeView({ building, origin, onExit, initialSave }: Props) {
  const simRef = useRef<LifeSim | null>(null);
  if (!simRef.current) {
    simRef.current = initialSave ? LifeSim.deserialize(initialSave) : new LifeSim(JSON.parse(JSON.stringify(building)));
  }
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const staticRef = useRef<HTMLCanvasElement | null>(null);
  const viewRef = useRef<View>({ scale: 50, ox: 0, oy: 0 });
  const [, setTick] = useState(0);
  const [paused, setPaused] = useState(false);
  const [speed, setSpeed] = useState(30);
  const [wallMode, setWallMode] = useState<WallMode>("full");
  const [selected, setSelected] = useState<string>("detective");
  const [propInfo, setPropInfo] = useState<PropData | null>(null);
  const [modal, setModal] = useState<null | "save" | "load" | "goals" | "rules" | "help">(null);
  const [showReport, setShowReport] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const pausedRef = useRef(paused);
  const speedRef = useRef(speed);
  const selRef = useRef(selected);
  const wallRef = useRef(wallMode);
  pausedRef.current = paused || modal !== null || showReport;
  speedRef.current = speed;
  selRef.current = selected;

  const flash = (s: string) => { setToast(s); setTimeout(() => setToast(null), 2200); };

  const rebuildStatic = useCallback(() => {
    const cv = canvasRef.current, sim = simRef.current!;
    if (!cv) return;
    const st = staticRef.current ?? document.createElement("canvas");
    staticRef.current = st;
    st.width = cv.width; st.height = cv.height;
    const ctx = st.getContext("2d")!;
    const v = viewRef.current;
    drawFloor(ctx, sim.geo, v);
    drawRoomLabels(ctx, sim.geo, v);
    for (const p of sortedProps(sim.building)) {
      if (p.kind === "wall_lantern" || p.kind === "pendant_lamp") continue;
      drawProp(ctx, p, v);
    }
    drawWalls(ctx, sim.building, v, wallRef.current);
  }, []);

  useEffect(() => { wallRef.current = wallMode; rebuildStatic(); }, [wallMode, rebuildStatic]);

  // 尺寸
  useEffect(() => {
    const resize = () => {
      const cv = canvasRef.current, wrap = wrapRef.current;
      if (!cv || !wrap) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const w = wrap.clientWidth, h = wrap.clientHeight;
      cv.width = Math.floor(w * dpr); cv.height = Math.floor(h * dpr);
      cv.style.width = w + "px"; cv.style.height = h + "px";
      viewRef.current = fitView(simRef.current!.building, cv.width, cv.height, 40 * dpr);
      rebuildStatic();
    };
    resize();
    const ro = new ResizeObserver(resize);
    if (wrapRef.current) ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, [rebuildStatic]);

  // 主循环
  useEffect(() => {
    let raf = 0, last = performance.now(), uiAcc = 0, wasEnded = false;
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      const sim = simRef.current!;
      if (!pausedRef.current && !sim.ended) sim.step(dt * BASE * speedRef.current);
      if (sim.ended && !wasEnded) { wasEnded = true; setShowReport(true); }
      draw(now / 1000);
      uiAcc += dt;
      if (uiAcc > 0.2) { uiAcc = 0; setTick((x) => x + 1); }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function draw(time: number) {
    const cv = canvasRef.current, sim = simRef.current!;
    if (!cv) return;
    const ctx = cv.getContext("2d")!;
    const v = viewRef.current;
    ctx.clearRect(0, 0, cv.width, cv.height);
    if (staticRef.current) ctx.drawImage(staticRef.current, 0, 0);
    // 动态家具
    for (const p of sim.building.props) {
      if (p.kind === "wall_lantern") drawProp(ctx, p, v, { lit: sim.lamps[p.id] });
      if (p.kind === "pendant_lamp") drawProp(ctx, p, v, { lit: sim.roomLit(sim.propRoom[p.id]) && !sim.isDay() });
    }
    // 选中人物路径
    const sel = sim.agents.find((a) => a.id === selRef.current);
    if (sel && sel.path.length) {
      ctx.save();
      ctx.strokeStyle = sel.color; ctx.globalAlpha = 0.7; ctx.lineWidth = 2; ctx.setLineDash([6, 5]);
      ctx.beginPath(); ctx.moveTo(v.ox + sel.x * v.scale, v.oy + sel.z * v.scale);
      for (const p of sel.path) ctx.lineTo(v.ox + p[0] * v.scale, v.oy + p[1] * v.scale);
      ctx.stroke(); ctx.restore();
    }
    // 琴声
    for (const a of sim.agents) {
      if (a.action?.key === "play_piano") {
        ctx.save();
        const ph = (time * 1.2) % 1;
        ctx.strokeStyle = `rgba(255,220,120,${1 - ph})`; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(v.ox + a.x * v.scale, v.oy + a.z * v.scale, v.scale * (0.5 + ph * 3.5), 0, Math.PI * 2); ctx.stroke();
        ctx.restore();
      }
    }
    const draws = sim.agents.map((a) => ({
      id: a.id, name: a.name, color: a.color, x: a.x, z: a.z, facing: a.facing,
      pose: a.action ? a.action.pose : "stand", walking: a.path.length > 0,
      icon: a.action ? ICONS[a.action.key] : a.plan ? "" : "", selected: a.id === selRef.current,
      bubble: a.bubble, food: a.food > 0, book: a.book, t: sim.t * 6,
    }));
    for (const d of draws) drawAgent(ctx, d, v);
    // 光照
    const lights: { x: number; z: number; r: number; k: number }[] = [];
    for (const p of sim.building.props) {
      if (p.kind === "wall_lantern" && sim.lamps[p.id]) lights.push({ x: p.x, z: p.z, r: 5, k: 0.95 });
      if ((p.kind === "pendant_lamp" || p.kind === "banker_lamp") && sim.roomLit(sim.propRoom[p.id]) && sim.building.props.some((q) => q.kind === "wall_lantern" && sim.propRoom[q.id] === sim.propRoom[p.id])) lights.push({ x: p.x, z: p.z, r: 3.5, k: 0.8 });
    }
    drawLighting(ctx, cv.width, cv.height, darkness(sim.hour), lights, v);
    // 库存徽章（作者视角：真实库存）
    for (const id of Object.keys(sim.stock)) drawStockBadge(ctx, sim.props[id], v, sim.stock[id]);
    for (const d of draws) drawBubble(ctx, d, v);
  }

  const onCanvasClick = (e: React.MouseEvent) => {
    const cv = canvasRef.current!, sim = simRef.current!;
    const rect = cv.getBoundingClientRect();
    const dpr = cv.width / rect.width;
    const v = viewRef.current;
    const x = ((e.clientX - rect.left) * dpr - v.ox) / v.scale, z = ((e.clientY - rect.top) * dpr - v.oy) / v.scale;
    let best: string | null = null, bd = 0.6;
    for (const a of sim.agents) { const d = Math.hypot(a.x - x, a.z - z); if (d < bd) { bd = d; best = a.id; } }
    if (best) { setSelected(best); setPropInfo(null); return; }
    const p = [...sim.building.props].reverse().find((q) => q.kind !== "rug" && pointInProp(q, x, z, 0.08));
    setPropInfo(p ?? null);
  };

  const sim = simRef.current!;
  const night = sim.isNight();
  const progress = Math.min(1, (sim.t - START_MIN) / (END_MIN - START_MIN));

  const saveSlot = (n: number) => {
    localStorage.setItem(`dowr2.save.${n}`, sim.serialize());
    localStorage.setItem(`dowr2.meta.${n}`, JSON.stringify({ time: fmtTime(sim.t), at: new Date().toLocaleString(), name: sim.building.name }));
    setModal(null); flash(`已存档至槽位 ${n}`);
  };
  const loadSlot = (n: number) => {
    const s = localStorage.getItem(`dowr2.save.${n}`);
    if (!s) return;
    try {
      simRef.current = LifeSim.deserialize(s);
      viewRef.current = fitView(simRef.current.building, canvasRef.current!.width, canvasRef.current!.height, 40);
      rebuildStatic();
      setModal(null); flash(`已读取槽位 ${n}`);
    } catch { flash("存档损坏，读取失败"); }
  };

  return (
    <div className="flex h-screen flex-col bg-[#15110d] text-[#efe6d6]">
      {/* 顶栏 */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[#3b2f24] bg-[#1d1712] px-3 py-2 text-sm">
        <button className="btn" onClick={onExit}>← {origin === "editor" ? "返回建筑器" : "主菜单"}</button>
        <div className="ml-1 font-serif text-base tracking-wider text-[#e9c98a]">{LIFE_RULES.scenario_label ?? "五人生活推演"}</div>
        <div className="mx-2 flex items-center gap-2 rounded-md bg-black/30 px-3 py-1 font-mono">
          <span>{night ? "🌙" : sim.isDusk() ? "🌆" : "☀️"}</span>
          <span className="text-[#ffe2a8]">{fmtTime(sim.t)}</span>
        </div>
        <div className="hidden h-2 w-32 overflow-hidden rounded bg-black/40 md:block" title="五日观察进度">
          <div className="h-full bg-gradient-to-r from-amber-600 to-amber-300" style={{ width: `${progress * 100}%` }} />
        </div>
        <button className={`btn ${paused ? "btn-hot" : ""}`} onClick={() => setPaused((p) => !p)}>{paused ? "▶ 继续" : "⏸ 暂停"}</button>
        <div className="flex overflow-hidden rounded-md border border-[#4a3b2d]">
          {SPEEDS.map((s) => (
            <button key={s} onClick={() => setSpeed(s)} className={`px-2 py-1 text-xs ${speed === s ? "bg-amber-700 text-white" : "bg-[#2a2119] hover:bg-[#3a2d22]"}`}>×{s}</button>
          ))}
        </div>
        <div className="ml-auto flex flex-wrap gap-2">
          <button className="btn" onClick={() => setModal("save")}>💾 存档</button>
          <button className="btn" onClick={() => setModal("load")}>📂 读档</button>
          <button className="btn" onClick={() => { sim.reloadContent(); rebuildStatic(); flash("兼容内容重载完成"); }}>⟳ 内容重载</button>
          <button className="btn" onClick={() => setWallMode((m) => (m === "full" ? "low" : m === "low" ? "hidden" : "full"))}>
            🧱 墙体：{wallMode === "full" ? "完整" : wallMode === "low" ? "矮墙" : "隐藏"}
          </button>
          <button className="btn" onClick={() => setModal("goals")}>🎯 观察目标 {sim.goals.filter((g) => g.done).length}/{sim.goals.length}</button>
          <button className="btn" onClick={() => setModal("rules")}>📜 规则</button>
          <button className="btn" onClick={() => setModal("help")}>？</button>
        </div>
      </div>

      <div className="flex min-h-0 flex-1">
        <Inspector sim={sim} selected={selected} onSelect={setSelected} />
        <div ref={wrapRef} className="relative min-w-0 flex-1">
          <canvas ref={canvasRef} onClick={onCanvasClick} className="block cursor-pointer" />
          {propInfo && (
            <div className="absolute bottom-3 left-3 w-64 rounded-lg border border-[#5a4633] bg-[#1d1712]/95 p-3 text-xs shadow-xl">
              <div className="mb-1 flex items-center justify-between">
                <span className="font-bold text-[#e9c98a]">{KIND_LABELS[propInfo.kind] ?? propInfo.kind}</span>
                <button onClick={() => setPropInfo(null)} className="opacity-60 hover:opacity-100">✕</button>
              </div>
              <div>位置：{sim.roomName(sim.propRoom[propInfo.id])}</div>
              {propInfo.id in sim.stock && <div>真实库存：{sim.stock[propInfo.id]} 份口粮（容量 {LIFE_RULES.inventory.capacity}）</div>}
              {propInfo.kind === "wall_lantern" && <div>灯：{sim.lamps[propInfo.id] ? "亮" : "灭"}</div>}
              {propInfo.kind === "bed" && <div>床主：{sim.bedOwner[propInfo.id] ? sim.agent(sim.bedOwner[propInfo.id]).name : "无"}</div>}
              <div>使用中：{(sim.occ[propInfo.id] ?? []).map((id) => sim.agent(id).name).join("、") || "无"}</div>
              <div className="mt-1 text-[10px] text-[#a8957b]">
                可进行：{Object.entries(LIFE_RULES.actions).filter(([, d]: [string, any]) => d.kinds?.includes(propInfo.kind)).map(([, d]: [string, any]) => d.label).join("、") || "—"}
              </div>
            </div>
          )}
          {toast && <div className="pointer-events-none absolute left-1/2 top-4 -translate-x-1/2 rounded-full bg-amber-700/90 px-4 py-1.5 text-sm shadow-lg">{toast}</div>}
          {paused && <div className="pointer-events-none absolute right-4 top-4 rounded bg-black/60 px-3 py-1 text-sm">已暂停</div>}
        </div>
        <LogPanel sim={sim} selected={selected} />
      </div>

      {modal === "save" && (
        <Modal title="存档" onClose={() => setModal(null)}>
          <SlotList onPick={saveSlot} mode="save" />
        </Modal>
      )}
      {modal === "load" && (
        <Modal title="读档" onClose={() => setModal(null)}>
          <SlotList onPick={loadSlot} mode="load" />
        </Modal>
      )}
      {modal === "goals" && (
        <Modal title="五日观察目标" onClose={() => setModal(null)}>
          <div className="space-y-2">
            {sim.goals.map((g) => (
              <div key={g.id} className={`flex items-start gap-3 rounded-lg border p-3 ${g.done ? "border-emerald-600/60 bg-emerald-900/20" : "border-[#4a3b2d] bg-black/20"}`}>
                <span className="text-xl">{g.done ? "✅" : "⬜"}</span>
                <div><div className="font-bold">{g.label}</div><div className="text-xs text-[#bfae94]">{g.desc}</div></div>
              </div>
            ))}
            <div className="pt-2 text-xs text-[#a8957b]">
              互为友善的组合：{sim.friendlyPairs()} · 词义分歧：{sim.stats.ontology} · 兑现承诺：{sim.stats.fulfilled} · 落空：{sim.stats.broken} · 作者干预：{sim.stats.authorActs}
            </div>
          </div>
        </Modal>
      )}
      {modal === "rules" && (
        <Modal title="生活规则（rules.dv）" onClose={() => setModal(null)} wide>
          <RulesView />
        </Modal>
      )}
      {modal === "help" && (
        <Modal title="玩法说明" onClose={() => setModal(null)}>
          <div className="space-y-2 text-sm leading-relaxed text-[#e6dac6]">
            <p>你是这座宅邸的<b>作者</b>。侦探、雀儿、卢西安、阮清月、沈鼐五人依据各自的需要、动机与认知<b>自主</b>生活，你可以只观察，也可以在左侧检查器中向某人提交 Core 当前允许的行动。</p>
            <p>口粮有限：每日 06:00 补给 12 份，五人却要吃得更多。分享、请求、让座、抱怨噪音，都会经过对方的六种回应之一：接受、勉强答应、延后答应、婉拒、冷处理、对抗斥责。</p>
            <p><b>同词异义</b>：“借/分一点”“小声点”“待会儿”在不同人心里对应不同事实。世界只记录各人的理解与实际行动——分歧只在期待落空时才显现，这些时刻会在日志里以紫色标出。</p>
            <p>点击人物选中；点击家具查看信息。顶部可暂停、调倍率、存读档、切换墙体显示。观察至第五日结束将得到观察报告。</p>
          </div>
        </Modal>
      )}
      {showReport && <Report sim={sim} onClose={() => setShowReport(false)} onExit={onExit} />}
    </div>
  );
}

function SlotList({ onPick, mode }: { onPick: (n: number) => void; mode: "save" | "load" }) {
  return (
    <div className="space-y-2">
      {[1, 2, 3].map((n) => {
        const meta = localStorage.getItem(`dowr2.meta.${n}`);
        const m = meta ? JSON.parse(meta) : null;
        const disabled = mode === "load" && !m;
        return (
          <button key={n} disabled={disabled} onClick={() => onPick(n)} className="flex w-full items-center justify-between rounded-lg border border-[#4a3b2d] bg-black/20 p-3 text-left hover:bg-[#3a2d22] disabled:opacity-40">
            <span className="font-bold">槽位 {n}</span>
            <span className="text-xs text-[#bfae94]">{m ? `${m.name} · ${m.time} · ${m.at}` : "空"}</span>
          </button>
        );
      })}
    </div>
  );
}

function RulesView() {
  const acts = Object.entries(LIFE_RULES.actions) as [string, any][];
  return (
    <div className="max-h-[65vh] space-y-4 overflow-auto pr-2 text-xs">
      <p className="text-[#bfae94]">{LIFE_RULES._comment}</p>
      <table className="w-full border-collapse">
        <thead><tr className="text-left text-[#e9c98a]"><th className="p-1">行动</th><th>对象</th><th>时长(分)</th><th>效果/分钟</th><th>条件</th></tr></thead>
        <tbody>
          {acts.map(([k, d]) => (
            <tr key={k} className="border-t border-[#3b2f24]">
              <td className="p-1 font-bold">{d.label}</td>
              <td>{(d.kinds ?? []).map((x: string) => KIND_LABELS[x] ?? x).join("/") || "—"}</td>
              <td>{d.dur?.join("–")}</td>
              <td>{Object.entries(d.fx ?? {}).map(([n, v]) => `${n}${(v as number) > 0 ? "+" : ""}${v}`).join(" ")}</td>
              <td>{Object.entries(d.when ?? {}).map(([n, v]) => `${n}<${v}`).join(" ")}{d.requires ? ` 需${d.requires}` : ""}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div>
        <div className="mb-1 font-bold text-[#e9c98a]">同词异义词典</div>
        {Object.entries(LIFE_RULES.lexicon.terms).map(([k, t]: [string, any]) => (
          <div key={k} className="mb-1">“{t.word}”：{Object.values(t.senses).map((s: any) => s.label).join(" ｜ ")}</div>
        ))}
        <p className="text-[#bfae94]">{LIFE_RULES.lexicon._comment}</p>
      </div>
    </div>
  );
}
