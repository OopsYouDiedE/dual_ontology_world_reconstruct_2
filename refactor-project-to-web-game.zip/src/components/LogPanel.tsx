import { useEffect, useRef, useState } from "react";
import type { LifeSim } from "../engine/sim";
import { fmtClock } from "../engine/sim";
import { CHAR_BY_ID } from "../data/characters";

const FILTERS = [
  ["all", "全部"],
  ["social", "对话"],
  ["ontology", "分歧"],
  ["promise", "承诺"],
  ["mine", "选中者"],
] as const;

const KIND_STYLE: Record<string, string> = {
  action: "text-[#d8cbb4]",
  social: "text-sky-200",
  reply: "text-sky-300/80 pl-3",
  system: "text-amber-200/80",
  ontology: "text-violet-200 bg-violet-900/30 border-l-2 border-violet-400 pl-2",
  promise: "text-emerald-200/90",
  author: "text-amber-400",
};

export function LogPanel({ sim, selected }: { sim: LifeSim; selected: string }) {
  const [filter, setFilter] = useState<(typeof FILTERS)[number][0]>("all");
  const ref = useRef<HTMLDivElement>(null);
  const [stick, setStick] = useState(true);
  const items = sim.log.filter((l) => {
    if (filter === "all") return true;
    if (filter === "social") return l.kind === "social" || l.kind === "reply";
    if (filter === "mine") return l.who?.includes(selected);
    return l.kind === filter;
  }).slice(-200);

  useEffect(() => {
    if (stick && ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  });

  let lastDay = -1;
  return (
    <div className="hidden w-[320px] shrink-0 flex-col border-l border-[#3b2f24] bg-[#1a1410] lg:flex">
      <div className="flex items-center justify-between border-b border-[#3b2f24] px-3 py-2">
        <span className="font-serif text-sm text-[#e9c98a]">生活日志</span>
        <span className="text-[10px] text-[#8f7d66]">分歧 {sim.stats.ontology} · 兑现 {sim.stats.fulfilled} · 落空 {sim.stats.broken}</span>
      </div>
      <div className="flex gap-1 border-b border-[#3b2f24] p-1.5">
        {FILTERS.map(([k, l]) => (
          <button key={k} onClick={() => setFilter(k)} className={`flex-1 rounded px-1 py-1 text-[11px] ${filter === k ? "bg-amber-700 text-white" : "bg-[#2a2119] text-[#bfae94] hover:bg-[#3a2d22]"}`}>{l}</button>
        ))}
      </div>
      <div ref={ref} onScroll={(e) => { const el = e.currentTarget; setStick(el.scrollHeight - el.scrollTop - el.clientHeight < 40); }}
        className="min-h-0 flex-1 space-y-1 overflow-y-auto p-2 text-[11.5px] leading-snug">
        {items.map((l, i) => {
          const day = Math.floor(l.t / 1440) + 1;
          const header = day !== lastDay;
          lastDay = day;
          return (
            <div key={i}>
              {header && <div className="my-2 text-center text-[10px] tracking-[0.3em] text-[#8f7d66]">— 第 {day} 日 —</div>}
              <div className={`rounded py-0.5 ${KIND_STYLE[l.kind]}`}>
                <span className="mr-1 font-mono text-[10px] text-[#7d6c57]">{fmtClock(l.t)}</span>
                {l.kind === "ontology" && <span className="mr-1">◈ 同词异义</span>}
                {l.text}
              </div>
            </div>
          );
        })}
        {!items.length && <div className="p-4 text-center text-[#8f7d66]">暂无记录</div>}
      </div>
      <div className="border-t border-[#3b2f24] p-2 text-[10px] text-[#8f7d66]">
        {sim.agents.map((a) => (
          <span key={a.id} className="mr-2" style={{ color: CHAR_BY_ID[a.id].color }}>■ {a.name}</span>
        ))}
      </div>
    </div>
  );
}
