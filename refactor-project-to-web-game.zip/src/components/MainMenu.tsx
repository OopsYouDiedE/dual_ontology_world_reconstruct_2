import { useEffect, useRef, useState } from "react";
import { LifeSim } from "../engine/sim";
import { DEFAULT_BUILDING } from "../data/house";
import { darkness, drawAgent, drawFloor, drawLighting, drawProp, drawWalls, fitView, sortedProps } from "../engine/render";
import { CHARACTERS } from "../data/characters";
import { Portrait } from "./Portrait";
import { Modal } from "./Modal";

interface Props {
  onNewLife: (seed: number) => void;
  onLoad: (save: string) => void;
  onEditor: () => void;
  onGallery: () => void;
}

export function MainMenu({ onNewLife, onLoad, onEditor, onGallery }: Props) {
  const cvRef = useRef<HTMLCanvasElement>(null);
  const [modal, setModal] = useState<null | "load" | "about" | "new">(null);
  const [seed, setSeed] = useState(7);

  useEffect(() => {
    const cv = cvRef.current!;
    const sim = new LifeSim(JSON.parse(JSON.stringify(DEFAULT_BUILDING)), Math.floor(Math.random() * 1000));
    sim.step(60 * 3);
    let raf = 0, last = performance.now();
    const st = document.createElement("canvas");
    let view = fitView(sim.building, 100, 100);
    const resize = () => {
      cv.width = window.innerWidth; cv.height = window.innerHeight;
      st.width = cv.width; st.height = cv.height;
      view = fitView(sim.building, cv.width, cv.height, 20);
      view.scale *= 1.1;
      view.ox = (cv.width - sim.building.width * view.scale) / 2;
      view.oy = (cv.height - sim.building.depth * view.scale) / 2;
      const c = st.getContext("2d")!;
      drawFloor(c, sim.geo, view);
      for (const p of sortedProps(sim.building)) drawProp(c, p, view);
      drawWalls(c, sim.building, view, "full");
    };
    resize();
    window.addEventListener("resize", resize);
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      sim.step(dt * 12);
      if (sim.ended) { sim.ended = false; sim.t = 420 + 1440; }
      const ctx = cv.getContext("2d")!;
      ctx.drawImage(st, 0, 0);
      for (const a of sim.agents) drawAgent(ctx, { id: a.id, name: a.name, color: a.color, x: a.x, z: a.z, facing: a.facing, pose: a.action?.pose ?? "stand", walking: a.path.length > 0, t: sim.t * 6 }, view);
      const lights = sim.building.props.filter((p) => p.kind === "wall_lantern" && sim.lamps[p.id]).map((p) => ({ x: p.x, z: p.z, r: 5, k: 0.9 }));
      drawLighting(ctx, cv.width, cv.height, darkness(sim.hour), lights, view);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, []);

  const slots = [1, 2, 3].map((n) => {
    const m = localStorage.getItem(`dowr2.meta.${n}`);
    return { n, meta: m ? JSON.parse(m) : null };
  });

  return (
    <div className="relative h-screen overflow-hidden bg-black text-[#efe6d6]">
      <canvas ref={cvRef} className="absolute inset-0 opacity-50 blur-[1.5px]" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/60 to-black/20" />
      <div className="relative flex h-full flex-col justify-center px-8 md:px-20">
        <div className="text-xs tracking-[0.6em] text-[#a8957b]">DUAL ONTOLOGY WORLD · RECONSTRUCT II</div>
        <h1 className="mt-3 font-serif text-5xl leading-tight tracking-wider text-[#ffe2a8] drop-shadow md:text-6xl">双本体世界<span className="text-[#d3b56b]">·</span>重构</h1>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-[#cbb898]">
          一座宅邸，五个人，有限的口粮。每个人只依据自己的认知行动；同一个词，在不同人心里是不同的事实——分歧只在期待落空时才显现。
        </p>
        <div className="mt-5 flex gap-2">
          {CHARACTERS.map((c) => (
            <div key={c.id} className="flex flex-col items-center gap-1 text-[11px]" title={c.purpose}>
              <Portrait id={c.id} size={46} />
              <span style={{ color: c.color }}>{c.name}</span>
            </div>
          ))}
        </div>
        <div className="mt-8 flex w-72 flex-col gap-2">
          <button className="menu-btn menu-btn-main" onClick={() => setModal("new")}>开始生活新局</button>
          <button className="menu-btn" onClick={() => setModal("load")} disabled={!slots.some((s) => s.meta)}>继续 · 读取存档</button>
          <button className="menu-btn" onClick={onEditor}>建筑设计器</button>
          <button className="menu-btn" onClick={onGallery}>角色模型</button>
          <button className="menu-btn" onClick={() => setModal("about")}>关于本作</button>
        </div>
        <div className="mt-10 text-[10px] text-[#7d6c57]">全部画面、模型与家具均由代码程序化生成 · 规则数据移植自原项目 DV 文件</div>
      </div>

      {modal === "new" && (
        <Modal title="五人生活新局" onClose={() => setModal(null)}>
          <div className="space-y-3 text-sm">
            <p className="text-[#cbb898]">场景：1F 示范住宅（五间房）。观察窗：第一日 07:00 至第五日结束。你可以只观察，也可以作为作者向任一人物提交行动。</p>
            <label className="block text-xs">随机种子（规则默认 7，同一种子可复现）
              <div className="mt-1 flex gap-2">
                <input type="number" value={seed} onChange={(e) => setSeed(+e.target.value)} className="inp" />
                <button className="btn" onClick={() => setSeed(Math.floor(Math.random() * 99999))}>🎲</button>
              </div>
            </label>
            <button className="menu-btn menu-btn-main w-full" onClick={() => onNewLife(seed)}>入住</button>
          </div>
        </Modal>
      )}
      {modal === "load" && (
        <Modal title="读取存档" onClose={() => setModal(null)}>
          <div className="space-y-2">
            {slots.map(({ n, meta }) => (
              <button key={n} disabled={!meta} onClick={() => { const s = localStorage.getItem(`dowr2.save.${n}`); if (s) onLoad(s); }}
                className="flex w-full items-center justify-between rounded-lg border border-[#4a3b2d] bg-black/20 p-3 text-left hover:bg-[#3a2d22] disabled:opacity-40">
                <span className="font-bold">槽位 {n}</span>
                <span className="text-xs text-[#bfae94]">{meta ? `${meta.name} · ${meta.time}` : "空"}</span>
              </button>
            ))}
          </div>
        </Modal>
      )}
      {modal === "about" && (
        <Modal title="关于本作" onClose={() => setModal(null)}>
          <div className="space-y-2 text-sm leading-relaxed text-[#e6dac6]">
            <p>本作是 Godot .NET 项目 <i>dual_ontology_world_reconstruct_2</i> 的网页游戏重构版。原项目提供“五人生活新局”与建筑设计工具，由 C# Core 依据 DV 规则推演人物自主生活。</p>
            <p>网页版保留了原设计的核心：十二种需要与衰减、基于紧迫度的行动评分与温度采样、有限口粮与每日补给、六种回应、延期与条件承诺、实际座位履行、有向关系账本、本人认知下的推理，以及“同词异义”词典。</p>
            <p>原项目中的 GLB 模型与 Godot 场景被替换为纯代码生成的 2D 宅邸渲染与 three.js 程序化人物模型，整体体积远小于限制。</p>
          </div>
        </Modal>
      )}
    </div>
  );
}
