import type { ReactNode } from "react";

export function Modal({ title, children, onClose, wide }: { title: string; children: ReactNode; onClose: () => void; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm" onClick={onClose}>
      <div
        className={`w-full ${wide ? "max-w-4xl" : "max-w-lg"} rounded-xl border border-[#5a4633] bg-[#1d1712] p-5 text-[#efe6d6] shadow-2xl`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-serif text-lg tracking-wider text-[#e9c98a]">{title}</h2>
          <button onClick={onClose} className="rounded px-2 text-lg opacity-60 hover:opacity-100">✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}
