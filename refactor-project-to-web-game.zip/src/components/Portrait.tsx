import { CHAR_BY_ID } from "../data/characters";

/** 程序化生成的人物头像 */
export function Portrait({ id, size = 40 }: { id: string; size?: number }) {
  const c = CHAR_BY_ID[id];
  if (!c) return null;
  const L = c.look;
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" className="shrink-0 rounded-full" style={{ background: `radial-gradient(circle at 50% 35%, ${c.color}55, #120e0a)` }}>
      {/* 衣领 */}
      <path d="M6 40 Q8 29 20 28 Q32 29 34 40 Z" fill={L.coat} />
      <path d="M16 28 L20 34 L24 28" fill={L.accent} />
      {/* 脸 */}
      <ellipse cx="20" cy="19" rx="8" ry="9" fill={L.skin} />
      {/* 发型 */}
      {L.hairStyle === "short" && <path d="M12 17 Q12 9 20 9 Q28 9 28 17 Q25 13 20 13 Q15 13 12 17Z" fill={L.hair} />}
      {L.hairStyle === "buns" && (<g fill={L.hair}><circle cx="12" cy="10" r="4" /><circle cx="28" cy="10" r="4" /><path d="M11.5 19 Q11 9 20 9.5 Q29 9 28.5 19 Q26 13 20 13.5 Q14 13 11.5 19Z" /></g>)}
      {L.hairStyle === "curly" && (<g fill={L.hair}>{[11, 14, 17, 20, 23, 26, 29].map((x, i) => <circle key={i} cx={x} cy={11 + (i % 2) * 1.5} r="3.2" />)}<circle cx="11" cy="16" r="2.6" /><circle cx="29" cy="16" r="2.6" /></g>)}
      {L.hairStyle === "bun" && (<g fill={L.hair}><circle cx="20" cy="7" r="4" /><path d="M11.5 19 Q11 9.5 20 9.5 Q29 9.5 28.5 19 Q27 12 20 12 Q13 12 11.5 19Z" /><rect x="22" y="4" width="8" height="1.2" fill={L.accent} transform="rotate(-25 22 4)" /></g>)}
      {L.hairStyle === "cap" && <path d="M12 17 Q12 11 20 11 Q28 11 28 17 Q24 14.5 20 14.5 Q16 14.5 12 17Z" fill={L.hair} />}
      {L.hat === "fedora" && (<g><ellipse cx="20" cy="12" rx="12" ry="2.6" fill="#2f2a26" /><path d="M13 12 Q13 4 20 4.5 Q27 4 27 12Z" fill="#3c3530" /><rect x="13" y="9.5" width="14" height="1.8" fill={c.color} /></g>)}
      {L.hat === "chef" && (<g fill="#f6f3ea"><rect x="13.5" y="8" width="13" height="5" rx="1" /><circle cx="15" cy="6" r="3.5" /><circle cx="20" cy="4.5" r="4" /><circle cx="25" cy="6" r="3.5" /></g>)}
      {/* 眼睛与嘴 */}
      <ellipse cx="16.8" cy="19.5" rx="1" ry="1.2" fill="#1d1612" />
      <ellipse cx="23.2" cy="19.5" rx="1" ry="1.2" fill="#1d1612" />
      <path d="M17.5 24 Q20 25.5 22.5 24" stroke="#8a4a3a" strokeWidth="0.9" fill="none" strokeLinecap="round" />
      {id === "detective" && <path d="M15 22.5 Q20 21 25 22.5" stroke={L.hair} strokeWidth="0" fill="none" />}
      {id === "lucian" && <path d="M14 30 Q20 33 26 30 L25 33 Q20 35 15 33Z" fill={L.accent} />}
    </svg>
  );
}
