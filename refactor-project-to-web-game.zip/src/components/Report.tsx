import type { LifeSim } from "../engine/sim";
import { CHAR_BY_ID } from "../data/characters";
import { LIFE_RULES } from "../data/rules";
import { Portrait } from "./Portrait";

export function Report({ sim, onClose, onExit }: { sim: LifeSim; onClose: () => void; onExit: () => void }) {
  const done = sim.goals.filter((g) => g.done).length;
  const avgMood = sim.agents.reduce((s, a) => s + a.mood, 0) / sim.agents.length;
  const rank = done >= 9 ? "S · 理想之家" : done >= 7 ? "A · 和睦宅邸" : done >= 5 ? "B · 磕磕绊绊" : done >= 3 ? "C · 各自为营" : "D · 冷屋";
  const modes = LIFE_RULES.social.mode_labels as Record<string, string>;
  const totalModes = Object.values(sim.stats.modes).reduce((a, b) => a + b, 0) || 1;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur">
      <div className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-amber-700/50 bg-gradient-to-b from-[#241b14] to-[#15100c] p-6 text-[#efe6d6] shadow-2xl">
        <div className="text-center">
          <div className="text-xs tracking-[0.5em] text-[#a8957b]">五日生活观察报告</div>
          <div className="mt-2 font-serif text-3xl text-[#ffd98a]">{rank}</div>
          <div className="mt-1 text-sm text-[#bfae94]">完成观察目标 {done} / {sim.goals.length} · 平均心情 {avgMood.toFixed(0)} · 作者干预 {sim.stats.authorActs} 次</div>
        </div>
        <div className="mt-5 grid gap-2 sm:grid-cols-2">
          {sim.goals.map((g) => (
            <div key={g.id} className={`rounded-lg border p-2 text-sm ${g.done ? "border-emerald-600/50 bg-emerald-900/20" : "border-[#4a3b2d] bg-black/20 opacity-70"}`}>
              {g.done ? "✅" : "⬜"} <b>{g.label}</b> <span className="text-xs text-[#bfae94]">{g.desc}</span>
            </div>
          ))}
        </div>
        <div className="mt-5 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
          {[["用餐次数", sim.stats.meals], ["社交请求", sim.stats.requests], ["词义分歧", sim.stats.ontology], ["兑现 / 落空", `${sim.stats.fulfilled} / ${sim.stats.broken}`]].map(([l, v]) => (
            <div key={l as string} className="rounded-lg bg-black/30 p-3 text-center"><div className="text-xl font-bold text-[#ffe2a8]">{v}</div><div className="text-xs text-[#a8957b]">{l}</div></div>
          ))}
        </div>
        <div className="mt-5">
          <div className="mb-2 text-xs text-[#a8957b]">回应分布</div>
          <div className="flex h-4 overflow-hidden rounded">
            {Object.entries(sim.stats.modes).map(([m, n], i) => (
              <div key={m} title={`${modes[m]} ${n}`} style={{ width: `${(n / totalModes) * 100}%`, background: ["#4caf7a", "#9ccc65", "#ffca28", "#ff8a65", "#90a4ae", "#e53935"][["accept", "comply", "defer", "decline", "ignore", "confront"].indexOf(m)] ?? `hsl(${i * 60},50%,50%)` }} />
            ))}
          </div>
          <div className="mt-1 flex flex-wrap gap-3 text-[11px] text-[#bfae94]">
            {Object.entries(sim.stats.modes).map(([m, n]) => <span key={m}>{modes[m]} {n}</span>)}
          </div>
        </div>
        <div className="mt-5">
          <div className="mb-2 text-xs text-[#a8957b]">关系矩阵（行 → 列）</div>
          <table className="w-full text-center text-xs">
            <thead><tr><th></th>{sim.agents.map((a) => <th key={a.id} className="p-1" style={{ color: a.color }}>{a.name}</th>)}</tr></thead>
            <tbody>
              {sim.agents.map((a) => (
                <tr key={a.id}>
                  <td className="p-1 text-left"><span className="flex items-center gap-1"><Portrait id={a.id} size={20} /><span style={{ color: a.color }}>{a.name}</span></span></td>
                  {sim.agents.map((b) => <td key={b.id} className="p-1">{a === b ? "—" : <span title={`好感${a.rel[b.id].affinity.toFixed(1)} 信任${a.rel[b.id].trust.toFixed(1)} 紧张${a.rel[b.id].tension.toFixed(1)}`}>{a.rel[b.id].stage}</span>}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-5">
          <div className="mb-2 text-xs text-[#a8957b]">最令人在意的分歧</div>
          {sim.log.filter((l) => l.kind === "ontology").slice(-4).map((l, i) => <div key={i} className="mb-1 border-l-2 border-violet-400 pl-2 text-xs text-violet-200">{l.text}</div>)}
          {!sim.log.some((l) => l.kind === "ontology") && <div className="text-xs text-[#8f7d66]">五日里，没有哪句话被误会到浮出水面。</div>}
        </div>
        <div className="mt-4 text-xs text-[#a8957b]">最低心情：{sim.agents.map((a) => `${CHAR_BY_ID[a.id].name} ${Math.round(sim.stats.minMood[a.id] ?? 0)}`).join(" · ")}</div>
        <div className="mt-6 flex justify-center gap-3">
          <button className="btn" onClick={onClose}>留在宅邸查看</button>
          <button className="btn btn-hot" onClick={onExit}>结束观察</button>
        </div>
      </div>
    </div>
  );
}
