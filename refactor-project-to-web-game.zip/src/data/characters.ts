// 五人的个人目的与职业记忆引用原项目 assets/data/scenarios/daily-life.dv；
// 外观描述用于程序化生成（替代原 GLB 模型）。

export interface CharacterProfile {
  id: string;
  name: string;
  color: string;
  title: string;
  purpose: string;
  memory: string;
  bed?: string; // 默认床位 prop id
  look: {
    skin: string;
    hair: string;
    coat: string;
    accent: string;
    hairStyle: "short" | "buns" | "curly" | "bun" | "cap";
    hat?: "fedora" | "chef" | "none";
    height: number;
    build: number; // 体型宽度系数
  };
}

export const CHARACTERS: CharacterProfile[] = [
  {
    id: "detective",
    name: "侦探",
    color: "#4f9dde",
    title: "旧案的复查者",
    purpose: "我要找到能被反驳和复查的解释，让别人的选择有真实依据。",
    memory: "旧案里最危险的往往是一句过早的“已经明白”。能解释现有痕迹的说法，还要经得起别的解释。",
    bed: "auto_bed_210884_1",
    look: { skin: "#e8c4a0", hair: "#3a2c22", coat: "#5a6470", accent: "#4f9dde", hairStyle: "short", hat: "fedora", height: 1.36, build: 1.05 },
  },
  {
    id: "quer",
    name: "雀儿",
    color: "#e0709a",
    title: "开锁的手艺人",
    purpose: "我要握住自己的工具和答应别人的权利；愿意帮忙，不等于谁能替我一直答应。",
    memory: "旧锁会骗人，手里的阻力不会。摸到哪一针卡住，就先记哪一针，别把猜测当成锁已经开了。",
    bed: "auto_bed_251292_1",
    look: { skin: "#f2d2b6", hair: "#1e1a1a", coat: "#c4577f", accent: "#ffd27a", hairStyle: "buns", hat: "none", height: 1.22, build: 0.9 },
  },
  {
    id: "lucian",
    name: "卢西安",
    color: "#d3b56b",
    title: "旧沙龙的诗人",
    purpose: "别人可以笑我的诗，不能因为雀儿没有家世，就把她的同意也一并收走。",
    memory: "我在欧洲的旧沙龙里学过十四行诗。格律能让人愿意听下去，却不能替证词作保。",
    look: { skin: "#f0d0b8", hair: "#c9a25a", coat: "#2d3a5a", accent: "#d3b56b", hairStyle: "curly", hat: "none", height: 1.4, build: 0.95 },
  },
  {
    id: "ruan",
    name: "阮清月",
    color: "#86bfa7",
    title: "棋院的拆棋人",
    purpose: "我要试出他人真正肯守的边界，争取判断上的先手；路被堵住，就借堵路的人留下的新条件。",
    memory: "在棋院拆棋，落子后的形状不能冒充落子前就知道的事。看别人肯付什么代价，比听他自称重什么更准。",
    bed: "extra_bed_0",
    look: { skin: "#f4dcc4", hair: "#141414", coat: "#4e8c76", accent: "#e8e2d0", hairStyle: "bun", hat: "none", height: 1.3, build: 0.88 },
  },
  {
    id: "shen",
    name: "沈鼐",
    color: "#a786c7",
    title: "船上的厨子",
    purpose: "我要让伤员和忙碌的人吃到热饭；谁想拿孩子和伤员换一份漂亮结论，我就拦着。",
    memory: "船上做饭，水要算给锅，也要算给人。厨子记得每张嘴，不代表能替每个人决定他该受什么苦。",
    bed: "extra_bed_38",
    look: { skin: "#d8a982", hair: "#2a2420", coat: "#6b5a7e", accent: "#f2efe6", hairStyle: "cap", hat: "chef", height: 1.38, build: 1.2 },
  },
];

export const CHAR_BY_ID: Record<string, CharacterProfile> = Object.fromEntries(CHARACTERS.map((c) => [c.id, c]));

export const NEED_LABELS: Record<string, string> = {
  hunger: "饥饿",
  thirst: "口渴",
  energy: "精力",
  hygiene: "清洁",
  social: "社交",
  fun: "娱乐",
  comfort: "舒适",
  growth: "成长",
  calm: "平静",
  curiosity: "求知",
  purpose: "个人目的",
  agency: "自主权",
};

export const KIND_LABELS: Record<string, string> = {
  bed: "床",
  cabinet: "储物柜",
  table: "桌子",
  chair: "椅子",
  rug: "地毯",
  painting: "画作",
  wall_lantern: "壁灯",
  wash_table: "盥洗台",
  sofa: "沙发",
  round_table: "圆桌",
  bench: "长凳",
  planter: "盆栽",
  upright_piano: "立式钢琴",
  easel: "画架",
  banker_lamp: "台灯",
  bookshelf: "书架",
  chest: "箱子",
  nightstand: "床头柜",
  pendant_lamp: "吊灯",
};
