import * as THREE from "three";
import type { CharacterProfile } from "../data/characters";

export interface Rig {
  root: THREE.Group;
  body: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  head: THREE.Group;
}

const mat = (c: string, rough = 0.7, metal = 0) => new THREE.MeshStandardMaterial({ color: c, roughness: rough, metalness: metal });

function mesh(g: THREE.BufferGeometry, m: THREE.Material, x = 0, y = 0, z = 0) {
  const o = new THREE.Mesh(g, m);
  o.position.set(x, y, z);
  o.castShadow = true;
  o.receiveShadow = true;
  return o;
}

/** 由外观参数程序化生成人物（替代原 GLB）。原点在脚底，朝向 +z。 */
export function buildCharacter(c: CharacterProfile): Rig {
  const L = c.look;
  const b = L.build;
  const skin = mat(L.skin, 0.6);
  const hair = mat(L.hair, 0.85);
  const coat = mat(L.coat, 0.75);
  const accent = mat(L.accent, 0.5);
  const pants = mat(c.id === "ruan" ? L.coat : "#2a2622", 0.8);
  const shoe = mat("#1b1714", 0.4);
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);

  // 腿
  const mkLeg = (side: number) => {
    const g = new THREE.Group();
    g.position.set(0.075 * side * b, 0.78, 0);
    g.add(mesh(new THREE.CylinderGeometry(0.058 * b, 0.05 * b, 0.72, 12), pants, 0, -0.36, 0));
    g.add(mesh(new THREE.BoxGeometry(0.1 * b, 0.07, 0.2), shoe, 0, -0.74, 0.04));
    body.add(g);
    return g;
  };
  const legL = mkLeg(1), legR = mkLeg(-1);

  // 躯干
  const torso = new THREE.Group();
  torso.position.y = 0.78;
  body.add(torso);
  torso.add(mesh(new THREE.CylinderGeometry(0.16 * b, 0.15 * b, 0.56, 16), coat, 0, 0.28, 0));
  torso.add(mesh(new THREE.SphereGeometry(0.16 * b, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2), coat, 0, 0.56, 0));
  // 衣摆
  if (c.id === "detective" || c.id === "lucian") {
    torso.add(mesh(new THREE.CylinderGeometry(0.155 * b, 0.21 * b, 0.42, 16, 1, true), coat, 0, -0.18, 0));
    torso.add(mesh(new THREE.BoxGeometry(0.03, 0.5, 0.02), mat("#1f1c1a"), 0, 0.15, 0.158 * b));
  }
  if (c.id === "ruan") {
    torso.add(mesh(new THREE.CylinderGeometry(0.15 * b, 0.2 * b, 0.62, 16), coat, 0, -0.28, 0));
    torso.add(mesh(new THREE.CylinderGeometry(0.07, 0.08, 0.08, 12), accent, 0, 0.6, 0));
    for (let i = 0; i < 3; i++) torso.add(mesh(new THREE.SphereGeometry(0.012, 6, 6), accent, 0.06 - i * 0.02, 0.48 - i * 0.05, 0.15 * b));
  }
  if (c.id === "quer") {
    torso.add(mesh(new THREE.CylinderGeometry(0.15 * b, 0.19 * b, 0.25, 16), coat, 0, -0.08, 0));
    const belt = mesh(new THREE.TorusGeometry(0.155 * b, 0.018, 8, 24), mat("#5a3a22"), 0, 0.06, 0);
    belt.rotation.x = Math.PI / 2;
    torso.add(belt);
    for (let i = 0; i < 3; i++) torso.add(mesh(new THREE.BoxGeometry(0.035, 0.05, 0.025), mat("#b9a07a", 0.4, 0.6), -0.08 + i * 0.07, 0.03, 0.16 * b));
  }
  if (c.id === "shen") {
    const apron = mesh(new THREE.BoxGeometry(0.24 * b, 0.62, 0.02), accent, 0, 0.12, 0.155 * b);
    torso.add(apron);
    torso.add(mesh(new THREE.CylinderGeometry(0.156 * b, 0.165 * b, 0.12, 16), coat, 0, -0.05, 0));
  }
  if (c.id === "lucian") {
    const scarf = mesh(new THREE.TorusGeometry(0.1, 0.035, 8, 20), accent, 0, 0.6, 0);
    scarf.rotation.x = Math.PI / 2;
    torso.add(scarf);
    torso.add(mesh(new THREE.BoxGeometry(0.06, 0.25, 0.03), accent, 0.05, 0.45, 0.14));
  }
  if (c.id === "detective") {
    torso.add(mesh(new THREE.BoxGeometry(0.1, 0.2, 0.02), mat("#d8d2c4"), 0, 0.46, 0.15 * b));
    torso.add(mesh(new THREE.BoxGeometry(0.03, 0.14, 0.022), accent, 0, 0.44, 0.162 * b));
  }

  // 手臂
  const mkArm = (side: number) => {
    const g = new THREE.Group();
    g.position.set(0.2 * side * b, 0.52, 0);
    g.add(mesh(new THREE.CylinderGeometry(0.045 * b, 0.04 * b, 0.5, 10), coat, 0, -0.25, 0));
    g.add(mesh(new THREE.SphereGeometry(0.045, 10, 8), skin, 0, -0.53, 0));
    torso.add(g);
    return g;
  };
  const armL = mkArm(1), armR = mkArm(-1);

  // 头
  const head = new THREE.Group();
  head.position.y = 0.66;
  torso.add(head);
  head.add(mesh(new THREE.CylinderGeometry(0.045, 0.05, 0.08, 10), skin, 0, 0.02, 0));
  head.add(mesh(new THREE.SphereGeometry(0.13, 24, 18), skin, 0, 0.17, 0));
  const eye = mat("#1d1612", 0.3);
  head.add(mesh(new THREE.SphereGeometry(0.015, 8, 8), eye, 0.045, 0.18, 0.118));
  head.add(mesh(new THREE.SphereGeometry(0.015, 8, 8), eye, -0.045, 0.18, 0.118));
  head.add(mesh(new THREE.BoxGeometry(0.05, 0.008, 0.01), mat("#8a4a3a"), 0, 0.12, 0.125));
  head.add(mesh(new THREE.SphereGeometry(0.02, 8, 8), skin, 0, 0.15, 0.13));

  const cap = (scale = 1.06, phi = Math.PI * 0.55) => {
    const m = mesh(new THREE.SphereGeometry(0.13 * scale, 24, 16, 0, Math.PI * 2, 0, phi), hair, 0, 0.18, -0.008);
    m.rotation.x = -0.25;
    head.add(m);
  };
  switch (L.hairStyle) {
    case "short": cap(1.07, Math.PI * 0.5); break;
    case "buns":
      cap(1.07, Math.PI * 0.55);
      head.add(mesh(new THREE.SphereGeometry(0.055, 12, 10), hair, 0.11, 0.3, -0.02));
      head.add(mesh(new THREE.SphereGeometry(0.055, 12, 10), hair, -0.11, 0.3, -0.02));
      head.add(mesh(new THREE.TorusGeometry(0.03, 0.008, 6, 12), accent, 0.11, 0.3, 0.03));
      break;
    case "curly":
      for (let i = 0; i < 22; i++) {
        const a = (i / 22) * Math.PI * 2, r = 0.12;
        const y = 0.24 + Math.sin(i * 1.7) * 0.03;
        head.add(mesh(new THREE.SphereGeometry(0.045, 8, 8), hair, Math.cos(a) * r * 0.95, a > Math.PI * 0.15 && a < Math.PI * 0.85 ? y + 0.03 : y - 0.04, Math.sin(a) * r * (Math.sin(a) > 0 ? 0.55 : 1)));
      }
      cap(1.04, Math.PI * 0.45);
      break;
    case "bun":
      cap(1.06, Math.PI * 0.55);
      head.add(mesh(new THREE.SphereGeometry(0.06, 12, 10), hair, 0, 0.3, -0.08));
      { const pin = mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.2, 6), accent, 0, 0.3, -0.08); pin.rotation.z = 1.1; head.add(pin); }
      // 长发
      head.add(mesh(new THREE.BoxGeometry(0.22, 0.2, 0.05), hair, 0, 0.1, -0.11));
      break;
    case "cap": cap(1.05, Math.PI * 0.42); break;
  }
  if (L.hat === "fedora") {
    head.add(mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.015, 24), mat("#2f2a26"), 0, 0.27, 0));
    head.add(mesh(new THREE.CylinderGeometry(0.12, 0.135, 0.13, 20), mat("#3c3530"), 0, 0.34, 0));
    head.add(mesh(new THREE.CylinderGeometry(0.137, 0.137, 0.03, 20), mat(c.color), 0, 0.3, 0));
  }
  if (L.hat === "chef") {
    head.add(mesh(new THREE.CylinderGeometry(0.12, 0.13, 0.12, 20), accent, 0, 0.32, 0));
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      head.add(mesh(new THREE.SphereGeometry(0.075, 12, 10), accent, Math.cos(a) * 0.07, 0.42, Math.sin(a) * 0.07));
    }
  }

  // 统一身高（原 character_models.dv 中 height=1.32）
  const box = new THREE.Box3().setFromObject(root);
  const h = box.max.y - box.min.y;
  root.scale.setScalar(L.height / h);
  return { root, body, armL, armR, legL, legR, head };
}

export function animateRig(r: Rig, t: number, pose: "stand" | "walk" | "sit" | "wave") {
  r.body.position.y = 0;
  r.legL.rotation.x = 0; r.legR.rotation.x = 0;
  r.armL.rotation.set(0, 0, 0.08); r.armR.rotation.set(0, 0, -0.08);
  r.head.rotation.set(0, Math.sin(t * 0.5) * 0.15, 0);
  const breathe = 1 + Math.sin(t * 2) * 0.012;
  r.body.scale.set(1, breathe, 1);
  if (pose === "walk") {
    const s = Math.sin(t * 6);
    r.legL.rotation.x = s * 0.5; r.legR.rotation.x = -s * 0.5;
    r.armL.rotation.x = -s * 0.45; r.armR.rotation.x = s * 0.45;
    r.body.position.y = Math.abs(Math.cos(t * 6)) * 0.02;
  } else if (pose === "sit") {
    r.body.position.y = -0.33;
    r.legL.rotation.x = -Math.PI / 2; r.legR.rotation.x = -Math.PI / 2;
    r.armL.rotation.x = -0.6; r.armR.rotation.x = -0.6;
  } else if (pose === "wave") {
    r.armR.rotation.z = -2.6 + Math.sin(t * 8) * 0.3;
  }
}
