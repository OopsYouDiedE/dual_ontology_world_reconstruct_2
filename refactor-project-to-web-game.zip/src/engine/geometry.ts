import type { BuildingData, PropData, Vec2, WallData } from "./types";

export const CELL = 0.25;
const MARGIN = 1;

export interface PropDims {
  w: number; // 沿局部右轴
  d: number; // 沿正面轴
  blocking: boolean;
  circle?: number;
  mounted?: boolean; // 墙挂
  seat?: boolean;
}

export function propDims(p: PropData): PropDims {
  const q = p.params || {};
  switch (p.kind) {
    case "bed": return { w: q.bed_w ?? 1.4, d: q.bed_l ?? 2, blocking: true, seat: true };
    case "cabinet": return { w: q.cab_w ?? 1.2, d: 0.55, blocking: true };
    case "table": return { w: q.table_w ?? 1.4, d: q.table_d ?? 0.8, blocking: true };
    case "chair": return { w: q.seat_w ?? 0.48, d: q.seat_d ?? 0.48, blocking: false, seat: true };
    case "rug": return { w: q.rug_w ?? 2, d: q.rug_d ?? 1.5, blocking: false };
    case "painting": return { w: q.frame_w ?? 1.2, d: 0.06, blocking: false, mounted: true };
    case "wall_lantern": return { w: 0.3, d: 0.18, blocking: false, mounted: true };
    case "wash_table": return { w: 0.9, d: 0.5, blocking: true };
    case "sofa": return { w: q.sofa_w ?? 2, d: q.sofa_d ?? 0.9, blocking: true, seat: true };
    case "round_table": { const r = q.table_r ?? 0.45; return { w: r * 2, d: r * 2, blocking: true, circle: r }; }
    case "bench": return { w: q.bench_len ?? 1.6, d: q.bench_w ?? 0.5, blocking: true, seat: true };
    case "planter": return { w: q.plant_w ?? 0.6, d: q.plant_w ?? 0.6, blocking: true };
    case "upright_piano": return { w: 1.5, d: 0.6, blocking: true };
    case "easel": return { w: 0.7, d: 0.6, blocking: true };
    case "banker_lamp": return { w: 0.3, d: 0.25, blocking: false };
    case "bookshelf": return { w: q.shelf_w ?? 1.4, d: 0.4, blocking: true };
    case "chest": return { w: q.chest_w ?? 0.9, d: q.chest_d ?? 0.55, blocking: true };
    case "nightstand": return { w: q.stand_w ?? 0.5, d: 0.45, blocking: true };
    case "pendant_lamp": return { w: 0.5, d: 0.5, blocking: false, circle: 0.25 };
    default: return { w: 0.6, d: 0.6, blocking: true };
  }
}

/** 正面方向（Godot yaw 约定：yaw 0 朝 +z） */
export function frontVec(yaw: number): Vec2 {
  const r = (yaw * Math.PI) / 180;
  return [Math.sin(r), Math.cos(r)];
}
export function rightVec(yaw: number): Vec2 {
  const r = (yaw * Math.PI) / 180;
  return [Math.cos(r), -Math.sin(r)];
}

export function propCorners(p: PropData, pad = 0): Vec2[] {
  const dm = propDims(p);
  const f = frontVec(p.yaw), r = rightVec(p.yaw);
  const hw = dm.w / 2 + pad, hd = dm.d / 2 + pad;
  const pts: Vec2[] = [];
  for (const [a, b] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
    pts.push([p.x + r[0] * hw * a + f[0] * hd * b, p.z + r[1] * hw * a + f[1] * hd * b]);
  }
  return pts;
}

export function pointInProp(p: PropData, x: number, z: number, pad = 0): boolean {
  const dm = propDims(p);
  if (dm.circle) return Math.hypot(x - p.x, z - p.z) <= dm.circle + pad;
  const f = frontVec(p.yaw), r = rightVec(p.yaw);
  const dx = x - p.x, dz = z - p.z;
  const lr = dx * r[0] + dz * r[1];
  const lf = dx * f[0] + dz * f[1];
  return Math.abs(lr) <= dm.w / 2 + pad && Math.abs(lf) <= dm.d / 2 + pad;
}

export interface Segment {
  wall: WallData;
  index: number;
  a: Vec2;
  b: Vec2;
  len: number;
}

export function wallSegments(w: WallData): Segment[] {
  const out: Segment[] = [];
  for (let i = 0; i < w.points.length - 1; i++) {
    const a = w.points[i], b = w.points[i + 1];
    const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
    if (len > 0.01) out.push({ wall: w, index: i, a, b, len });
  }
  return out;
}

function segLocal(s: Segment, x: number, z: number) {
  const ux = (s.b[0] - s.a[0]) / s.len, uz = (s.b[1] - s.a[1]) / s.len;
  const dx = x - s.a[0], dz = z - s.a[1];
  const t = dx * ux + dz * uz;
  const d = Math.abs(dx * -uz + dz * ux);
  return { t, d };
}

export function isPassable(type: string) {
  return type === "closed_door" || type === "portal_arch" || type === "open_door";
}

export interface Room {
  id: number;
  name: string;
  kind: string;
  cells: number;
  cx: number;
  cz: number;
  area: number;
}

export interface WorldGeo {
  cols: number;
  rows: number;
  ox: number;
  oz: number;
  walk: Uint8Array; // 1 = 可行走
  wallMask: Uint8Array;
  room: Int16Array; // -1 = 室外/墙
  rooms: Room[];
  adj: Set<string>;
  building: BuildingData;
}

export function buildGeo(b: BuildingData): WorldGeo {
  const ox = -MARGIN, oz = -MARGIN;
  const cols = Math.ceil((b.width + MARGIN * 2) / CELL);
  const rows = Math.ceil((b.depth + MARGIN * 2) / CELL);
  const n = cols * rows;
  const walk = new Uint8Array(n).fill(1);
  const wallMask = new Uint8Array(n);
  const roomWall = new Uint8Array(n);
  const segs = b.walls.flatMap(wallSegments);

  for (let j = 0; j < rows; j++) {
    for (let i = 0; i < cols; i++) {
      const x = ox + (i + 0.5) * CELL, z = oz + (j + 0.5) * CELL;
      const k = j * cols + i;
      for (const s of segs) {
        const { t, d } = segLocal(s, x, z);
        const th = s.wall.thickness / 2;
        if (t < -th - 0.05 || t > s.len + th + 0.05) continue;
        if (d < th + 0.14) {
          roomWall[k] = 1;
          let open = false;
          for (const o of s.wall.openings) {
            if (o.segment !== s.index || !isPassable(o.type)) continue;
            if (Math.abs(t - o.center) < o.width / 2 - 0.12) open = true;
          }
          if (!open) { walk[k] = 0; wallMask[k] = 1; }
        }
        if (d < th + 0.02) roomWall[k] = 1;
      }
    }
  }
  // 家具阻挡
  for (const p of b.props) {
    const dm = propDims(p);
    if (!dm.blocking) continue;
    for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
      const x = ox + (i + 0.5) * CELL, z = oz + (j + 0.5) * CELL;
      if (pointInProp(p, x, z, 0.06)) walk[j * cols + i] = 0;
    }
  }
  // 房间：门洞视作隔断，洪泛
  const room = new Int16Array(n).fill(-2);
  const regions: { cells: number[]; outside: boolean }[] = [];
  for (let k = 0; k < n; k++) {
    if (roomWall[k] || room[k] !== -2) continue;
    const id = regions.length;
    const stack = [k];
    room[k] = id;
    const cells: number[] = [];
    let outside = false;
    while (stack.length) {
      const c = stack.pop()!;
      cells.push(c);
      const ci = c % cols, cj = (c / cols) | 0;
      if (ci === 0 || cj === 0 || ci === cols - 1 || cj === rows - 1) outside = true;
      const nb = [ci > 0 ? c - 1 : -1, ci < cols - 1 ? c + 1 : -1, cj > 0 ? c - cols : -1, cj < rows - 1 ? c + cols : -1];
      for (const m of nb) {
        if (m < 0 || roomWall[m] || room[m] !== -2) continue;
        room[m] = id;
        stack.push(m);
      }
    }
    regions.push({ cells, outside });
  }
  const rooms: Room[] = [];
  const remap = new Map<number, number>();
  regions.forEach((r, idx) => {
    if (r.outside || r.cells.length * CELL * CELL < 1.5) return;
    let sx = 0, sz = 0;
    for (const c of r.cells) { sx += ox + ((c % cols) + 0.5) * CELL; sz += oz + (((c / cols) | 0) + 0.5) * CELL; }
    const id = rooms.length;
    remap.set(idx, id);
    rooms.push({ id, name: "", kind: "room", cells: r.cells.length, cx: sx / r.cells.length, cz: sz / r.cells.length, area: r.cells.length * CELL * CELL });
  });
  for (let k = 0; k < n; k++) {
    const v = room[k];
    room[k] = v >= 0 && remap.has(v) ? remap.get(v)! : -1;
  }
  // 墙体/门洞上的格子归入最近的房间（便于定位人物）
  for (let pass = 0; pass < 3; pass++) {
    for (let k = 0; k < n; k++) {
      if (room[k] !== -1 || !walk[k]) continue;
      const ci = k % cols;
      for (const m of [ci > 0 ? k - 1 : -1, ci < cols - 1 ? k + 1 : -1, k - cols, k + cols]) {
        if (m >= 0 && m < n && room[m] >= 0 && roomWall[m] === 0) { room[k] = room[m]; break; }
      }
    }
  }
  const geo: WorldGeo = { cols, rows, ox, oz, walk, wallMask, room, rooms, adj: new Set(), building: b };
  nameRooms(geo);
  // 邻接：门洞两侧
  for (const s of segs) {
    for (const o of s.wall.openings) {
      if (o.segment !== s.index || !isPassable(o.type)) continue;
      const ux = (s.b[0] - s.a[0]) / s.len, uz = (s.b[1] - s.a[1]) / s.len;
      const px = s.a[0] + ux * o.center, pz = s.a[1] + uz * o.center;
      const r1 = roomAtRaw(geo, px - uz * 0.45, pz + ux * 0.45);
      const r2 = roomAtRaw(geo, px + uz * 0.45, pz - ux * 0.45);
      if (r1 >= 0 && r2 >= 0 && r1 !== r2) { geo.adj.add(`${r1}-${r2}`); geo.adj.add(`${r2}-${r1}`); }
    }
  }
  return geo;
}

function roomAtRaw(g: WorldGeo, x: number, z: number) {
  const i = Math.floor((x - g.ox) / CELL), j = Math.floor((z - g.oz) / CELL);
  if (i < 0 || j < 0 || i >= g.cols || j >= g.rows) return -1;
  return g.room[j * g.cols + i];
}

export function roomAt(g: WorldGeo, x: number, z: number): number {
  const r = roomAtRaw(g, x, z);
  if (r >= 0) return r;
  // 就近查找
  for (let rad = 1; rad <= 3; rad++) {
    for (const [dx, dz] of [[rad, 0], [-rad, 0], [0, rad], [0, -rad]]) {
      const v = roomAtRaw(g, x + dx * CELL, z + dz * CELL);
      if (v >= 0) return v;
    }
  }
  return -1;
}

function nameRooms(g: WorldGeo) {
  const counts: Record<string, number> = {};
  for (const r of g.rooms) {
    const inside = g.building.props.filter((p) => roomAtRaw(g, p.x, p.z) === r.id);
    const has = (k: string) => inside.filter((p) => p.kind === k).length;
    let kind = "room", name = "房间";
    if (has("bed")) { kind = "bedroom"; name = "卧室"; }
    else if (has("bookshelf")) { kind = "study"; name = "书房"; }
    else if (has("table") && has("chair") >= 3) { kind = "dining"; name = "餐厅"; }
    else if (has("sofa") || has("upright_piano")) { kind = "living"; name = "客厅"; }
    else if (has("wash_table")) { kind = "bath"; name = "盥洗间"; }
    r.kind = kind;
    r.name = name;
    counts[name] = (counts[name] || 0) + 1;
  }
  const W = g.building.width, D = g.building.depth;
  for (const r of g.rooms) {
    if (counts[r.name] > 1) {
      const ns = r.cz < D / 2 ? "北" : "南";
      const ew = r.cx < W / 3 ? "西" : r.cx > (W * 2) / 3 ? "东" : "";
      r.name = `${r.name}·${ns}${ew}`;
    }
  }
}

export function cellOf(g: WorldGeo, x: number, z: number): number {
  const i = Math.min(g.cols - 1, Math.max(0, Math.floor((x - g.ox) / CELL)));
  const j = Math.min(g.rows - 1, Math.max(0, Math.floor((z - g.oz) / CELL)));
  return j * g.cols + i;
}
export function cellCenter(g: WorldGeo, k: number): Vec2 {
  return [g.ox + ((k % g.cols) + 0.5) * CELL, g.oz + (((k / g.cols) | 0) + 0.5) * CELL];
}

export function insideBuilding(g: WorldGeo, k: number) {
  return g.room[k] >= 0;
}

/** 距离给定点最近的可行走室内格 */
export function nearestWalkable(g: WorldGeo, x: number, z: number, maxR = 3): Vec2 | null {
  const start = cellOf(g, x, z);
  if (g.walk[start] && insideBuilding(g, start)) return cellCenter(g, start);
  let best: number = -1, bd = Infinity;
  const R = Math.ceil(maxR / CELL);
  const si = start % g.cols, sj = (start / g.cols) | 0;
  for (let dj = -R; dj <= R; dj++) for (let di = -R; di <= R; di++) {
    const i = si + di, j = sj + dj;
    if (i < 0 || j < 0 || i >= g.cols || j >= g.rows) continue;
    const k = j * g.cols + i;
    if (!g.walk[k] || !insideBuilding(g, k)) continue;
    const c = cellCenter(g, k);
    const d = Math.hypot(c[0] - x, c[1] - z);
    if (d < bd) { bd = d; best = k; }
  }
  return best >= 0 ? cellCenter(g, best) : null;
}

/** 使用家具前站立的位置 */
export function approachPoint(g: WorldGeo, p: PropData, roomHint?: number): Vec2 | null {
  const dm = propDims(p);
  const f = frontVec(p.yaw), r = rightVec(p.yaw);
  const tries: Vec2[] = [];
  const off = dm.mounted ? 0.55 : dm.d / 2 + 0.32;
  tries.push([p.x + f[0] * off, p.z + f[1] * off]);
  if (dm.seat || p.kind === "bed") {
    tries.push([p.x + r[0] * (dm.w / 2 + 0.32), p.z + r[1] * (dm.w / 2 + 0.32)]);
    tries.push([p.x - r[0] * (dm.w / 2 + 0.32), p.z - r[1] * (dm.w / 2 + 0.32)]);
    tries.push([p.x - f[0] * off, p.z - f[1] * off]);
  }
  const room = roomHint ?? roomAt(g, p.x, p.z);
  for (const t of tries) {
    const k = cellOf(g, t[0], t[1]);
    if (g.walk[k] && insideBuilding(g, k) && (room < 0 || g.room[k] === room)) return cellCenter(g, k);
  }
  return nearestWalkable(g, tries[0][0], tries[0][1], 2.5);
}

function lineClear(g: WorldGeo, a: Vec2, b: Vec2): boolean {
  const d = Math.hypot(b[0] - a[0], b[1] - a[1]);
  const steps = Math.ceil(d / (CELL * 0.4));
  for (let s = 1; s < steps; s++) {
    const t = s / steps;
    const x = a[0] + (b[0] - a[0]) * t, z = a[1] + (b[1] - a[1]) * t;
    // 检查周围避免贴墙切角
    for (const [dx, dz] of [[0, 0], [0.09, 0.09], [-0.09, 0.09], [0.09, -0.09], [-0.09, -0.09]]) {
      if (!g.walk[cellOf(g, x + dx, z + dz)]) return false;
    }
  }
  return true;
}

/** A* 寻路，返回平滑后的路点 */
export function findPath(g: WorldGeo, from: Vec2, to: Vec2): Vec2[] | null {
  let s = cellOf(g, from[0], from[1]);
  const e = cellOf(g, to[0], to[1]);
  if (!g.walk[s]) {
    const nw = nearestWalkable(g, from[0], from[1], 1.5);
    if (!nw) return null;
    s = cellOf(g, nw[0], nw[1]);
  }
  if (!g.walk[e]) return null;
  if (s === e) return [to];
  const n = g.cols * g.rows;
  const gs = new Float32Array(n).fill(Infinity);
  const came = new Int32Array(n).fill(-1);
  const closed = new Uint8Array(n);
  const heap: [number, number][] = [];
  const push = (k: number, f: number) => {
    heap.push([f, k]);
    let i = heap.length - 1;
    while (i > 0) { const p = (i - 1) >> 1; if (heap[p][0] <= heap[i][0]) break; [heap[p], heap[i]] = [heap[i], heap[p]]; i = p; }
  };
  const pop = () => {
    const top = heap[0]; const last = heap.pop()!;
    if (heap.length) { heap[0] = last; let i = 0; for (;;) { const l = i * 2 + 1, r = l + 1; let m = i; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r < heap.length && heap[r][0] < heap[m][0]) m = r; if (m === i) break; [heap[m], heap[i]] = [heap[i], heap[m]]; i = m; } }
    return top;
  };
  const ei = e % g.cols, ej = (e / g.cols) | 0;
  const h = (k: number) => { const dx = Math.abs((k % g.cols) - ei), dy = Math.abs(((k / g.cols) | 0) - ej); return Math.max(dx, dy) + 0.414 * Math.min(dx, dy); };
  gs[s] = 0; push(s, h(s));
  const dirs = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414]];
  let found = false;
  let guard = 0;
  while (heap.length && guard++ < 20000) {
    const [, k] = pop();
    if (closed[k]) continue;
    if (k === e) { found = true; break; }
    closed[k] = 1;
    const ki = k % g.cols, kj = (k / g.cols) | 0;
    for (const [di, dj, c] of dirs) {
      const i = ki + di, j = kj + dj;
      if (i < 0 || j < 0 || i >= g.cols || j >= g.rows) continue;
      const m = j * g.cols + i;
      if (!g.walk[m] || closed[m]) continue;
      if (di && dj && (!g.walk[kj * g.cols + i] || !g.walk[j * g.cols + ki])) continue;
      const ng = gs[k] + c;
      if (ng < gs[m]) { gs[m] = ng; came[m] = k; push(m, ng + h(m)); }
    }
  }
  if (!found) return null;
  const cells: Vec2[] = [];
  for (let k = e; k !== -1; k = came[k]) cells.push(cellCenter(g, k));
  cells.reverse();
  cells[cells.length - 1] = to;
  // 拉直
  const out: Vec2[] = [];
  let anchor: Vec2 = from;
  let i = 0;
  while (i < cells.length) {
    let j = cells.length - 1;
    while (j > i && !lineClear(g, anchor, cells[j])) j--;
    out.push(cells[j]);
    anchor = cells[j];
    i = j + 1;
  }
  return out;
}

export function pathLength(from: Vec2, pts: Vec2[]) {
  let L = 0, a = from;
  for (const p of pts) { L += Math.hypot(p[0] - a[0], p[1] - a[1]); a = p; }
  return L;
}

export function areAdjacent(g: WorldGeo, a: number, b: number) {
  return g.adj.has(`${a}-${b}`);
}
