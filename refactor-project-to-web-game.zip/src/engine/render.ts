import { CELL, propDims, wallSegments, type WorldGeo } from "./geometry";
import type { BuildingData, PropData } from "./types";

export interface View {
  scale: number;
  ox: number;
  oy: number;
}

export type WallMode = "full" | "low" | "hidden";

const ROOM_TINT: Record<string, string> = {
  bedroom: "#c99a6b",
  living: "#b98a5c",
  study: "#a87c55",
  dining: "#c49464",
  bath: "#a9b8bf",
  room: "#bf9466",
};

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return (h >>> 0) / 4294967296;
}

function shade(hex: string, k: number) {
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  if (k >= 0) { r += (255 - r) * k; g += (255 - g) * k; b += (255 - b) * k; }
  else { r *= 1 + k; g *= 1 + k; b *= 1 + k; }
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const k = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + k, y);
  ctx.arcTo(x + w, y, x + w, y + h, k);
  ctx.arcTo(x + w, y + h, x, y + h, k);
  ctx.arcTo(x, y + h, x, y, k);
  ctx.arcTo(x, y, x + w, y, k);
  ctx.closePath();
}

/** 地板：按房间格子绘制拼花木地板 */
export function drawFloor(ctx: CanvasRenderingContext2D, geo: WorldGeo, v: View) {
  const s = v.scale;
  // 室外草地
  ctx.fillStyle = "#3d5a3a";
  ctx.fillRect(v.ox + geo.ox * s, v.oy + geo.oz * s, geo.cols * CELL * s, geo.rows * CELL * s);
  for (let j = 0; j < geo.rows; j++) {
    for (let i = 0; i < geo.cols; i++) {
      const k = j * geo.cols + i;
      const x = geo.ox + i * CELL, z = geo.oz + j * CELL;
      if (geo.room[k] < 0) {
        const n = hash(`g${i},${j}`);
        if (n > 0.85) { ctx.fillStyle = "#466a42"; ctx.fillRect(v.ox + x * s, v.oy + z * s, CELL * s + 0.5, CELL * s + 0.5); }
        continue;
      }
      const room = geo.rooms[geo.room[k]];
      const base = ROOM_TINT[room?.kind ?? "room"];
      // 人字形木板：两格一组
      const plank = ((i >> 1) + (j >> 0)) % 2 === 0;
      const n = hash(`${i},${j}`);
      ctx.fillStyle = shade(base, (n - 0.5) * 0.12 + (plank ? 0.03 : -0.03));
      ctx.fillRect(v.ox + x * s, v.oy + z * s, CELL * s + 0.6, CELL * s + 0.6);
      ctx.strokeStyle = "rgba(60,35,15,0.18)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      if (plank) { ctx.moveTo(v.ox + x * s, v.oy + z * s); ctx.lineTo(v.ox + (x + CELL) * s, v.oy + z * s); }
      else { ctx.moveTo(v.ox + x * s, v.oy + z * s); ctx.lineTo(v.ox + x * s, v.oy + (z + CELL) * s); }
      ctx.stroke();
    }
  }
}

export function drawRoomLabels(ctx: CanvasRenderingContext2D, geo: WorldGeo, v: View) {
  ctx.save();
  ctx.font = `${Math.max(10, v.scale * 0.24)}px "Noto Serif SC", serif`;
  ctx.textAlign = "center";
  ctx.fillStyle = "rgba(40,22,10,0.35)";
  for (const r of geo.rooms) ctx.fillText(r.name, v.ox + r.cx * v.scale, v.oy + r.cz * v.scale);
  ctx.restore();
}

const PALETTE = ["#8a3b3b", "#2f5d7c", "#6d7f3c", "#a67c2e", "#5a3f73", "#2e6f68", "#9a5a2a", "#3c3c5c"];

export function drawProp(ctx: CanvasRenderingContext2D, p: PropData, v: View, opts: { selected?: boolean; ghost?: boolean; lit?: boolean; stock?: number; occupied?: boolean } = {}) {
  const dm = propDims(p);
  const s = v.scale;
  ctx.save();
  ctx.translate(v.ox + p.x * s, v.oy + p.z * s);
  ctx.rotate((-p.yaw * Math.PI) / 180);
  ctx.scale(s, s);
  if (opts.ghost) ctx.globalAlpha = 0.55;
  const w = dm.w, d = dm.d, hw = w / 2, hd = d / 2;
  const seed = hash(p.id);
  ctx.lineWidth = 0.025;
  ctx.lineJoin = "round";
  const shadow = () => { ctx.fillStyle = "rgba(0,0,0,0.22)"; rr(ctx, -hw + 0.05, -hd + 0.06, w, d, 0.05); ctx.fill(); };
  switch (p.kind) {
    case "rug": {
      const c = PALETTE[Math.floor(seed * PALETTE.length)];
      ctx.fillStyle = c; rr(ctx, -hw, -hd, w, d, 0.04); ctx.fill();
      ctx.strokeStyle = shade(c, 0.45); ctx.lineWidth = 0.05; rr(ctx, -hw + 0.1, -hd + 0.1, w - 0.2, d - 0.2, 0.03); ctx.stroke();
      ctx.lineWidth = 0.02; ctx.strokeStyle = shade(c, 0.25);
      ctx.beginPath(); ctx.moveTo(0, -hd + 0.25); ctx.lineTo(hw - 0.3, 0); ctx.lineTo(0, hd - 0.25); ctx.lineTo(-hw + 0.3, 0); ctx.closePath(); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0, Math.min(w, d) * 0.12, 0, Math.PI * 2); ctx.fillStyle = shade(c, 0.35); ctx.fill();
      break;
    }
    case "bed": {
      shadow();
      ctx.fillStyle = "#6b4528"; rr(ctx, -hw, -hd, w, d, 0.06); ctx.fill();
      ctx.fillStyle = "#f3eee4"; rr(ctx, -hw + 0.06, -hd + 0.12, w - 0.12, d - 0.18, 0.05); ctx.fill();
      ctx.fillStyle = "#4a2e1a"; ctx.fillRect(-hw, -hd, w, 0.12);
      const pillows = w > 1.4 ? 2 : 1;
      for (let i = 0; i < pillows; i++) {
        const pw = (w - 0.3) / pillows - 0.06;
        ctx.fillStyle = "#ffffff"; rr(ctx, -hw + 0.15 + i * (pw + 0.06), -hd + 0.2, pw, 0.34, 0.08); ctx.fill();
        ctx.strokeStyle = "#d9d2c4"; ctx.stroke();
      }
      const bc = ["#3f6e8c", "#8c3f52", "#5f7d47", "#7a5c99"][Math.floor(seed * 4)];
      ctx.fillStyle = bc; rr(ctx, -hw + 0.06, -hd + d * 0.38, w - 0.12, d * 0.58, 0.05); ctx.fill();
      ctx.fillStyle = shade(bc, 0.3); ctx.fillRect(-hw + 0.06, -hd + d * 0.38, w - 0.12, 0.12);
      break;
    }
    case "cabinet": case "nightstand": case "chest": {
      shadow();
      const c = p.kind === "chest" ? "#7a4f2a" : "#8b5e3c";
      ctx.fillStyle = c; rr(ctx, -hw, -hd, w, d, 0.03); ctx.fill();
      ctx.strokeStyle = shade(c, -0.35); ctx.stroke();
      if (p.kind === "cabinet") {
        ctx.beginPath(); ctx.moveTo(0, -hd); ctx.lineTo(0, hd); ctx.stroke();
        ctx.fillStyle = "#e0c070"; ctx.fillRect(-0.08, hd - 0.1, 0.05, 0.06); ctx.fillRect(0.03, hd - 0.1, 0.05, 0.06);
      } else if (p.kind === "chest") {
        ctx.fillStyle = "#3d3d3d"; ctx.fillRect(-hw + 0.12, -hd, 0.06, d); ctx.fillRect(hw - 0.18, -hd, 0.06, d);
        ctx.fillStyle = "#d8b45a"; ctx.fillRect(-0.05, hd - 0.08, 0.1, 0.08);
      } else {
        ctx.beginPath(); ctx.arc(0, 0, 0.12, 0, Math.PI * 2); ctx.fillStyle = "#f2e2b0"; ctx.fill();
      }
      break;
    }
    case "table": {
      shadow();
      ctx.fillStyle = "#9a6a40"; rr(ctx, -hw, -hd, w, d, 0.05); ctx.fill();
      ctx.strokeStyle = "#5e3b1e"; ctx.stroke();
      ctx.strokeStyle = "rgba(70,40,15,0.35)"; ctx.lineWidth = 0.012;
      for (let i = 1; i < 5; i++) { ctx.beginPath(); ctx.moveTo(-hw + 0.05, -hd + (d * i) / 5); ctx.bezierCurveTo(-hw / 3, -hd + (d * i) / 5 + 0.03, hw / 3, -hd + (d * i) / 5 - 0.03, hw - 0.05, -hd + (d * i) / 5); ctx.stroke(); }
      break;
    }
    case "round_table": {
      ctx.fillStyle = "rgba(0,0,0,0.22)"; ctx.beginPath(); ctx.arc(0.05, 0.06, dm.circle!, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#9a6a40"; ctx.beginPath(); ctx.arc(0, 0, dm.circle!, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "#5e3b1e"; ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0, dm.circle! * 0.65, 0, Math.PI * 2); ctx.strokeStyle = "rgba(70,40,15,0.3)"; ctx.stroke();
      ctx.fillStyle = "#f0ece0"; ctx.beginPath(); ctx.arc(0.1, -0.05, 0.08, 0, Math.PI * 2); ctx.fill();
      break;
    }
    case "chair": {
      ctx.fillStyle = "rgba(0,0,0,0.2)"; ctx.fillRect(-hw + 0.04, -hd + 0.05, w, d);
      ctx.fillStyle = "#7d5232"; rr(ctx, -hw, -hd, w, d, 0.05); ctx.fill();
      ctx.fillStyle = "#a33f3f"; rr(ctx, -hw + 0.05, -hd + 0.1, w - 0.1, d - 0.15, 0.04); ctx.fill();
      ctx.fillStyle = "#5a3820"; ctx.fillRect(-hw, -hd, w, 0.08);
      break;
    }
    case "sofa": {
      shadow();
      const c = "#4f6d7a";
      ctx.fillStyle = shade(c, -0.25); rr(ctx, -hw, -hd, w, d, 0.1); ctx.fill();
      ctx.fillStyle = c; rr(ctx, -hw + 0.15, -hd + 0.22, w - 0.3, d - 0.28, 0.06); ctx.fill();
      ctx.strokeStyle = shade(c, -0.4); ctx.beginPath(); ctx.moveTo(0, -hd + 0.24); ctx.lineTo(0, hd - 0.08); ctx.stroke();
      ctx.fillStyle = "#e3c27a"; rr(ctx, -hw + 0.2, -hd + 0.25, 0.25, 0.22, 0.06); ctx.fill();
      break;
    }
    case "bench": {
      shadow();
      ctx.fillStyle = "#8a5d36"; rr(ctx, -hw, -hd, w, d, 0.04); ctx.fill();
      ctx.strokeStyle = "#5a3820";
      for (let i = 1; i < 4; i++) { ctx.beginPath(); ctx.moveTo(-hw, -hd + (d * i) / 4); ctx.lineTo(hw, -hd + (d * i) / 4); ctx.stroke(); }
      break;
    }
    case "planter": {
      ctx.fillStyle = "rgba(0,0,0,0.2)"; ctx.beginPath(); ctx.arc(0.04, 0.05, hw, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#a0522d"; ctx.beginPath(); ctx.arc(0, 0, hw * 0.75, 0, Math.PI * 2); ctx.fill();
      for (let i = 0; i < 9; i++) {
        const a = (i / 9) * Math.PI * 2 + seed * 3;
        ctx.fillStyle = i % 2 ? "#3f7d3a" : "#5a9b46";
        ctx.beginPath(); ctx.ellipse(Math.cos(a) * hw * 0.45, Math.sin(a) * hw * 0.45, hw * 0.42, hw * 0.2, a, 0, Math.PI * 2); ctx.fill();
      }
      const fc = p.params?.flower_count ?? 5;
      for (let i = 0; i < fc; i++) {
        const a = (i / fc) * Math.PI * 2 + seed * 7;
        ctx.fillStyle = ["#f4d35e", "#ee6c8a", "#f7f7f7"][i % 3];
        ctx.beginPath(); ctx.arc(Math.cos(a) * hw * 0.5, Math.sin(a) * hw * 0.5, 0.045, 0, Math.PI * 2); ctx.fill();
      }
      break;
    }
    case "upright_piano": {
      shadow();
      ctx.fillStyle = "#1c1a1f"; rr(ctx, -hw, -hd, w, d, 0.04); ctx.fill();
      ctx.fillStyle = "#f5f2ea"; ctx.fillRect(-hw + 0.08, hd - 0.18, w - 0.16, 0.16);
      ctx.fillStyle = "#111";
      const keys = 26;
      for (let i = 0; i < keys; i++) if (i % 7 !== 2 && i % 7 !== 6) ctx.fillRect(-hw + 0.08 + ((w - 0.16) * (i + 0.65)) / keys, hd - 0.18, (w - 0.16) / keys / 2, 0.09);
      ctx.fillStyle = "#d6b25e"; ctx.fillRect(-0.15, -hd + 0.1, 0.3, 0.03);
      break;
    }
    case "easel": {
      ctx.strokeStyle = "#7b5434"; ctx.lineWidth = 0.05;
      ctx.beginPath(); ctx.moveTo(-hw * 0.8, hd); ctx.lineTo(0, -hd); ctx.lineTo(hw * 0.8, hd); ctx.moveTo(0, -hd); ctx.lineTo(0, hd * 0.9); ctx.stroke();
      ctx.fillStyle = "#f8f4ea"; ctx.fillRect(-hw * 0.7, -0.05, w * 0.7, 0.08);
      ctx.fillStyle = "#4f86b8"; ctx.fillRect(-hw * 0.5, -0.04, w * 0.25, 0.06);
      ctx.fillStyle = "#e0a84f"; ctx.fillRect(0, -0.04, w * 0.15, 0.06);
      break;
    }
    case "bookshelf": {
      shadow();
      ctx.fillStyle = "#5b3a22"; ctx.fillRect(-hw, -hd, w, d);
      let x = -hw + 0.04;
      let i = 0;
      while (x < hw - 0.06) {
        const bw = 0.04 + hash(p.id + i) * 0.05;
        ctx.fillStyle = PALETTE[Math.floor(hash(p.id + "c" + i) * PALETTE.length)];
        ctx.fillRect(x, -hd + 0.05, Math.min(bw, hw - 0.04 - x), d - 0.1);
        x += bw + 0.008; i++;
      }
      break;
    }
    case "wash_table": {
      shadow();
      ctx.fillStyle = "#e9e4da"; rr(ctx, -hw, -hd, w, d, 0.06); ctx.fill();
      ctx.strokeStyle = "#a9a294"; ctx.stroke();
      ctx.fillStyle = "#bfe0ea"; ctx.beginPath(); ctx.ellipse(0, 0.03, hw * 0.55, hd * 0.55, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "#8aaab4"; ctx.stroke();
      ctx.fillStyle = "#b9b9b9"; ctx.fillRect(-0.03, -hd + 0.02, 0.06, 0.12);
      break;
    }
    case "painting": {
      ctx.fillStyle = "#c79a3b"; ctx.fillRect(-hw, -0.06, w, 0.12);
      const g = ctx.createLinearGradient(-hw, 0, hw, 0);
      g.addColorStop(0, ["#2f5d7c", "#7a3b5c", "#3f6b3a"][Math.floor(seed * 3)]); g.addColorStop(1, "#e3c27a");
      ctx.fillStyle = g; ctx.fillRect(-hw + 0.06, -0.03, w - 0.12, 0.06);
      break;
    }
    case "wall_lantern": {
      ctx.fillStyle = "#3a3a3a"; ctx.fillRect(-0.1, -hd, 0.2, 0.08);
      ctx.beginPath(); ctx.arc(0, 0.02, 0.1, 0, Math.PI * 2);
      ctx.fillStyle = opts.lit ? "#ffe9a8" : "#8a8270"; ctx.fill();
      ctx.strokeStyle = "#2a2a2a"; ctx.stroke();
      break;
    }
    case "banker_lamp": {
      ctx.fillStyle = "#1f6b45"; rr(ctx, -hw, -hd, w, d, 0.06); ctx.fill();
      ctx.fillStyle = "#d8b45a"; ctx.fillRect(-0.02, -hd, 0.04, d);
      break;
    }
    case "pendant_lamp": {
      ctx.strokeStyle = "rgba(60,40,20,0.5)"; ctx.lineWidth = 0.02;
      ctx.beginPath(); ctx.arc(0, 0, 0.22, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = opts.lit ? "rgba(255,230,160,0.9)" : "rgba(200,180,140,0.6)";
      ctx.beginPath(); ctx.arc(0, 0, 0.1, 0, Math.PI * 2); ctx.fill();
      break;
    }
    default: {
      ctx.fillStyle = "#888"; ctx.fillRect(-hw, -hd, w, d);
    }
  }
  if (opts.selected) {
    ctx.strokeStyle = "#ffd54a"; ctx.lineWidth = 0.05; ctx.setLineDash([0.12, 0.08]);
    if (dm.circle) { ctx.beginPath(); ctx.arc(0, 0, dm.circle + 0.06, 0, Math.PI * 2); ctx.stroke(); }
    else ctx.strokeRect(-hw - 0.06, -hd - 0.06, w + 0.12, d + 0.12);
    ctx.setLineDash([]);
    // 正面箭头
    ctx.fillStyle = "#ffd54a";
    ctx.beginPath(); ctx.moveTo(-0.1, hd + 0.1); ctx.lineTo(0.1, hd + 0.1); ctx.lineTo(0, hd + 0.25); ctx.fill();
  }
  ctx.restore();
  if (opts.stock !== undefined) drawStockBadge(ctx, p, v, opts.stock);
}

export function drawStockBadge(ctx: CanvasRenderingContext2D, p: PropData, v: View, stock: number) {
  const s = v.scale;
  const opts = { stock };
  {
    const x = v.ox + p.x * s, y = v.oy + p.z * s;
    ctx.save();
    ctx.font = `bold ${Math.max(9, s * 0.2)}px sans-serif`;
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillStyle = opts.stock > 0 ? "rgba(30,90,40,0.9)" : "rgba(140,30,30,0.9)";
    rr(ctx, x - s * 0.22, y - s * 0.13, s * 0.44, s * 0.26, s * 0.06); ctx.fill();
    ctx.fillStyle = "#fff"; ctx.fillText(`🍞${opts.stock}`, x, y + 1);
    ctx.restore();
  }
}

const RUG_FIRST = (a: PropData, b: PropData) => {
  const o = (p: PropData) => (p.kind === "rug" ? 0 : p.kind === "chair" ? 2 : p.kind === "pendant_lamp" || p.kind === "banker_lamp" ? 4 : propDims(p).mounted ? 5 : 1);
  return o(a) - o(b);
};

export function sortedProps(b: BuildingData) {
  return [...b.props].sort(RUG_FIRST);
}

export function drawWalls(ctx: CanvasRenderingContext2D, b: BuildingData, v: View, mode: WallMode, selectedWall?: string | null) {
  const s = v.scale;
  for (const w of b.walls) {
    for (const seg of wallSegments(w)) {
      const ux = (seg.b[0] - seg.a[0]) / seg.len, uz = (seg.b[1] - seg.a[1]) / seg.len;
      const nx = -uz, nz = ux;
      const th = mode === "full" ? w.thickness : mode === "low" ? w.thickness * 0.75 : 0.06;
      const ops = w.openings.filter((o) => o.segment === seg.index).sort((a, c) => a.center - c.center);
      const pieces: [number, number][] = [];
      let cur = -w.thickness / 2;
      for (const o of ops) {
        const a = o.center - o.width / 2, c = o.center + o.width / 2;
        if (a > cur) pieces.push([cur, a]);
        cur = Math.max(cur, c);
      }
      if (cur < seg.len + w.thickness / 2) pieces.push([cur, seg.len + w.thickness / 2]);
      const col = selectedWall === w.id ? "#e0a020" : mode === "full" ? "#2b2420" : mode === "low" ? "#6a5d52" : "rgba(40,30,25,0.5)";
      const quad = (t0: number, t1: number, half: number, fill: string) => {
        ctx.fillStyle = fill;
        ctx.beginPath();
        const P = (t: number, n: number): [number, number] => [v.ox + (seg.a[0] + ux * t + nx * n) * s, v.oy + (seg.a[1] + uz * t + nz * n) * s];
        const p1 = P(t0, -half), p2 = P(t1, -half), p3 = P(t1, half), p4 = P(t0, half);
        ctx.moveTo(...p1); ctx.lineTo(...p2); ctx.lineTo(...p3); ctx.lineTo(...p4); ctx.closePath(); ctx.fill();
      };
      for (const [t0, t1] of pieces) {
        quad(t0, t1, th / 2, col);
        if (mode === "full") quad(t0, t1, th / 2 - 0.05, "#4a3f37");
      }
      for (const o of ops) {
        const a = o.center - o.width / 2, c = o.center + o.width / 2;
        if (o.type === "rectangular_window") {
          quad(a, c, th / 2, "#c9e6f2");
          quad(a, c, 0.02, "#7fb3c9");
        } else if (o.type === "closed_door" || o.type === "open_door") {
          // 门槛与门扇
          quad(a, c, 0.04, "rgba(90,60,30,0.6)");
          const hx = v.ox + (seg.a[0] + ux * a) * s, hz = v.oy + (seg.a[1] + uz * a) * s;
          const ang = Math.atan2(uz, ux);
          ctx.strokeStyle = "rgba(60,40,20,0.75)"; ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.moveTo(hx, hz); ctx.lineTo(hx + Math.cos(ang + Math.PI / 2) * o.width * s * 0.9, hz + Math.sin(ang + Math.PI / 2) * o.width * s * 0.9); ctx.stroke();
          ctx.setLineDash([3, 3]); ctx.lineWidth = 1;
          ctx.beginPath(); ctx.arc(hx, hz, o.width * s * 0.9, ang, ang + Math.PI / 2); ctx.stroke(); ctx.setLineDash([]);
        } else {
          quad(a, c, 0.03, "rgba(120,90,60,0.35)");
        }
      }
    }
  }
}

/** 昼夜光照：返回暗度 0..1 */
export function darkness(hour: number) {
  if (hour >= 7 && hour < 17.5) return 0;
  if (hour >= 17.5 && hour < 20) return ((hour - 17.5) / 2.5) * 0.62;
  if (hour >= 20 || hour < 5) return 0.62;
  return 0.62 * (1 - (hour - 5) / 2);
}

let lightCanvas: HTMLCanvasElement | null = null;
export function drawLighting(ctx: CanvasRenderingContext2D, w: number, h: number, dark: number, lights: { x: number; z: number; r: number; k: number }[], v: View) {
  if (dark <= 0.01) return;
  if (!lightCanvas) lightCanvas = document.createElement("canvas");
  if (lightCanvas.width !== w || lightCanvas.height !== h) { lightCanvas.width = w; lightCanvas.height = h; }
  const l = lightCanvas.getContext("2d")!;
  l.globalCompositeOperation = "source-over";
  l.clearRect(0, 0, w, h);
  l.fillStyle = `rgba(8,12,38,${dark})`;
  l.fillRect(0, 0, w, h);
  l.globalCompositeOperation = "destination-out";
  for (const L of lights) {
    const x = v.ox + L.x * v.scale, y = v.oy + L.z * v.scale, r = L.r * v.scale;
    const g = l.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, `rgba(0,0,0,${L.k})`);
    g.addColorStop(0.6, `rgba(0,0,0,${L.k * 0.6})`);
    g.addColorStop(1, "rgba(0,0,0,0)");
    l.fillStyle = g;
    l.beginPath(); l.arc(x, y, r, 0, Math.PI * 2); l.fill();
  }
  ctx.drawImage(lightCanvas, 0, 0);
  // 暖色
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (const L of lights) {
    const x = v.ox + L.x * v.scale, y = v.oy + L.z * v.scale, r = L.r * v.scale * 0.7;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, `rgba(255,170,60,${0.18 * dark * L.k})`);
    g.addColorStop(1, "rgba(255,170,60,0)");
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();
}

export interface AgentDraw {
  id: string;
  name: string;
  color: string;
  x: number;
  z: number;
  facing: number;
  pose: string;
  walking: boolean;
  icon?: string;
  selected?: boolean;
  bubble?: { text: string; kind: string } | null;
  food?: boolean;
  book?: boolean;
  t: number;
}

export function drawAgent(ctx: CanvasRenderingContext2D, a: AgentDraw, v: View) {
  const s = v.scale;
  const x = v.ox + a.x * s, y = v.oy + a.z * s;
  const bob = a.walking ? Math.sin(a.t * 0.9 + a.x * 3) * s * 0.02 : 0;
  ctx.save();
  ctx.translate(x, y + bob);
  if (a.selected) {
    ctx.strokeStyle = "#ffd54a"; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(0, 0, s * 0.36, 0, Math.PI * 2); ctx.stroke();
  }
  ctx.fillStyle = "rgba(0,0,0,0.3)";
  ctx.beginPath(); ctx.ellipse(s * 0.04, s * 0.05, s * 0.24, s * 0.2, 0, 0, Math.PI * 2); ctx.fill();
  ctx.rotate(-a.facing);
  if (a.pose === "lie") {
    ctx.fillStyle = a.color;
    rr(ctx, -s * 0.2, -s * 0.55, s * 0.4, s * 0.9, s * 0.18); ctx.fill();
    ctx.fillStyle = "#f0d0b0"; ctx.beginPath(); ctx.arc(0, -s * 0.55, s * 0.14, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "rgba(0,0,0,0.4)"; ctx.lineWidth = 1; ctx.stroke();
  } else {
    const r = a.pose === "sit" ? s * 0.19 : s * 0.21;
    // 肩
    ctx.fillStyle = shade(a.color, -0.2);
    rr(ctx, -r * 1.25, -r * 0.55, r * 2.5, r * 1.1, r * 0.5); ctx.fill();
    ctx.fillStyle = a.color;
    ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "rgba(0,0,0,0.45)"; ctx.lineWidth = 1.2; ctx.stroke();
    // 头与朝向（+y 为正面）
    ctx.fillStyle = "#f0d0b0";
    ctx.beginPath(); ctx.arc(0, r * 0.25, r * 0.55, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "rgba(30,20,10,0.8)";
    ctx.beginPath(); ctx.arc(0, r * 0.05, r * 0.5, Math.PI, Math.PI * 2); ctx.fill();
    if (a.pose === "work") {
      ctx.fillStyle = "#f0d0b0";
      ctx.beginPath(); ctx.arc(-r * 0.7, r * 0.95, r * 0.22, 0, Math.PI * 2); ctx.arc(r * 0.7, r * 0.95, r * 0.22, 0, Math.PI * 2); ctx.fill();
    }
  }
  ctx.restore();
  // 名牌
  ctx.save();
  ctx.font = `bold ${Math.max(10, s * 0.2)}px "Noto Sans SC", sans-serif`;
  ctx.textAlign = "center";
  const label = `${a.name}${a.icon ? " " + a.icon : ""}${a.food ? " 🍞" : ""}${a.book ? " 📖" : ""}`;
  const tw = ctx.measureText(label).width;
  ctx.fillStyle = "rgba(20,16,12,0.72)";
  rr(ctx, x - tw / 2 - 5, y - s * 0.62, tw + 10, s * 0.26, 5); ctx.fill();
  ctx.fillStyle = a.color;
  ctx.fillText(label, x, y - s * 0.43);
  ctx.restore();
}

export function drawBubble(ctx: CanvasRenderingContext2D, a: AgentDraw, v: View) {
  if (!a.bubble) return;
  const s = v.scale;
  const x = v.ox + a.x * s, y = v.oy + a.z * s - s * 0.75;
  ctx.save();
  ctx.font = `${Math.max(11, s * 0.21)}px "Noto Sans SC", sans-serif`;
  const text = a.bubble.text.length > 22 ? a.bubble.text.slice(0, 21) + "…" : a.bubble.text;
  const tw = ctx.measureText(text).width;
  const bw = tw + 16, bh = s * 0.36;
  const kind = a.bubble.kind;
  const bg = kind === "confront" ? "#ffd9d6" : kind === "ignore" ? "#e6e6e6" : kind === "decline" ? "#fbe7d0" : kind === "think" ? "#e8eaff" : kind === "defer" ? "#fff3c4" : "#fffdf6";
  ctx.fillStyle = "rgba(0,0,0,0.25)";
  rr(ctx, x - bw / 2 + 2, y - bh + 2, bw, bh, 8); ctx.fill();
  ctx.fillStyle = bg;
  rr(ctx, x - bw / 2, y - bh, bw, bh, 8); ctx.fill();
  ctx.beginPath(); ctx.moveTo(x - 5, y - 1); ctx.lineTo(x + 5, y - 1); ctx.lineTo(x, y + 6); ctx.fill();
  ctx.strokeStyle = "rgba(60,40,20,0.35)"; ctx.lineWidth = 1;
  rr(ctx, x - bw / 2, y - bh, bw, bh, 8); ctx.stroke();
  ctx.fillStyle = "#2b2016";
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  if (kind === "think") ctx.font = `italic ${Math.max(11, s * 0.21)}px "Noto Sans SC", sans-serif`;
  ctx.fillText(text, x, y - bh / 2);
  ctx.restore();
}

export function fitView(b: BuildingData, w: number, h: number, pad = 30): View {
  const scale = Math.min((w - pad * 2) / b.width, (h - pad * 2) / b.depth);
  return { scale, ox: (w - b.width * scale) / 2, oy: (h - b.depth * scale) / 2 };
}
