/* eslint-disable @typescript-eslint/no-explicit-any */
import { LIFE_RULES } from "../data/rules";
import { CHARACTERS, CHAR_BY_ID, NEED_LABELS } from "../data/characters";
import {
  approachPoint, areAdjacent, buildGeo, findPath, nearestWalkable, pathLength, propDims, rightVec, roomAt,
  type WorldGeo,
} from "./geometry";
import type { BuildingData, Candidate, Commitment, Goal, LogEntry, PropData, Relation, Vec2 } from "./types";

const R = LIFE_RULES;
const BODY = ["hunger", "thirst", "energy", "hygiene"];
const ALL_NEEDS = Object.keys(R.needs);

export const START_MIN = R.time.start_minute as number;
export const END_MIN = R.run_end ?? 7200;

function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface ActionState {
  key: string;
  label: string;
  propId?: string;
  targetId?: string;
  remaining: number;
  total: number;
  pose: string;
  forced?: boolean;
  commitmentId?: string;
}

export interface Plan {
  type: "action" | "social" | "investigate" | "fulfil";
  cand: Candidate;
  dest: Vec2;
  commitmentId?: string;
  startedAt: number;
}

export interface Agent {
  id: string;
  name: string;
  color: string;
  x: number;
  z: number;
  facing: number;
  needs: Record<string, number>;
  stress: number;
  mood: number;
  food: number;
  book: boolean;
  action: ActionState | null;
  plan: Plan | null;
  path: Vec2[];
  waitSince: number;
  recent: string[];
  cooldowns: Record<string, number>;
  talkCd: Record<string, number>;
  rel: Record<string, Relation>;
  irritation: number;
  quietUntil: number;
  beliefs: {
    stock: Record<string, { v: number; t: number }>;
    seen: Record<string, { food: boolean; room: number; t: number; playing: boolean }>;
    inferences: string[];
  };
  lexicon: Record<string, string>;
  weights: Record<string, number>;
  candidates: Candidate[];
  lastReason: string;
  bubble: { text: string; until: number; kind: string } | null;
  forced: Candidate | null;
  room: number;
  idleUntil: number;
}

export interface SimStats {
  meals: number;
  requests: number;
  modes: Record<string, number>;
  fulfilled: number;
  broken: number;
  ontology: number;
  authorActs: number;
  minMood: Record<string, number>;
  hungryCritical: number;
}

const LINES_EXTRA: Record<string, string[]> = {
  apologize: ["{t},之前的事，是我不对。", "{t},我想跟你道个歉。"],
  share_food: ["{t},这份口粮你拿着吧。", "{t},我这儿还有吃的，分你一份?"],
  ask_help: ["{t},能帮我理一理思路吗?", "{t},有件事想听听你的看法。"],
};

export class LifeSim {
  building: BuildingData;
  geo: WorldGeo;
  props: Record<string, PropData> = {};
  propRoom: Record<string, number> = {};
  t = START_MIN;
  agents: Agent[] = [];
  stock: Record<string, number> = {};
  lamps: Record<string, boolean> = {};
  occ: Record<string, string[]> = {};
  commitments: Commitment[] = [];
  log: LogEntry[] = [];
  stats: SimStats;
  rngState: number;
  rng: () => number;
  lastSupplyDay = 0;
  goals: Goal[] = [];
  ended = false;
  seq = 0;
  bedOwner: Record<string, string> = {};

  constructor(building: BuildingData, seed: number = R.response.initial_seed ?? 7) {
    this.building = building;
    this.geo = buildGeo(building);
    this.rngState = seed;
    this.rng = mulberry(seed * 9973 + 17);
    this.stats = { meals: 0, requests: 0, modes: {}, fulfilled: 0, broken: 0, ontology: 0, authorActs: 0, minMood: {}, hungryCritical: 0 };
    this.indexProps();
    this.initAgents();
    this.addLog("system", `五人生活推演开始：${building.name}。观察窗：第一日 07:00 至第五日结束。`);
    this.goals = makeGoals();
  }

  // ---------- 初始化 ----------
  indexProps() {
    this.props = {};
    this.propRoom = {};
    for (const p of this.building.props) {
      this.props[p.id] = p;
      this.propRoom[p.id] = roomAt(this.geo, p.x, p.z);
      if (this.occ[p.id] === undefined) this.occ[p.id] = [];
      if (p.kind === "cabinet" && this.isPantry(p) && this.stock[p.id] === undefined) this.stock[p.id] = R.inventory.initial_per_pantry;
      if (p.kind === "wall_lantern" && this.lamps[p.id] === undefined) this.lamps[p.id] = false;
    }
    // 床位归属：优先使用设计文件中的 owner，否则使用默认
    this.bedOwner = {};
    for (const p of this.building.props) if (p.kind === "bed" && p.owner) this.bedOwner[p.id] = p.owner;
    for (const c of CHARACTERS) {
      if (Object.values(this.bedOwner).includes(c.id)) continue;
      if (c.bed && this.props[c.bed] && !this.bedOwner[c.bed]) this.bedOwner[c.bed] = c.id;
    }
  }

  isPantry(p: PropData) {
    const r = this.geo.rooms[roomAt(this.geo, p.x, p.z)];
    if (!r) return false;
    if (r.kind === "bedroom") {
      // 没有其他储物柜时卧室柜也当储藏
      return !this.building.props.some((q) => q.kind === "cabinet" && this.geo.rooms[roomAt(this.geo, q.x, q.z)]?.kind !== "bedroom");
    }
    return true;
  }

  initAgents() {
    const rooms = this.geo.rooms;
    const startRoom = rooms.find((r) => r.kind === "living") ?? rooms[0];
    const ruleAgents: any[] = R.agents;
    CHARACTERS.forEach((c, i) => {
      const ra = ruleAgents.find((a) => a.id === c.id) ?? {};
      let pos: Vec2 | null = null;
      const bed = Object.entries(this.bedOwner).find(([, o]) => o === c.id)?.[0];
      if (bed) pos = approachPoint(this.geo, this.props[bed]);
      if (!pos && startRoom) pos = nearestWalkable(this.geo, startRoom.cx + (i - 2) * 0.6, startRoom.cz, 4);
      if (!pos) pos = nearestWalkable(this.geo, this.building.width / 2, this.building.depth / 2, 10) ?? [1, 1];
      const needs: Record<string, number> = {};
      for (const n of ALL_NEEDS) needs[n] = R.initial_needs[n] ?? 60 + this.rng() * 10;
      for (const n of Object.keys(needs)) needs[n] = Math.min(100, Math.max(0, needs[n] + (this.rng() - 0.5) * 10));
      const rel: Record<string, Relation> = {};
      for (const o of CHARACTERS) if (o.id !== c.id) rel[o.id] = { ...R.relationship.initial, stage: "熟识" };
      const weights: Record<string, number> = { ...(ra.weights ?? {}) };
      this.agents.push({
        id: c.id, name: c.name, color: c.color, x: pos[0], z: pos[1], facing: 0,
        needs, stress: 0, mood: 70, food: R.inventory.initial_carried, book: false,
        action: null, plan: null, path: [], waitSince: 0, recent: [], cooldowns: {}, talkCd: {}, rel,
        irritation: 0, quietUntil: 0,
        beliefs: { stock: {}, seen: {}, inferences: [] },
        lexicon: { ...(R.lexicon.agents[c.id] ?? {}) },
        weights, candidates: [], lastReason: "", bubble: null, forced: null,
        room: roomAt(this.geo, pos[0], pos[1]), idleUntil: 0,
      });
      this.stats.minMood[c.id] = 100;
    });
    for (const a of this.agents) for (const o of this.agents) if (o !== a) this.updateStage(a, o.id);
  }

  // ---------- 工具 ----------
  get day() { return Math.floor(this.t / 1440) + 1; }
  get hour() { return (this.t % 1440) / 60; }
  isNight(h = this.hour) { return h >= R.time.night_from || h < R.time.night_to; }
  isDusk(h = this.hour) { return h >= R.time.dusk && h < R.time.night_from; }
  isDay(h = this.hour) { return h >= R.time.day_from && h < R.time.dusk; }

  agent(id: string) { return this.agents.find((a) => a.id === id)!; }

  addLog(kind: LogEntry["kind"], text: string, who?: string[]) {
    this.log.push({ t: this.t, kind, text, who });
    if (this.log.length > 1500) this.log.splice(0, this.log.length - 1500);
  }

  say(a: Agent, text: string, kind = "say", dur = 6) {
    a.bubble = { text, until: this.t + dur, kind };
  }

  urgency(a: Agent, n: string) {
    const v = a.needs[n] ?? 100;
    if (v >= R.brain.satisfied_below) return 0;
    return Math.pow((100 - v) / 100, R.brain.urgency_power);
  }

  roomLit(room: number) {
    const lanterns = this.building.props.filter((p) => p.kind === "wall_lantern" && this.propRoom[p.id] === room);
    if (!lanterns.length) return true;
    return lanterns.some((p) => this.lamps[p.id]);
  }
  naturalLight() { return this.isDay(); }

  capacity(p: PropData) {
    return (R.capacities as any)[p.kind] ?? 1;
  }
  propFree(p: PropData, a: Agent) {
    const o = this.occ[p.id] ?? [];
    return o.includes(a.id) || o.length < this.capacity(p);
  }

  canSee(a: Agent, b: Agent) {
    if (a.room < 0 || b.room < 0) return false;
    if (a.room === b.room) return true;
    const d = Math.hypot(a.x - b.x, a.z - b.z);
    return areAdjacent(this.geo, a.room, b.room) && d < 5.5;
  }

  isAsleep(a: Agent) { return !!a.action && (a.action.key === "sleep" || a.action.key === "nap"); }

  isPlaying(a: Agent) { return a.action?.key === "play_piano" && !a.plan; }

  seatPos(p: PropData, a: Agent): Vec2 {
    if (this.capacity(p) > 1) {
      const idx = Math.max(0, (this.occ[p.id] ?? []).indexOf(a.id));
      const r = rightVec(p.yaw);
      const off = (idx === 0 ? -1 : 1) * propDims(p).w * 0.25;
      return [p.x + r[0] * off, p.z + r[1] * off];
    }
    return [p.x, p.z];
  }

  // ---------- 主循环 ----------
  step(dtTotal: number) {
    if (this.ended) return;
    let left = dtTotal;
    while (left > 1e-6) {
      const dt = Math.min(R.time.max_step, left);
      left -= dt;
      this.tick(dt);
      if (this.t >= END_MIN) {
        this.ended = true;
        this.addLog("system", "五日生活观察窗结束。");
        this.evaluateGoals(true);
        break;
      }
    }
  }

  tick(dt: number) {
    this.t += dt;
    // 每日补给
    const supplyAt = (this.day - 1) * 1440 + R.inventory.supply_hour * 60;
    if (this.t >= supplyAt && this.lastSupplyDay < this.day && this.day > 1) {
      this.lastSupplyDay = this.day;
      const pantries = Object.keys(this.stock);
      let left = R.inventory.daily_supply;
      let guard = 0;
      while (left > 0 && pantries.length && guard++ < 200) {
        for (const id of pantries) {
          if (left <= 0) break;
          if (this.stock[id] < R.inventory.capacity) { this.stock[id]++; left--; }
        }
        if (pantries.every((id) => this.stock[id] >= R.inventory.capacity)) break;
      }
      this.addLog("system", `第${this.day}日 06:00 库存补给送达（储物柜口粮 ${pantries.map((id) => this.stock[id]).join(" / ")}）。`);
    }
    this.updateNoise(dt);
    for (const a of this.agents) this.updateAgent(a, dt);
    this.updateCommitments();
    // 关系衰减（半衰期）
    const tensionK = Math.pow(0.5, dt / (R.relationship.tension_half_life_days * 1440));
    const affK = Math.pow(0.5, dt / (R.relationship.affinity_half_life_days * 1440));
    for (const a of this.agents) {
      for (const r of Object.values(a.rel)) {
        r.tension *= tensionK;
        r.affinity = R.relationship.initial.affinity + (r.affinity - R.relationship.initial.affinity) * affK;
      }
    }
    if (Math.floor(this.t) % 30 === 0 && Math.floor(this.t - dt) % 30 !== 0) this.evaluateGoals(false);
  }

  updateNoise(dt: number) {
    const players = this.agents.filter((a) => this.isPlaying(a));
    const irr = R.social.irritation;
    for (const a of this.agents) {
      let heard = 0;
      let source: Agent | null = null;
      for (const p of players) {
        if (p === a) continue;
        let f = irr.far_factor;
        if (p.room === a.room) f = 1;
        else if (areAdjacent(this.geo, p.room, a.room)) f = irr.adjacent_room_factor;
        if (f > heard) { heard = f; source = p; }
      }
      const inf = new Set<string>();
      if (heard >= irr.adjacent_room_factor && source) {
        const sens = a.action && R.actions[a.action.key]?.noise_sensitive ? 2 : 1;
        a.irritation += irr.per_noise_min * heard * dt * sens * 0.5;
        a.needs.calm = Math.max(0, a.needs.calm - R.response.noise_calm_per_minute * heard * dt);
        inf.add("当前听到演奏声");
        inf.add("声响的一种解释：有人练习");
        inf.add("声响的另一种解释：有人寻求陪伴");
        if (this.canSee(a, source)) inf.add(`${source.name}是当前可归因的演奏声源`);
        // 噪音吵醒
        if (this.isAsleep(a) && a.irritation > irr.threshold * 1.4 && this.rng() < 0.02 * dt) {
          this.addLog("action", `${a.name}被琴声吵醒了。`, [a.id]);
          this.endAction(a, false);
        }
      } else {
        a.irritation = Math.max(0, a.irritation - irr.decay_per_min * dt);
      }
      for (const o of this.agents) {
        if (o === a) continue;
        if (this.canSee(a, o)) {
          a.beliefs.seen[o.id] = { food: o.food > 0, room: o.room, t: this.t, playing: this.isPlaying(o) };
          inf.add(o.food > 0 ? `${o.name}手里有口粮，可尝试请求` : `${o.name}空手，可尝试询问是否需要口粮`);
        }
      }
      a.beliefs.inferences = [...inf];
    }
  }

  updateAgent(a: Agent, dt: number) {
    const act = a.action;
    const def = act ? R.actions[act.key] : null;
    const mult = def?.decay_mult ?? 1;
    for (const n of ALL_NEEDS) {
      a.needs[n] = Math.max(0, a.needs[n] - R.needs[n].decay * dt * (BODY.includes(n) || n === "energy" ? mult : 1));
    }
    // 心情与压力
    let sw = 0, sv = 0, crit = false;
    for (const [n, w] of Object.entries(R.mood.weights) as [string, number][]) {
      sw += w; sv += w * a.needs[n];
      if (a.needs[n] < R.mood.critical) crit = true;
    }
    if (crit) a.stress = Math.min(1, a.stress + R.mood.stress_gain_per_min * dt);
    else a.stress = Math.max(0, a.stress - R.mood.stress_relax_per_min * dt);
    a.mood = Math.max(0, Math.min(100, sv / sw - a.stress * 25));
    this.stats.minMood[a.id] = Math.min(this.stats.minMood[a.id] ?? 100, a.mood);
    if (a.needs.hunger < R.mood.critical && a.needs.hunger + R.needs.hunger.decay * dt >= R.mood.critical) {
      this.stats.hungryCritical++;
      this.addLog("system", `${a.name}饿得发慌（饥饿进入临界）。`, [a.id]);
    }
    if (a.bubble && this.t > a.bubble.until) a.bubble = null;

    // 作者强制行动
    if (a.forced) {
      const c = a.forced;
      a.forced = null;
      if (a.action) this.endAction(a, false);
      this.beginPlan(a, c, true);
      return;
    }

    if (act && def) {
      for (const [n, v] of Object.entries(def.fx ?? {}) as [string, number][]) a.needs[n] = Math.max(0, Math.min(100, a.needs[n] + v * dt));
      if (act.key === "hangout") {
        const cat = R.social.categories.invite;
        void cat;
      }
      act.remaining -= dt;
      // 中断：身体临界
      const critBody = BODY.find((n) => a.needs[n] < R.brain.critical * 0.75 && !(def.fx ?? {})[n]);
      if (critBody && act.key !== "sleep" && !act.forced && act.remaining > 2) {
        this.addLog("action", `${a.name}因${NEED_LABELS[critBody]}告急中断了「${act.label}」。`, [a.id]);
        this.endAction(a, false);
        return;
      }
      if (act.key === "sleep" && a.needs.energy >= 99.5 && !this.isNight()) act.remaining = 0;
      if (act.key === "play_piano" && a.quietUntil > this.t) act.remaining = 0;
      if (act.remaining <= 0) this.endAction(a, true);
      return;
    }

    if (a.plan) {
      this.updatePlan(a, dt);
      return;
    }

    if (this.t < a.idleUntil) return;
    this.decide(a);
  }

  updatePlan(a: Agent, dt: number) {
    const plan = a.plan!;
    // 社交目标移动，重新寻路
    if ((plan.type === "social" || plan.type === "fulfil") && plan.cand.targetId) {
      const tg = this.agent(plan.cand.targetId);
      const d = Math.hypot(tg.x - a.x, tg.z - a.z);
      if (this.isAsleep(tg) && plan.type === "social") {
        a.lastReason = `${tg.name}睡着了，作罢`;
        a.plan = null; a.path = []; a.idleUntil = this.t + 2;
        return;
      }
      if (d <= R.response.range_m) {
        a.path = [];
        this.arrive(a);
        return;
      }
      const end = a.path[a.path.length - 1];
      if (!end || Math.hypot(end[0] - tg.x, end[1] - tg.z) > 1.2) {
        const dest = nearestWalkable(this.geo, tg.x, tg.z, 1.5);
        const p = dest ? findPath(this.geo, [a.x, a.z], dest) : null;
        if (!p) { a.plan = null; a.idleUntil = this.t + 3; return; }
        a.path = p;
      }
      if (this.t - plan.startedAt > 60) { a.plan = null; a.path = []; a.lastReason = "没能追上对方"; return; }
    }
    let step = R.time.walk_speed_per_min * dt;
    while (step > 0 && a.path.length) {
      const [tx, tz] = a.path[0];
      const dx = tx - a.x, dz = tz - a.z;
      const d = Math.hypot(dx, dz);
      if (d < 1e-4) { a.path.shift(); continue; }
      a.facing = Math.atan2(dx, dz);
      if (d <= step) { a.x = tx; a.z = tz; a.path.shift(); step -= d; }
      else { a.x += (dx / d) * step; a.z += (dz / d) * step; step = 0; }
    }
    a.room = roomAt(this.geo, a.x, a.z);
    if (!a.path.length && plan.type !== "social" && plan.type !== "fulfil") this.arrive(a);
  }

  arrive(a: Agent) {
    const plan = a.plan!;
    const c = plan.cand;
    if (plan.type === "investigate") {
      a.plan = null;
      a.lastReason = "循声查看";
      const src = this.agents.find((o) => this.isPlaying(o) && this.canSee(a, o));
      if (src) this.addLog("action", `${a.name}循声走来，看见是${src.name}在弹琴。`, [a.id, src.id]);
      a.idleUntil = this.t + 0.5;
      return;
    }
    if (plan.type === "social" || plan.type === "fulfil") {
      a.plan = null;
      const tg = this.agent(c.targetId!);
      a.facing = Math.atan2(tg.x - a.x, tg.z - a.z);
      if (plan.type === "fulfil") this.fulfilCommitment(a, tg, plan.commitmentId!);
      else this.request(a, tg, c.category!, false);
      return;
    }
    // 普通行动
    const def = R.actions[c.action];
    const p = c.propId ? this.props[c.propId] : undefined;
    if (p && !this.propFree(p, a)) {
      if (!a.waitSince) a.waitSince = this.t;
      if (this.t - a.waitSince > R.brain.queue_wait_limit) {
        a.waitSince = 0; a.plan = null;
        a.lastReason = `等不到${p.kind}空出，改做别的`;
        const occ = this.occ[p.id].map((id) => this.agent(id)).find(Boolean);
        if (occ && (def.pose === "sit" || def.pose === "lie") && a.needs.comfort < 70 && !this.isAsleep(occ)) {
          this.request(a, occ, "ask_seat", false, p.id);
        }
      }
      return;
    }
    a.waitSince = 0;
    // 库存检查（真实世界）
    if (def.pantry || c.action === "inspect_pantry") {
      const real = this.stock[p!.id] ?? 0;
      a.beliefs.stock[p!.id] = { v: real, t: this.t };
      if (def.pantry && real < (def.stock_cost ?? 1)) {
        this.addLog("action", `${a.name}打开储物柜，发现已经没有口粮了。`, [a.id]);
        this.say(a, "……空的。", "think");
        a.plan = null; a.idleUntil = this.t + 1;
        return;
      }
    }
    a.plan = null;
    this.startAction(a, c, p, plan.commitmentId);
  }

  startAction(a: Agent, c: Candidate, p?: PropData, commitmentId?: string) {
    const def = R.actions[c.action];
    const [lo, hi] = def.dur;
    const dur = lo + (hi - lo) * this.rng();
    a.action = { key: c.action, label: def.label, propId: p?.id, remaining: dur, total: dur, pose: def.pose, forced: c.parts.includes("作者指令"), commitmentId };
    if (p) {
      if (!this.occ[p.id].includes(a.id)) this.occ[p.id].push(a.id);
      if (def.pose === "sit" || def.pose === "lie") {
        const sp = this.seatPos(p, a);
        a.x = sp[0]; a.z = sp[1];
        a.facing = (p.yaw * Math.PI) / 180;
      } else {
        a.facing = Math.atan2(p.x - a.x, p.z - a.z);
      }
    }
    if (def.pantry) {
      this.stock[p!.id] -= def.stock_cost ?? 1;
      a.beliefs.stock[p!.id] = { v: this.stock[p!.id], t: this.t };
    }
    a.recent.unshift(c.action);
    a.recent = a.recent.slice(0, R.brain.repeat_memory);
    if (c.action === "play_piano") {
      for (const o of this.agents) if (o !== a && o.room === a.room) this.say(o, "♪?", "think", 3);
    }
    if (!["wander", "drink", "light_lamp", "douse_lamp"].includes(c.action)) {
      this.addLog("action", `${a.name}开始「${def.label}」${p ? `（${this.roomName(this.propRoom[p.id])}）` : ""}。${a.lastReason ? "依据：" + a.lastReason : ""}`, [a.id]);
    }
  }

  endAction(a: Agent, completed: boolean) {
    const act = a.action;
    if (!act) return;
    const def = R.actions[act.key];
    if (act.propId) this.occ[act.propId] = (this.occ[act.propId] ?? []).filter((id) => id !== a.id);
    a.action = null;
    // 离开座位回到可行走处
    const nw = nearestWalkable(this.geo, a.x, a.z, 2);
    if (nw && (def.pose === "sit" || def.pose === "lie")) { a.x = nw[0]; a.z = nw[1]; }
    a.room = roomAt(this.geo, a.x, a.z);
    if (!completed) return;
    if (def.cooldown) a.cooldowns[act.key] = this.t + def.cooldown;
    if (def.gives === "food") { a.food++; }
    if (def.gives === "book") a.book = true;
    if (def.consumes === "food") { a.food = Math.max(0, a.food - 1); this.stats.meals++; }
    if (def.consumes === "book") a.book = false;
    if (def.special === "lamp_on" && act.propId) { this.setRoomLamps(this.propRoom[act.propId], true); }
    if (def.special === "lamp_off" && act.propId) { this.setRoomLamps(this.propRoom[act.propId], false); }
    // 动机：个人目的、求知、自主权
    const ra = (R.agents as any[]).find((x) => x.id === a.id);
    const mot = ra?.action_motives?.[act.key];
    if (mot) for (const [n, v] of Object.entries(mot) as [string, number][]) a.needs[n] = Math.min(100, a.needs[n] + v);
    if (act.forced) a.needs.agency = Math.max(0, a.needs.agency - 4);
    else a.needs.agency = Math.min(100, a.needs.agency + 1.5);
    if (act.key === "hangout" || act.key === "join_seat") {
      a.needs.social = Math.min(100, a.needs.social + 6);
      if (act.targetId && a.rel[act.targetId]) {
        a.rel[act.targetId].affinity = clamp(a.rel[act.targetId].affinity + 1.4);
        a.rel[act.targetId].trust = clamp(a.rel[act.targetId].trust + 0.5);
        a.rel[act.targetId].familiarity = clamp(a.rel[act.targetId].familiarity + 2);
        this.updateStage(a, act.targetId);
      }
    }
  }

  setRoomLamps(room: number, on: boolean) {
    for (const p of this.building.props) if (p.kind === "wall_lantern" && this.propRoom[p.id] === room) this.lamps[p.id] = on;
  }

  roomName(r: number) { return this.geo.rooms[r]?.name ?? "走廊"; }

  // ---------- 决策 ----------
  computeCandidates(a: Agent, forAuthor = false): Candidate[] {
    const out: Candidate[] = [];
    const h = this.hour;
    const B = R.brain;
    const night = this.isNight(h), dusk = this.isDusk(h), day = this.isDay(h);
    const bodyCrit = BODY.filter((n) => a.needs[n] < B.critical);
    const ra = (R.agents as any[]).find((x) => x.id === a.id) ?? {};
    const hearsMusic = a.beliefs.inferences.includes("当前听到演奏声");

    for (const [key, def] of Object.entries(R.actions) as [string, any][]) {
      if (def.commitment_only || def.joint) continue;
      if (def.requires === "food" && a.food <= 0) continue;
      if (def.requires === "book" && !a.book) continue;
      if (def.requires_not === "food" && a.food > 0) continue;
      if (def.requires_not === "book" && a.book) continue;
      if (def.day_only && !day) continue;
      if ((a.cooldowns[key] ?? 0) > this.t) continue;
      let gate = def.when as Record<string, number> | undefined;
      if (key === "sleep") gate = night ? def.when_night : dusk ? def.when : def.day_when;
      if (gate && !forAuthor) {
        if (!Object.entries(gate).some(([n, th]) => a.needs[n] < th)) continue;
      }
      if (key === "light_lamp" && day) continue;
      if (key === "douse_lamp" && !(night || day)) continue;

      const parts: string[] = [];
      let base = 0;
      const avgDur = (def.dur[0] + def.dur[1]) / 2;
      const gains: Record<string, number> = {};
      for (const [n, v] of Object.entries(def.fx ?? {}) as [string, number][]) if (v > 0) gains[n] = (gains[n] ?? 0) + v * avgDur;
      for (const [n, v] of Object.entries(def.chain_gain ?? {}) as [string, number][]) gains[n] = (gains[n] ?? 0) + v;
      for (const [n, v] of Object.entries(ra.action_motives?.[key] ?? {}) as [string, number][]) gains[n] = (gains[n] ?? 0) + v;
      for (const [n, amt] of Object.entries(gains)) {
        const cap = Math.min(amt, 100 - a.needs[n]);
        const g = (this.urgency(a, n) * cap * (a.weights[n] ?? 1)) / 10;
        if (g > 0.01) { base += g; parts.push(`${NEED_LABELS[n] ?? n}+${g.toFixed(2)}`); }
      }
      let score = base + (base > 0.05 ? def.importance ?? 0 : 0);
      if (def.importance && base > 0.05) parts.push(`重要度+${def.importance}`);
      if (key === "sleep") {
        if (night) { score *= B.night_sleep_bonus; parts.push(`夜间×${B.night_sleep_bonus}`); }
        else if (day) { score *= B.day_sleep_penalty; parts.push(`白天×${B.day_sleep_penalty}`); }
        else if (dusk && h < 21) { score *= 0.45; parts.push("傍晚尚早×0.45"); }
      }
      if (key === "prepare_meal" && a.needs.hunger < R.reasoning.plan_needs.hunger) { score += R.reasoning.plan_bonus / 10; parts.push(`推理：备餐→用餐+${R.reasoning.plan_bonus / 10}`); }
      if (key === "read" && a.needs.growth < R.reasoning.plan_needs.growth) { score += 0.2; parts.push("推理：取书→就座阅读+0.2"); }
      if (def.penalty) { score *= 1 - def.penalty; parts.push(`替代方案×${(1 - def.penalty).toFixed(2)}`); }
      if (bodyCrit.length && !bodyCrit.some((n) => gains[n])) { score *= B.survival_penalty; parts.push(`生存优先×${B.survival_penalty}`); }
      if (def.noise_sensitive && hearsMusic) { score *= 0.6; parts.push("听到琴声×0.6"); }
      if (a.recent.includes(key) && !["sleep", "eat_meal", "drink"].includes(key)) { score *= B.repeat_penalty; parts.push(`重复×${B.repeat_penalty}`); }
      if (key === "play_piano" && a.quietUntil > this.t) continue;

      if (key === "wander") {
        out.push({ action: key, label: def.label, score: B.idle_threshold * 0.6, parts: ["无事可做"], dist: 0 });
        continue;
      }
      if (key === "inspect_pantry") {
        for (const id of Object.keys(this.stock)) {
          const b = a.beliefs.stock[id];
          if (b && this.t - b.t < 240) continue;
          const p = this.props[id];
          const d = Math.hypot(p.x - a.x, p.z - a.z) * 1.25;
          const urgentFood = a.needs.hunger < 80 ? 0.4 : 0;
          const s = R.reasoning.info_bonus / 10 + urgentFood + base - d * B.distance_cost;
          out.push({ action: key, label: def.label, propId: id, score: s, parts: [`信息缺口+${R.reasoning.info_bonus / 10}`, ...(urgentFood ? ["关心口粮+0.4"] : []), ...parts, `距离-${(d * B.distance_cost).toFixed(2)}`], dist: d });
        }
        continue;
      }
      if (score <= 0.02 && !forAuthor && !["light_lamp", "douse_lamp"].includes(key)) continue;

      for (const p of this.building.props) {
        if (!def.kinds.includes(p.kind)) continue;
        if (def.pantry && !(p.id in this.stock)) continue;
        if (!this.propFree(p, a)) continue;
        const room = this.propRoom[p.id];
        if (room < 0) continue;
        if ((def.needs_light || def.light) && !day && !this.roomLit(room)) continue;
        if (def.near) {
          const ok = this.building.props.some((q) => def.near.includes(q.kind) && Math.hypot(q.x - p.x, q.z - p.z) <= def.near_dist);
          if (!ok) continue;
        }
        let s = score;
        const pp = [...parts];
        if (def.pantry) {
          const b = a.beliefs.stock[p.id];
          if (b && b.v <= 0 && this.t - b.t < 600) continue; // 本人认知：柜子空了
          if (!b) { s *= 0.85; pp.push("未确认库存×0.85"); }
        }
        if (key === "light_lamp") {
          if (this.lamps[p.id]) continue;
          if (room !== a.room && !forAuthor) continue;
          if (night && h >= 22.5) continue;
          s = 0.9 + base; pp.push("天黑需要照明+0.9");
        }
        if (key === "douse_lamp") {
          if (!this.lamps[p.id]) continue;
          const awake = this.agents.some((o) => o !== a && o.room === room && !this.isAsleep(o));
          if (day) { s = 0.8; pp.push("白天无需灯火+0.8"); }
          else if (night && !awake && a.needs.energy < 70) { s = 0.7 + base; pp.push("睡前熄灯+0.7"); }
          else if (!forAuthor) continue;
          if (room !== a.room && !forAuthor) continue;
        }
        if (def.owner_bed && p.kind === "bed") {
          const owner = this.bedOwner[p.id];
          if (owner === a.id) { s *= B.own_bed_bonus; pp.push(`自己的床×${B.own_bed_bonus}`); }
          else if (owner) { s *= B.foreign_bed_penalty; pp.push(`他人的床×${B.foreign_bed_penalty}`); }
        }
        if (def.kind_penalty?.[p.kind]) { s *= 1 - def.kind_penalty[p.kind]; pp.push(`${p.kind}×${(1 - def.kind_penalty[p.kind]).toFixed(2)}`); }
        const d = Math.hypot(p.x - a.x, p.z - a.z) * 1.25;
        s -= d * B.distance_cost;
        pp.push(`距离-${(d * B.distance_cost).toFixed(2)}`);
        out.push({ action: key, label: def.label, propId: p.id, score: s, parts: pp, dist: d });
      }
    }

    // 社交候选
    out.push(...this.socialCandidates(a, forAuthor));

    // 循声查看：听到琴声却看不到声源
    if (hearsMusic && a.irritation > R.social.irritation.threshold * 0.6 && !a.beliefs.inferences.some((s) => s.includes("可归因"))) {
      const src = this.agents.find((o) => this.isPlaying(o));
      if (src) out.push({ action: "investigate", label: "循声查看", targetId: src.id, score: 0.6 + a.irritation / 60, parts: ["声源不明，信息缺口"], dist: 0 });
    }

    // 承诺履行
    for (const c of this.commitments) {
      if (c.resolved || c.from !== a.id || c.kind !== "later") continue;
      const due = this.t - c.createdAt >= 8;
      if (!due && !forAuthor) continue;
      const urgency = this.t > c.fromDeadline - 5 ? 2.5 : 1.2;
      out.push({ action: "fulfil", label: `履行承诺：${c.label}`, targetId: c.to, score: urgency, parts: [`本人理解的“待会儿”：${senseLabel("later", c.fromSense)}`], dist: 0, category: c.id });
    }

    for (const c of out) c.score += (this.rng() - 0.5) * 2 * B.noise;
    out.sort((x, y) => y.score - x.score);
    return out;
  }

  socialCandidates(a: Agent, forAuthor: boolean): Candidate[] {
    const out: Candidate[] = [];
    const ra = (R.agents as any[]).find((x) => x.id === a.id) ?? {};
    const cats = R.social.categories as Record<string, any>;
    for (const o of this.agents) {
      if (o === a) continue;
      if (this.isAsleep(o)) continue;
      if ((a.talkCd[o.id] ?? 0) > this.t && !forAuthor) continue;
      const rel = a.rel[o.id];
      const seen = a.beliefs.seen[o.id];
      const d = Math.hypot(o.x - a.x, o.z - a.z);
      const visible = this.canSee(a, o);
      if (!visible && d > 12 && !forAuthor) continue;
      for (const [cat, def] of Object.entries(cats)) {
        if (def.fam && rel.familiarity < def.fam * 100) continue;
        if (def.tension_above !== undefined && rel.tension <= def.tension_above) continue;
        if (cat === "share_food" && (a.food <= 0 || !seen || seen.food)) continue;
        if (cat === "ask_share" && (!seen || !seen.food || a.food > 0)) continue;
        if (cat === "complain" && !(this.isPlaying(o) && visible && a.irritation > R.social.irritation.threshold)) continue;
        if (cat === "ask_seat") continue; // 由座位排队触发
        if (cat === "confide" && rel.stage === "敌视") continue;
        const parts: string[] = [];
        let s = 0;
        for (const [n, v] of Object.entries(def.need ?? {}) as [string, number][]) {
          const g = (this.urgency(a, n) * Math.min(v * 2, 100 - a.needs[n]) * (a.weights[n] ?? 1)) / 10;
          if (g > 0.005) { s += g; parts.push(`${NEED_LABELS[n]}+${g.toFixed(2)}`); }
        }
        for (const [n, v] of Object.entries(ra.social_motives?.[cat] ?? {}) as [string, number][]) {
          const g = (this.urgency(a, n) * v) / 10;
          if (g > 0.005) { s += g; parts.push(`动机·${NEED_LABELS[n]}+${g.toFixed(2)}`); }
        }
        if (cat === "complain") { s += a.irritation / 30; parts.push(`烦躁+${(a.irritation / 30).toFixed(2)}`); }
        if (cat === "share_food") { const g = 0.3 + (o.needs.hunger < 50 ? 0 : 0); s += g; }
        if (cat === "apologize") { s += rel.tension / 20; parts.push(`紧张+${(rel.tension / 20).toFixed(2)}`); }
        s *= (def.weight ?? 1) * R.brain.social_base;
        if (rel.stage === "敌视" && def.nature === "bonding") { s *= 0.3; parts.push("敌视×0.3"); }
        if (rel.stage === "亲近" && def.nature === "bonding") { s *= 1.2; parts.push("亲近×1.2"); }
        s -= d * R.brain.social_distance_cost;
        if (s <= 0.05 && !forAuthor) continue;
        const label = `${def.label} → ${o.name}`;
        out.push({ action: "social", label, targetId: o.id, category: cat, score: s, parts: [...parts, `距离-${(d * R.brain.social_distance_cost).toFixed(2)}`], dist: d });
      }
    }
    return out;
  }

  decide(a: Agent) {
    const cands = this.computeCandidates(a);
    a.candidates = cands.slice(0, 12);
    if (!cands.length) { a.idleUntil = this.t + 3; return; }
    const top = cands.slice(0, 6);
    const T = R.brain.temperature;
    const mx = top[0].score;
    if (mx < R.brain.idle_threshold * 0.5) {
      // 闲逛或发呆
      if (this.rng() < 0.5) {
        a.idleUntil = this.t + 4 + this.rng() * 6;
        a.lastReason = "暂无迫切需要，发呆";
        return;
      }
    }
    const ws = top.map((c) => Math.exp((c.score - mx) / T));
    const sum = ws.reduce((x, y) => x + y, 0);
    let r = this.rng() * sum;
    let pick = top[0];
    for (let i = 0; i < top.length; i++) { r -= ws[i]; if (r <= 0) { pick = top[i]; break; } }
    this.beginPlan(a, pick, false);
  }

  beginPlan(a: Agent, c: Candidate, forced: boolean) {
    a.lastReason = c.parts.slice(0, 3).join("，");
    if (forced) {
      this.stats.authorActs++;
      c = { ...c, parts: ["作者指令", ...c.parts] };
      this.addLog("author", `作者为${a.name}提交行动：「${c.label}」。`, [a.id]);
    }
    if (c.action === "social" || c.action === "fulfil") {
      const tg = this.agent(c.targetId!);
      a.plan = { type: c.action === "fulfil" ? "fulfil" : "social", cand: c, dest: [tg.x, tg.z], startedAt: this.t, commitmentId: c.action === "fulfil" ? c.category : undefined };
      a.path = [];
      a.talkCd[tg.id] = this.t + R.social.talk_cooldown;
      return;
    }
    if (c.action === "investigate") {
      const tg = this.agent(c.targetId!);
      const dest = nearestWalkable(this.geo, tg.x, tg.z, 2.5);
      const p = dest ? findPath(this.geo, [a.x, a.z], dest) : null;
      if (!p) { a.idleUntil = this.t + 3; return; }
      a.path = p.slice(0, Math.max(1, p.length - 1));
      a.plan = { type: "investigate", cand: c, dest: dest!, startedAt: this.t };
      return;
    }
    if (c.action === "wander") {
      const rooms = this.geo.rooms;
      const room = rooms[Math.floor(this.rng() * rooms.length)];
      const dest = room ? nearestWalkable(this.geo, room.cx + (this.rng() - 0.5) * 2, room.cz + (this.rng() - 0.5) * 2, 3) : null;
      const p = dest ? findPath(this.geo, [a.x, a.z], dest) : null;
      if (!p) { a.idleUntil = this.t + 3; return; }
      a.path = p;
      a.plan = { type: "action", cand: c, dest: dest!, startedAt: this.t };
      return;
    }
    const prop = c.propId ? this.props[c.propId] : undefined;
    const dest = prop ? approachPoint(this.geo, prop, this.propRoom[prop.id]) : [a.x, a.z] as Vec2;
    if (!dest) { a.idleUntil = this.t + 2; a.lastReason = "够不到目标"; return; }
    const p = findPath(this.geo, [a.x, a.z], dest);
    if (!p) { a.idleUntil = this.t + 2; a.lastReason = "找不到路径"; return; }
    a.path = p;
    a.plan = { type: "action", cand: c, dest, startedAt: this.t };
    void pathLength;
  }

  // ---------- 社交与回应 ----------
  request(q: Agent, r: Agent, cat: string, isFulfil: boolean, seatPropId?: string) {
    const def = R.social.categories[cat];
    const lines = R.social.lines.request[cat] ?? LINES_EXTRA[cat] ?? ["{t}……"];
    const line = lines[Math.floor(this.rng() * lines.length)].replace("{t}", r.name);
    this.say(q, line, "say", 5);
    this.stats.requests++;
    q.talkCd[r.id] = this.t + R.social.talk_cooldown;
    const mode = isFulfil ? "accept" : this.chooseResponse(r, q, cat);
    this.stats.modes[mode] = (this.stats.modes[mode] ?? 0) + 1;
    const replies = R.social.lines.reply[mode] ?? ["……"];
    let reply = replies[Math.floor(this.rng() * replies.length)];
    if (mode === "defer") {
      const s = r.lexicon.later ?? "soon";
      reply = s === "soon" ? "待会儿吧，我马上就来。" : "待会儿吧，等我有空。";
    }
    this.say(r, reply, mode, 6);
    r.facing = Math.atan2(q.x - r.x, q.z - r.z);
    this.addLog("social", `${q.name}→${r.name}「${line}」`, [q.id, r.id]);
    this.addLog("reply", `${r.name}${R.social.mode_labels[mode]}：「${reply}」`, [r.id, q.id]);
    this.applyMode(q, r, mode);
    const fulfil = R.social.mode_effects[mode].fulfil;
    if (fulfil >= 1) this.applyCategory(q, r, cat, seatPropId);
    else if (mode === "defer") this.makeLater(q, r, cat);
    void def;
  }

  chooseResponse(r: Agent, q: Agent, cat: string): string {
    const def = R.social.categories[cat];
    const rel = r.rel[q.id];
    const busy = r.action && (R.actions[r.action.key]?.importance ?? 0) >= 0.3 ? 1 : r.plan ? 0.5 : 0;
    const f: Record<string, number> = {
      benefit: def.benefit ?? 0.3,
      coercion: def.coercion ?? 0,
      cost: def.cost ?? 0,
      intrusion: def.intr ?? 0,
      affinity: rel.affinity / 50,
      trust: rel.trust / 50,
      calm: r.needs.calm / 100,
      agreeable: 0.5,
      tension: rel.tension / 30,
      debt: Math.min(1, Math.max(0, rel.owe)),
      busy,
    };
    if (cat === "ask_share" && r.needs.hunger < 40) f.cost += 0.6;
    const scores: Record<string, number> = {};
    for (const m of R.social.modes as string[]) {
      const w = R.response.scores[m] ?? {};
      let s = w.base ?? 0;
      for (const [k, v] of Object.entries(w) as [string, number][]) if (k !== "base") s += v * (f[k] ?? 0);
      s += R.response.nature_bias[def.nature]?.[m] ?? 0;
      s += R.response.stage_bias[rel.stage]?.[m] ?? 0;
      scores[m] = s;
    }
    const T = R.response.temperature;
    const mx = Math.max(...Object.values(scores));
    const ws = Object.entries(scores).map(([m, s]) => [m, Math.exp((s - mx) / T)] as [string, number]);
    const sum = ws.reduce((x, [, w]) => x + w, 0);
    let x = this.rng() * sum;
    for (const [m, w] of ws) { x -= w; if (x <= 0) return m; }
    return ws[0][0];
  }

  applyMode(q: Agent, r: Agent, mode: string) {
    const e = R.social.mode_effects[mode];
    const caps = R.social.caps;
    const qr = q.rel[r.id], rq = r.rel[q.id];
    const clampD = (v: number, gain: number, loss: number) => Math.max(-loss, Math.min(gain, v));
    qr.affinity = clamp(qr.affinity + clampD(e.q_aff, caps.aff_gain, caps.aff_loss));
    qr.trust = clamp(qr.trust + clampD(e.q_trust, caps.trust_gain, caps.trust_loss));
    qr.tension = clamp(qr.tension + Math.min(caps.tension_gain, e.q_tension));
    rq.affinity = clamp(rq.affinity + clampD(e.r_aff, caps.aff_gain, caps.aff_loss));
    rq.trust = clamp(rq.trust + clampD(e.r_trust, caps.trust_gain, caps.trust_loss));
    rq.tension = clamp(rq.tension + Math.min(caps.tension_gain, e.r_tension));
    qr.familiarity = clamp(qr.familiarity + 0.8);
    rq.familiarity = clamp(rq.familiarity + 0.8);
    q.stress = Math.max(0, Math.min(1, q.stress + e.q_stress));
    r.stress = Math.max(0, Math.min(1, r.stress + e.r_stress));
    q.needs.social = Math.min(100, q.needs.social + 4);
    r.needs.social = Math.min(100, r.needs.social + 2);
    if (mode === "confront" || mode === "ignore") q.needs.calm = Math.max(0, q.needs.calm - 6);
    this.updateStage(q, r.id);
    this.updateStage(r, q.id);
  }

  updateStage(a: Agent, oid: string) {
    const rel = a.rel[oid];
    const RR = R.relationship;
    const prev = rel.stage;
    let st = "生疏";
    if (rel.tension >= RR.hostile_tension) st = "敌视";
    else for (const s of RR.stages) if (rel.affinity >= s.affinity && rel.trust >= s.trust) { st = s.id; break; }
    // 滞回
    if (prev && prev !== st && prev !== "敌视" && st !== "敌视") {
      const ps = RR.stages.find((s: any) => s.id === prev);
      if (ps && rel.affinity > ps.affinity - RR.stage_hysteresis && rel.trust > ps.trust - RR.stage_hysteresis && RR.stages.indexOf(ps) < RR.stages.findIndex((s: any) => s.id === st || st === "生疏")) st = prev;
    }
    if (prev !== st && prev) this.addLog("system", `${a.name}对${CHAR_BY_ID[oid].name}的关系：${prev} → ${st}`, [a.id, oid]);
    rel.stage = st;
  }

  applyCategory(q: Agent, r: Agent, cat: string, seatPropId?: string) {
    const def = R.social.categories[cat];
    const ra = (R.agents as any[]).find((x) => x.id === q.id) ?? {};
    for (const [n, v] of Object.entries(def.need ?? {}) as [string, number][]) q.needs[n] = Math.min(100, q.needs[n] + v);
    for (const [n, v] of Object.entries(ra.social_motives?.[cat] ?? {}) as [string, number][]) q.needs[n] = Math.min(100, q.needs[n] + v);
    r.needs.social = Math.min(100, r.needs.social + (def.need?.social ?? 4) * 0.5);
    if (["bonding", "offer", "amends", "favor"].includes(def.nature)) {
      const k = def.nature === "offer" || def.nature === "amends" ? 1.6 : 1;
      q.rel[r.id].affinity = clamp(q.rel[r.id].affinity + 0.9 * k);
      r.rel[q.id].affinity = clamp(r.rel[q.id].affinity + 0.7 * k);
      if (def.nature === "amends") { q.rel[r.id].tension *= 0.6; r.rel[q.id].tension *= 0.6; }
      this.updateStage(q, r.id); this.updateStage(r, q.id);
    }
    switch (def.fx) {
      case "offer_food": this.giveFood(q, r, cat); break;
      case "share_food": this.giveFood(r, q, cat); break;
      case "stop_noise": this.stopNoise(q, r); break;
      case "yield_object": {
        if (r.action) this.endAction(r, false);
        this.addLog("action", `${r.name}起身让出了座位。`, [r.id]);
        if (seatPropId) {
          const p = this.props[seatPropId];
          const cand: Candidate = { action: "rest", label: R.actions.rest.label, propId: p.id, score: 1, parts: ["对方让位"], dist: 0 };
          this.startAction(q, cand, p);
        }
        break;
      }
      case "hangout": this.startHangout(q, r); break;
      default: break;
    }
  }

  startHangout(q: Agent, r: Agent) {
    if (this.isAsleep(r)) return;
    if (r.action) this.endAction(r, false);
    r.plan = null; r.path = [];
    const seat = this.building.props
      .filter((p) => (p.kind === "sofa" || p.kind === "bench") && (this.occ[p.id] ?? []).length === 0)
      .sort((a, b) => Math.hypot(a.x - q.x, a.z - q.z) - Math.hypot(b.x - q.x, b.z - q.z))[0];
    const dur = 20 + this.rng() * 20;
    for (const ag of [q, r]) {
      ag.action = { key: "hangout", label: `与${(ag === q ? r : q).name}一同闲坐`, propId: seat?.id, targetId: (ag === q ? r : q).id, remaining: dur, total: dur, pose: seat ? "sit" : "stand" };
      if (seat) {
        this.occ[seat.id].push(ag.id);
        const sp = this.seatPos(seat, ag);
        ag.x = sp[0]; ag.z = sp[1]; ag.facing = (seat.yaw * Math.PI) / 180;
      }
    }
    this.addLog("action", `${q.name}与${r.name}${seat ? `在${this.roomName(this.propRoom[seat.id])}的${seat.kind === "sofa" ? "沙发" : "长凳"}上` : "原地"}一同闲坐。`, [q.id, r.id]);
  }

  giveFood(giver: Agent, recv: Agent, cat: string) {
    if (giver.food <= 0) {
      this.addLog("action", `${giver.name}翻了翻口袋，其实已经没有口粮了。`, [giver.id]);
      return;
    }
    giver.food--; recv.food++;
    recv.beliefs.seen[giver.id] = { food: giver.food > 0, room: giver.room, t: this.t, playing: false };
    const gs = giver.lexicon.give_back ?? "free", rs = recv.lexicon.give_back ?? "free";
    const term = R.lexicon.terms.give_back;
    this.addLog("action", `${giver.name}把一份口粮交给${recv.name}。（${giver.name}心里：${term.senses[gs].label}；${recv.name}心里：${term.senses[rs].label}）`, [giver.id, recv.id]);
    if (gs === "return" || rs === "return") {
      const grace = R.lexicon.return_grace_minutes;
      this.commitments.push({
        id: `c${++this.seq}`, kind: "give_back", from: recv.id, to: giver.id, label: `归还${giver.name}的一份口粮`, category: cat,
        createdAt: this.t,
        fromDeadline: rs === "return" ? this.t + grace : Infinity,
        toDeadline: gs === "return" ? this.t + grace : Infinity,
        fromSense: rs, toSense: gs,
      });
      if (rs === "return") recv.rel[giver.id].owe += 1;
    }
  }

  stopNoise(q: Agent, r: Agent) {
    const qs = q.lexicon.quiet ?? "short", rs = r.lexicon.quiet ?? "short";
    const term = R.lexicon.terms.quiet;
    if (r.action?.key === "play_piano") this.endAction(r, false);
    r.quietUntil = this.t + term.senses[rs].minutes;
    q.irritation = 0;
    this.addLog("action", `${r.name}停下了琴。（${q.name}理解的“小声点”：${term.senses[qs].label}；${r.name}理解的：${term.senses[rs].label}）`, [q.id, r.id]);
    this.commitments.push({
      id: `c${++this.seq}`, kind: "quiet", from: r.id, to: q.id, label: "保持安静", createdAt: this.t,
      fromDeadline: this.t + term.senses[rs].minutes, toDeadline: this.t + term.senses[qs].minutes, fromSense: rs, toSense: qs,
    });
  }

  makeLater(q: Agent, r: Agent, cat: string) {
    const term = R.lexicon.terms.later;
    const rs = r.lexicon.later ?? term.default, qs = q.lexicon.later ?? term.default;
    const def = R.social.categories[cat];
    this.commitments.push({
      id: `c${++this.seq}`, kind: "later", from: r.id, to: q.id, label: `${def.label}（应${q.name}）`, category: cat,
      createdAt: this.t,
      fromDeadline: this.t + term.senses[rs].minutes, toDeadline: this.t + term.senses[qs].minutes,
      fromSense: rs, toSense: qs,
    });
    this.addLog("promise", `${r.name}答应“待会儿”再${def.label}。${q.name}心里的期限：${term.senses[qs].label}；${r.name}心里的：${term.senses[rs].label}。`, [r.id, q.id]);
  }

  fulfilCommitment(a: Agent, tg: Agent, cid: string) {
    const c = this.commitments.find((x) => x.id === cid);
    if (!c || c.resolved) return;
    const late = this.t > c.toDeadline;
    c.resolved = "fulfilled";
    this.stats.fulfilled++;
    const line = late ? `${tg.name}，抱歉让你久等了。` : `${tg.name}，我来了，刚才说好的。`;
    this.say(a, line, "say", 5);
    this.addLog("promise", `${a.name}履行了承诺：${c.label}${late ? `（但已超出${tg.name}心里的期限）` : ""}。`, [a.id, tg.id]);
    const fe = R.relationship.fulfilled_effects;
    if (!late) {
      tg.rel[a.id].trust = clamp(tg.rel[a.id].trust + fe.trust);
      tg.rel[a.id].affinity = clamp(tg.rel[a.id].affinity + fe.affinity);
    }
    this.updateStage(tg, a.id);
    if (c.category) this.applyCategory(tg, a, c.category);
    a.needs.purpose = Math.min(100, a.needs.purpose + 6);
  }

  updateCommitments() {
    const lex = R.lexicon;
    for (const c of this.commitments) {
      if (c.resolved) continue;
      const from = this.agent(c.from), to = this.agent(c.to);
      if (c.kind === "give_back") {
        // 欠方自认要还：有余粮且对方在附近时归还
        if (c.fromSense === "return" && from.food > 0 && !from.action && !from.plan && this.canSee(from, to) && !this.isAsleep(to) && this.t - c.createdAt > 60) {
          from.food--; to.food++;
          c.resolved = "fulfilled";
          this.stats.fulfilled++;
          from.rel[to.id].owe = Math.max(0, from.rel[to.id].owe - 1);
          const re = R.relationship.reciprocity_effects;
          to.rel[from.id].trust = clamp(to.rel[from.id].trust + re.trust);
          to.rel[from.id].affinity = clamp(to.rel[from.id].affinity + re.affinity);
          this.say(from, "上次那份，还你。", "say", 5);
          this.addLog("promise", `${from.name}归还了${to.name}一份口粮。`, [from.id, to.id]);
          if (c.toSense === "free") {
            this.say(to, "咦？那本来就是送你的。", "think", 5);
            this.ontology(`“${lex.terms.give_back.word}”：${to.name}以为是「${lex.terms.give_back.senses.free.label}」，${from.name}却当作「${lex.terms.give_back.senses.return.label}」——期待意外地被超出。`, [to.id, from.id]);
          }
          this.updateStage(to, from.id);
          continue;
        }
        if (this.t > c.toDeadline) {
          c.resolved = "broken";
          this.stats.broken++;
          this.grievance(to, from);
          this.say(to, "那份口粮……他是不打算还了吗？", "think", 6);
          this.ontology(`“${lex.terms.give_back.word}”：${to.name}心里是「${lex.terms.give_back.senses[c.toSense].label}」，${from.name}心里是「${lex.terms.give_back.senses[c.fromSense].label}」。期待落空，分歧显现。`, [to.id, from.id]);
        } else if (this.t > c.fromDeadline + 60) {
          c.resolved = "expired";
        }
      } else if (c.kind === "quiet") {
        if (from.action?.key === "play_piano" && this.t < c.toDeadline) {
          c.resolved = "broken";
          this.stats.broken++;
          this.grievance(to, from);
          this.ontology(`“${lex.terms.quiet.word}”：${to.name}理解为「${lex.terms.quiet.senses[c.toSense].label}」，${from.name}理解为「${lex.terms.quiet.senses[c.fromSense].label}」。琴声再起时，分歧显现。`, [to.id, from.id]);
        } else if (this.t >= c.toDeadline) {
          c.resolved = "fulfilled";
          this.stats.fulfilled++;
        }
      } else if (c.kind === "later") {
        if (this.t > c.toDeadline && !(c as any).noticed) {
          (c as any).noticed = true;
          const be = R.relationship.broken_effects;
          to.rel[from.id].trust = clamp(to.rel[from.id].trust + be.trust);
          to.rel[from.id].tension = clamp(to.rel[from.id].tension + be.tension);
          this.updateStage(to, from.id);
          this.say(to, `${from.name}说的待会儿呢？`, "think", 6);
          if (c.fromSense !== c.toSense) {
            this.ontology(`“${lex.terms.later.word}”：${to.name}以为是「${lex.terms.later.senses[c.toSense].label}」，${from.name}以为是「${lex.terms.later.senses[c.fromSense].label}」。`, [to.id, from.id]);
          } else {
            this.addLog("promise", `${to.name}等不到${from.name}的“待会儿”，期待落空。`, [to.id, from.id]);
          }
        }
        if (this.t > c.createdAt + R.response.expiry_minutes) {
          c.resolved = "broken";
          this.stats.broken++;
          this.addLog("promise", `${from.name}对${to.name}的承诺“${c.label}”过期未履行。`, [from.id, to.id]);
        }
      }
    }
    if (this.commitments.length > 80) this.commitments = this.commitments.filter((c) => !c.resolved || this.t - c.createdAt < 600);
  }

  grievance(a: Agent, b: Agent) {
    const g = R.lexicon.grievance;
    a.rel[b.id].tension = clamp(a.rel[b.id].tension + g.tension);
    a.rel[b.id].trust = clamp(a.rel[b.id].trust + g.trust);
    a.needs.calm = Math.max(0, a.needs.calm + g.calm);
    this.updateStage(a, b.id);
  }

  ontology(text: string, who: string[]) {
    this.stats.ontology++;
    this.addLog("ontology", text, who);
  }

  // ---------- 作者接口 ----------
  authorCandidates(a: Agent): Candidate[] {
    const list = this.computeCandidates(a, true);
    // 每种行动保留得分最高的若干个
    const seen = new Map<string, number>();
    return list.filter((c) => {
      const k = c.action === "social" ? `${c.action}:${c.category}:${c.targetId}` : c.action;
      const n = seen.get(k) ?? 0;
      seen.set(k, n + 1);
      return n < (c.action === "social" ? 1 : 2);
    });
  }

  submit(a: Agent, c: Candidate) {
    a.forced = c;
  }

  // ---------- 目标 ----------
  evaluateGoals(final: boolean) {
    const pairs = this.friendlyPairs();
    const close = this.friendlyPairs(true);
    const hostile = this.agents.some((a) => Object.values(a.rel).some((r) => r.stage === "敌视"));
    const avgMood = this.agents.reduce((s, a) => s + a.mood, 0) / this.agents.length;
    const st = this.stats;
    const ratio = st.fulfilled / Math.max(1, st.fulfilled + st.broken);
    for (const g of this.goals) {
      const sticky = ["observe", "friends", "close", "ontology"].includes(g.id);
      if (g.done && sticky) continue;
      switch (g.id) {
        case "observe": g.done = this.t >= END_MIN; break;
        case "friends": g.done = pairs >= 4; break;
        case "close": g.done = close >= 1; break;
        case "ontology": g.done = st.ontology >= 5; break;
        case "promises": g.done = st.fulfilled >= 20 && ratio >= 0.9; break;
        case "no_hostile": g.done = !hostile && (final || this.day >= 2); break;
        case "fed": g.done = st.hungryCritical === 0 && (final || this.day >= 2); break;
        case "mood": g.done = avgMood >= 70; break;
        case "hands_off": g.done = st.authorActs <= 8; break;
      }
    }
  }

  friendlyPairs(closeOnly = false) {
    let n = 0;
    for (let i = 0; i < this.agents.length; i++) for (let j = i + 1; j < this.agents.length; j++) {
      const a = this.agents[i], b = this.agents[j];
      const ok = (s: string) => (closeOnly ? s === "亲近" : s === "友善" || s === "亲近");
      if (ok(a.rel[b.id].stage) && ok(b.rel[a.id].stage)) n++;
    }
    return n;
  }

  // ---------- 存读档 ----------
  serialize(): string {
    const { geo, props, propRoom, rng, ...rest } = this as any;
    void geo; void props; void propRoom; void rng;
    return JSON.stringify({ v: 1, ...rest, rngPos: this.rng() });
  }

  static deserialize(json: string): LifeSim {
    const d = JSON.parse(json);
    const sim = new LifeSim(d.building, d.rngState);
    Object.assign(sim, { ...d, geo: sim.geo, props: sim.props, propRoom: sim.propRoom, rng: mulberry(Math.floor((d.rngPos ?? 0.5) * 1e9)) });
    for (const c of sim.commitments) {
      if (c.fromDeadline === null) c.fromDeadline = Infinity;
      if (c.toDeadline === null) c.toDeadline = Infinity;
    }
    return sim;
  }

  /** 兼容内容重载：重新解析建筑与规则，保留人物状态 */
  reloadContent() {
    this.geo = buildGeo(this.building);
    this.indexProps();
    for (const a of this.agents) {
      for (const n of ALL_NEEDS) if (a.needs[n] === undefined) a.needs[n] = 70;
      a.room = roomAt(this.geo, a.x, a.z);
    }
    this.addLog("system", "兼容内容重载完成：规则与建筑已重新解析，人物状态保留。");
  }
}

function clamp(v: number) { return Math.max(0, Math.min(100, v)); }

export function senseLabel(term: string, sense: string) {
  return R.lexicon.terms[term]?.senses[sense]?.label ?? sense;
}

export function makeGoals(): Goal[] {
  return [
    { id: "observe", label: "五日观察", desc: "坚持观察至第五日结束", done: false },
    { id: "friends", label: "结伴", desc: "至少四对人物互为「友善」或「亲近」", done: false },
    { id: "close", label: "知己", desc: "至少一对人物互为「亲近」（好感≥55，信任≥50）", done: false },
    { id: "ontology", label: "词义分歧", desc: "见证 5 次同词异义引发的期待落空或意外", done: false },
    { id: "promises", label: "守诺之家", desc: "兑现承诺 ≥20 次，且兑现率 ≥90%", done: false },
    { id: "no_hostile", label: "无人敌视", desc: "没有任何一方处于「敌视」", done: false },
    { id: "fed", label: "无人挨饿", desc: "五日内无人饥饿跌入临界", done: false },
    { id: "mood", label: "安居", desc: "五人平均心情不低于 70", done: false },
    { id: "hands_off", label: "放手", desc: "作者干预不超过 8 次（自主与引导的取舍）", done: false },
  ];
}

export function fmtTime(t: number) {
  const day = Math.floor(t / 1440) + 1;
  const m = Math.floor(t % 1440);
  return `第${day}日 ${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
}
export function fmtClock(t: number) {
  const m = Math.floor(t % 1440);
  return `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
}
