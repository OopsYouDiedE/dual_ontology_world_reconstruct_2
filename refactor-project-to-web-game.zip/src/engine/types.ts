export type Vec2 = [number, number];

export interface Opening {
  id: string;
  segment: number;
  center: number; // 沿该段距离起点的米数
  width: number;
  type: string; // closed_door | portal_arch | rectangular_window
}

export interface WallData {
  id: string;
  points: Vec2[]; // [x, z]
  thickness: number;
  height: number;
  openings: Opening[];
}

export interface PropData {
  id: string;
  kind: string;
  x: number;
  z: number;
  yaw: number;
  params: Record<string, number>;
  owner?: string;
}

export interface BuildingData {
  name: string;
  width: number;
  depth: number;
  style: string;
  walls: WallData[];
  props: PropData[];
}

export type NeedKey =
  | "hunger" | "thirst" | "energy" | "hygiene" | "social" | "fun" | "comfort" | "growth" | "calm"
  | "curiosity" | "purpose" | "agency";

export type Pose = "stand" | "sit" | "lie" | "work" | "walk";

export interface Relation {
  affinity: number;
  trust: number;
  tension: number;
  familiarity: number;
  owe: number;
  stage: string;
}

export interface Candidate {
  action: string;
  label: string;
  propId?: string;
  targetId?: string;
  category?: string;
  score: number;
  parts: string[];
  dist: number;
}

export interface Commitment {
  id: string;
  kind: "later" | "give_back" | "quiet" | "seat";
  from: string; // 承诺者 / 欠方
  to: string; // 期待方
  label: string;
  category?: string;
  createdAt: number;
  // 每个人脑中的期限（分钟）：同一词，两种事实
  fromDeadline: number;
  toDeadline: number;
  fromSense: string;
  toSense: string;
  resolved?: "fulfilled" | "broken" | "expired";
  seatPropId?: string;
}

export interface LogEntry {
  t: number;
  kind: "action" | "social" | "reply" | "system" | "ontology" | "promise" | "author";
  text: string;
  who?: string[];
}

export interface Goal {
  id: string;
  label: string;
  desc: string;
  done: boolean;
}
